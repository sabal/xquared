var xq={};
xq.asEventSource=function(A,D,C){A._listeners=[];
A._registerEventFirer=function(F,E){this["_fireOn"+E]=function(){for(var G=0;
G<this._listeners.length;
G++){var I=this._listeners[G];
var H=I["on"+F+E];
if(H){H.apply(I,$A(arguments))
}}}
};
A.addListener=function(E){this._listeners.push(E)
};
for(var B=0;
B<C.length;
B++){A._registerEventFirer(D,C[B])
}};
Array.prototype.indexOf=function(B){for(var A=0;
A<this.length;
A++){if(this[A]==B){return A
}}return -1
};
Date.preset=null;
Date.pass=function(A){if(Date.preset==null){return 
}Date.preset=new Date(Date.preset.getTime()+A)
};
Date.get=function(){return Date.preset==null?new Date():Date.preset
};
Date.prototype.elapsed=function(A){return Date.get().getTime()-this.getTime()>=A
};
String.prototype.merge=function(B){var A=this;
for(k in B){A=A.replace("{"+k+"}",B[k])
}return A
};
xq.Editor=Class.create();
xq.Editor.prototype={initialize:function(A){if(!A){throw"[contentElement] is null"
}if(A.nodeType!=1){throw"[contentElement] is not an element"
}xq.asEventSource(this,"Editor",["ElementChanged","BeforeEvent","AfterEvent","CurrentContentChanged","StaticContentChanged","ModeChanged"]);
this.contentElement=A;
this.doc=this.contentElement.ownerDocument;
this.body=this.doc.body;
this.editMode=false;
this.rdom=xq.RichDom.createInstance();
this.validator=xq.Validator.createInstance();
this.editorFrame=null;
this.editorWin=null;
this.editorDoc=null;
this.editorBody=null;
this.config={};
this.config.enableLinkClick=false;
this.config.shortcuts={};
this.config.autocorrections={};
this.config.autocompletions={};
this.config.templateProcessors={};
this.editHistory=null;
this._contextMenuEnabled=false;
this._contextMenuContainer=null;
this._contextMenuHandler=null;
this._contextMenuItems=null;
this._validContentCache=null;
this._lastModified=null;
this.addShortcuts(this._getDefaultShortcuts());
this.addTemplateProcessors(this._getDefaultTemplateProcessors())
},_getDefaultShortcuts:function(){if(xq.Browser.isMac){return[{event:"Ctrl+Shift+SPACE",handler:"this.handleAutocompletion(); stop = true;"},{event:"ENTER",handler:"this.handleEnter(false, false)"},{event:"Ctrl+ENTER",handler:"this.handleEnter(true, false)"},{event:"Ctrl+Shift+ENTER",handler:"this.handleEnter(true, true)"},{event:"TAB",handler:"this.handleTab()"},{event:"Shift+TAB",handler:"this.handleShiftTab()"},{event:"DELETE",handler:"this.handleDelete()"},{event:"BACKSPACE",handler:"this.handleBackspace()"},{event:"Ctrl+B",handler:"this.handleStrongEmphasis()"},{event:"Ctrl+I",handler:"this.handleEmphasis()"},{event:"Ctrl+U",handler:"this.handleUnderline()"},{event:"Ctrl+K",handler:"this.handleStrike()"},{event:"Meta+Z",handler:"this.handleUndo()"},{event:"Meta+Shift+Z",handler:"this.handleRedo()"},{event:"Meta+Y",handler:"this.handleRedo()"}]
}else{if(xq.Browser.isUbunto){return[{event:"Ctrl+SPACE",handler:"this.handleAutocompletion(); stop = true;"},{event:"ENTER",handler:"this.handleEnter(false, false)"},{event:"Ctrl+ENTER",handler:"this.handleEnter(true, false)"},{event:"Ctrl+Shift+ENTER",handler:"this.handleEnter(true, true)"},{event:"TAB",handler:"this.handleTab()"},{event:"Shift+TAB",handler:"this.handleShiftTab()"},{event:"DELETE",handler:"this.handleDelete()"},{event:"BACKSPACE",handler:"this.handleBackspace()"},{event:"Ctrl+B",handler:"this.handleStrongEmphasis()"},{event:"Ctrl+I",handler:"this.handleEmphasis()"},{event:"Ctrl+U",handler:"this.handleUnderline()"},{event:"Ctrl+K",handler:"this.handleStrike()"},{event:"Ctrl+Z",handler:"this.handleUndo()"},{event:"Ctrl+Y",handler:"this.handleRedo()"}]
}else{return[{event:"Ctrl+SPACE",handler:"this.handleAutocompletion(); stop = true;"},{event:"ENTER",handler:"this.handleEnter(false, false)"},{event:"Ctrl+ENTER",handler:"this.handleEnter(true, false)"},{event:"Ctrl+Shift+ENTER",handler:"this.handleEnter(true, true)"},{event:"TAB",handler:"this.handleTab()"},{event:"Shift+TAB",handler:"this.handleShiftTab()"},{event:"DELETE",handler:"this.handleDelete()"},{event:"BACKSPACE",handler:"this.handleBackspace()"},{event:"Ctrl+B",handler:"this.handleStrongEmphasis()"},{event:"Ctrl+I",handler:"this.handleEmphasis()"},{event:"Ctrl+U",handler:"this.handleUnderline()"},{event:"Ctrl+K",handler:"this.handleStrike()"},{event:"Ctrl+Z",handler:"this.handleUndo()"},{event:"Ctrl+Y",handler:"this.handleRedo()"}]
}}},_getDefaultTemplateProcessors:function(){return[{id:"predefinedKeywordProcessor",handler:function(C){var A=Date.get();
var B={year:A.getFullYear(),month:A.getMonth()+1,date:A.getDate(),hour:A.getHours(),min:A.getMinutes(),sec:A.getSeconds()};
return C.replace(/\{xq:(year|month|date|hour|min|sec)\}/img,function(E,D){return B[D]||D
})
}}]
},addShortcut:function(A,B){this.config.shortcuts[A]={"event":new xq.Shortcut(A),"handler":B}
},addShortcuts:function(A){A.each(function(B){this.addShortcut(B.event,B.handler)
}.bind(this))
},getShortcut:function(A){return this.config.shortcuts[A]
},getShortcuts:function(){return this.config.shortcuts
},removeShortcut:function(A){delete this.config.shortcuts[A]
},addAutocorrection:function(D,C,A){if(C.exec){var B=C;
C=function(E){return E.match(B)
}}this.config.autocorrections[D]={"criteria":C,"handler":A}
},addAutocorrections:function(A){A.each(function(B){this.addAutocorrection(B.id,B.criteria,B.handler)
}.bind(this))
},getAutocorrection:function(A){return this.config.autocorrection[A]
},getAutocorrections:function(){return this.config.autocorrections
},removeAutocorrection:function(A){delete this.config.autocorrections[A]
},addAutocompletion:function(D,C,A){if(C.exec){var B=C;
C=function(F){var E=B.exec(F);
return E?E.index:-1
}}this.config.autocompletions[D]={"criteria":C,"handler":A}
},addAutocompletions:function(A){A.each(function(B){this.addAutocompletion(B.id,B.criteria,B.handler)
}.bind(this))
},getAutocompletion:function(A){return this.config.autocompletions[A]
},getAutocompletions:function(){return this.config.autocompletions
},removeAutocompletion:function(A){delete this.config.autocompletions[A]
},addTemplateProcessor:function(B,A){this.config.templateProcessors[B]={"handler":A}
},addTemplateProcessors:function(A){A.each(function(B){this.addTemplateProcessor(B.id,B.handler)
}.bind(this))
},getTemplateProcessor:function(A){return this.config.templateProcessors[A]
},getTemplateProcessors:function(){return this.config.templateProcessors
},removeTemplateProcessors:function(A){delete this.config.templateProcessors[A]
},setEditMode:function(A){if(this.editMode==A){return 
}if(A){this.contentElement.style.display="none";
if(!this.editorFrame){this._createEditorFrame();
this._registerEventHandlers()
}this.loadCurrentContentFromStaticContent();
this.editorFrame.style.display="block";
if(!xq.Browser.isTrident){window.setTimeout(function(){this.getDoc().designMode="On"
}.bind(this),0)
}}else{this.editorFrame.style.display="none";
this.setStaticContent(this.getCurrentContent());
this.contentElement.style.display="block"
}this.editMode=A;
this._fireOnModeChanged(this,A)
},loadStylesheet:function(C){var A=this.editorDoc.getElementsByTagName("HEAD")[0];
var B=this.editorDoc.createElement("LINK");
B.rel="Stylesheet";
B.type="text/css";
B.href=C;
A.appendChild(B)
},loadCurrentContentFromStaticContent:function(){var A=this.validator.invalidate(this.contentElement);
A=this.removeUnnecessarySpaces(A);
if(A.blank()){this.rdom.clearRoot()
}else{this.rdom.getRoot().innerHTML=A
}this.rdom.wrapAllInlineOrTextNodesAs("P",this.rdom.getRoot(),true);
this.editHistory.clear();
this._fireOnCurrentContentChanged(this)
},removeUnnecessarySpaces:function(A){var C=this.rdom.tree.getBlockTags().join("|");
var B=new RegExp("\\s*<(/?)("+C+")>\\s*","img");
return A.replace(B,"<$1$2>")
},getCurrentContent:function(A){if(!A){return this.validator.validate(this.rdom.getRoot())
}var B=this.editHistory.getLastModifiedDate();
if(this._lastModified!=B){this._validContentCache=this.validator.validate(this.rdom.getRoot(),A);
this._lastModified=B
}return this._validContentCache
},setStaticContent:function(A){this.contentElement.innerHTML=A;
this._fireOnStaticContentChanged(this,A)
},getStaticContent:function(){return this.contentElement.innerHTML
},focus:function(){this.rdom.focus()
},getFrame:function(){return this.editorFrame
},getWin:function(){return this.editorWin
},getDoc:function(){return this.editorDoc
},getBody:function(){return this.editorBody
},_createEditorFrame:function(){this.editorFrame=this.doc.createElement("iframe");
this.rdom.setAttributes(this.editorFrame,{"frameBorder":"0","marginWidth":"0","marginHeight":"0","leftMargin":"0","topMargin":"0","allowTransparency":"true"});
this.contentElement.parentNode.insertBefore(this.editorFrame,this.contentElement);
var A=this.editorFrame.contentWindow.document;
A.open();
A.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">");
A.write("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ko\">");
A.write("<head>");
A.write("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\" />");
A.write("<title>XQuared</title>");
A.write("</head>");
A.write(xq.Browser.isTrident?"<body contentEditable=\"true\"><p></p></body>":"<body><p></p></body>");
A.write("</html>");
A.close();
this.editorWin=this.editorFrame.contentWindow;
this.editorDoc=this.editorWin.document;
this.editorBody=this.editorDoc.body;
this.editorBody.className="xed";
this.rdom.setWin(this.editorWin);
this.rdom.setRoot(this.editorBody);
this.editHistory=new xq.EditHistory(this.rdom)
},_registerEventHandlers:function(){var B=["keydown","click","keyup","mouseup","contextmenu","scroll"];
if(xq.Browser.isMac&&xq.Browser.isGecko){B.push("keypress")
}for(var A=0;
A<B.length;
A++){Event.observe(this.getDoc(),B[A],this._handleEvent.bindAsEventListener(this))
}},_handleEvent:function(e){this._fireOnBeforeEvent(this,e);
var stop=false;
if(e.type=="click"&&this.config.enableLinkClick){var a=this.rdom.getParentElementOf(e.target||e.srcElement,["A"]);
if(a){stop=this.handleClick(e,a)
}}else{if(e.type==(xq.Browser.isMac&&xq.Browser.isGecko?"keypress":"keydown")){this.rdom.correctParagraph();
for(var key in this.config.shortcuts){if(!this.config.shortcuts[key].event.matches(e)){continue
}var handler=this.config.shortcuts[key].handler;
var xed=this;
stop=(typeof handler=="function")?handler(this):eval(handler)
}}else{if(["mouseup","keyup","contextmenu"].include(e.type)){this.rdom.correctParagraph()
}}}var curFocusElement=this.rdom.getCurrentElement();
if(this._lastFocusElement!=curFocusElement){if(!this.rdom.tree.isBlockContainer(this._lastFocusElement)){this.rdom.removeTrailingWhitespace(this._lastFocusElement)
}this._fireOnElementChanged(this._lastFocusElement,curFocusElement);
this._lastFocusElement=curFocusElement
}if(stop){Event.stop(e)
}var historyAdded=this.editHistory.onEvent(e);
if(historyAdded){this._fireOnCurrentContentChanged(this)
}this._fireOnAfterEvent(this,e);
return !stop
},handleAutocorrection:function(){var block=this.rdom.getCurrentBlockElement();
var text=this.rdom.getInnerText(block).replace(/&nbsp;/gi," ");
var acs=this.config.autocorrections;
var performed=false;
this.editHistory.disable();
var stop=false;
for(var key in acs){var ac=acs[key];
if(ac.criteria(text)){try{if(typeof ac.handler=="String"){var xed=this;
var rdom=this.rdom;
eval(ac.handler)
}else{stop=ac.handler(this,this.rdom,block,text)
}}catch(ignored){}block=this.rdom.getCurrentBlockElement();
text=this.rdom.getInnerText(block);
performed=true;
if(stop){break
}}}this.editHistory.enable();
if(performed){this.editHistory.onCommand()
}return stop
},handleAutocompletion:function(){var acs=$H(this.config.autocompletions);
if(acs.size()==0){return 
}if(this.rdom.hasSelection()){var text=this.rdom.getSelectionAsText();
this.rdom.deleteSelection();
var wrapper=this.rdom.insertNode(this.rdom.createElement("SPAN"));
wrapper.innerHTML=text;
var marker=this.rdom.pushMarker();
var filtered=acs.map(function(pair){return[pair.key,pair.value.criteria(text)]
}.bind(this)).findAll(function(elem){return elem[1]!=-1
}).sortBy(function(elem){return elem[1]
});
if(filtered.length==0){this.rdom.popMarker(true);
return 
}var ac=acs[filtered[0][0]];
this.editHistory.disable()
}else{var marker=this.rdom.pushMarker();
var filtered=acs.map(function(pair){return[pair.key,this.rdom.testSmartWrap(marker,pair.value.criteria).textIndex]
}.bind(this)).findAll(function(elem){return elem[1]!=-1
}).sortBy(function(elem){return elem[1]
});
if(filtered.length==0){this.rdom.popMarker(true);
return 
}var ac=acs[filtered[0][0]];
this.editHistory.disable();
var wrapper=this.rdom.smartWrap(marker,"SPAN",ac.criteria)
}var block=this.rdom.getCurrentBlockElement();
var text=this.rdom.getInnerText(wrapper).replace(/&nbsp;/gi," ");
try{if(typeof ac.handler=="String"){var xed=this;
var rdom=this.rdom;
eval(ac.handler)
}else{ac.handler(this,this.rdom,block,wrapper,text)
}}catch(ignored){}try{this.rdom.unwrapElement(wrapper)
}catch(ignored){}if(this.rdom.isEmptyBlock(block)){this.rdom.correctEmptyElement(block)
}this.editHistory.enable();
this.editHistory.onCommand();
this.rdom.popMarker(true)
},handleClick:function(C,B){var A=decodeURI(B.href);
if(!xq.Browser.isTrident){if(!C.ctrlKey&&!C.shiftKey&&C.button!=1){window.location.href=A;
return true
}}else{if(C.shiftKey){window.open(A,"_blank")
}else{window.location.href=A
}return true
}return false
},handleEnter:function(D,G){if(this.rdom.hasSelection()){return false
}if(!D&&this.handleAutocorrection()){return true
}var B=this.rdom.isCaretAtEmptyBlock();
var A=B||this.rdom.isCaretAtBlockStart();
var H=B||(!A&&this.rdom.isCaretAtBlockEnd());
var C=B||A||H;
if(!C){var E=this.rdom.getCurrentBlockElement();
var F=this.rdom.pushMarker();
if(this.rdom.isFirstLiWithNestedList(E)&&!G){var I=E.parentNode;
this.rdom.unwrapElement(E);
E=I
}else{if(E.nodeName!="LI"&&this.rdom.tree.isBlockContainer(E)){E=this.rdom.wrapAllInlineOrTextNodesAs("P",E,true).first()
}}this.rdom.splitElementUpto(F,E);
this.rdom.popMarker(true)
}else{if(B){this._handleEnterAtEmptyBlock()
}else{this._handleEnterAtEdge(A,G)
}}return true
},handleMoveBlock:function(A){var C=this.rdom.moveBlock(this.rdom.getCurrentBlockElement(),A);
if(C){this.rdom.selectElement(C,false);
C.scrollIntoView(false);
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}}return true
},handleTab:function(){var A=this.rdom.hasSelection();
if(A){this.handleIndent()
}else{if(this.rdom.getParentElementOf(this.rdom.getCurrentBlockElement(),["TD","TH"])){this.handleMoveToNextCell()
}else{if(this.rdom.isCaretAtBlockStart()){this.handleIndent()
}else{this.handleInsertTab()
}}}return true
},handleInsertTab:function(){this.rdom.insertHtml("&nbsp;");
this.rdom.insertHtml("&nbsp;");
this.rdom.insertHtml("&nbsp;");
return true
},handleShiftTab:function(){var A=this.rdom.hasSelection();
if(A){this.handleOutdent()
}else{if(this.rdom.getParentElementOf(this.rdom.getCurrentBlockElement(),["TD","TH"])){this.handleMoveToPreviousCell()
}else{this.handleOutdent()
}}return true
},handleDelete:function(){if(this.rdom.hasSelection()||!this.rdom.isCaretAtBlockEnd()){return false
}return this._handleMerge(true)
},handleBackspace:function(){if(this.rdom.hasSelection()||!this.rdom.isCaretAtBlockStart()){return false
}return this._handleMerge(false)
},_handleMerge:function(C){var E=this.rdom.getCurrentBlockElement();
var B=this.rdom.pushMarker();
var A=this.rdom.mergeElement(E,C,C)||this.rdom.extractOutElementFromParent(E)||E;
this.rdom.popMarker(true);
this.rdom.correctEmptyElement(A);
var D=this.editHistory.onCommand();
if(D){this._fireOnCurrentContentChanged(this)
}return true
},handleMoveToNextCell:function(){this._handleMoveToCell("next")
},handleMoveToPreviousCell:function(){this._handleMoveToCell("prev")
},handleMoveToAboveCell:function(){this._handleMoveToCell("above")
},handleMoveToBelowCell:function(){this._handleMoveToCell("below")
},_handleMoveToCell:function(B){var C=this.rdom.getCurrentBlockElement();
var H=this.rdom.getParentElementOf(C,["TD","TH"]);
var J=this.rdom.getParentElementOf(H,["TABLE"]);
var I=new xq.RichTable(this.rdom,J);
var E=null;
if(["next","prev"].include(B)){var G=B=="next";
E=G?I.getNextCellOf(H):I.getPreviousCellOf(H)
}else{var F=B=="below";
E=F?I.getBelowCellOf(H):I.getAboveCellOf(H)
}if(!E){var A=function(K){return !["TD","TH"].include(K.nodeName)&&this.tree.isBlock(K)&&!this.tree.hasBlocks(K)
}.bind(this.rdom);
var D=function(K){return this.tree.isBlock(K)&&!this.tree.isDescendantOf(this.getRoot(),K)
}.bind(this.rdom);
E=(G||F)?this.rdom.tree.findForward(H,A,D):this.rdom.tree.findBackward(J,A,D)
}if(E){this.rdom.placeCaretAtStartOf(E)
}},handleStrongEmphasis:function(){this.rdom.applyStrongEmphasis();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleEmphasis:function(){this.rdom.applyEmphasis();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleUnderline:function(){this.rdom.applyUnderline();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleStrike:function(){this.rdom.applyStrike();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleQuote:function(){this.rdom.applyQuote();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleRemoveFormat:function(){this.rdom.applyRemoveFormat();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleTable:function(F,E,C){var H=this.rdom.getCurrentBlockElement();
if(this.rdom.getParentElementOf(H,["TABLE"])){return true
}var B=xq.RichTable.create(this.rdom,F,E,C);
if(this.rdom.tree.isBlockContainer(H)){var D=this.rdom.wrapAllInlineOrTextNodesAs("P",H,true);
H=D.last()
}var A=this.rdom.insertNodeAt(B.getDom(),H,"after");
this.rdom.placeCaretAtStartOf(B.getCellAt(0,0));
if(this.rdom.isEmptyBlock(H)){this.rdom.deleteNode(H,true)
}var G=this.editHistory.onCommand();
if(G){this._fireOnCurrentContentChanged(this)
}return true
},handleInsertNewRowAt:function(A){var F=this.rdom.getCurrentBlockElement();
var D=this.rdom.getParentElementOf(F,["TR"]);
if(!D){return true
}var C=this.rdom.getParentElementOf(D,["TABLE"]);
var B=new xq.RichTable(this.rdom,C);
var E=B.insertNewRowAt(D,A);
this.rdom.placeCaretAtStartOf(E.cells[0]);
return true
},handleInsertNewColumnAt:function(A){var D=this.rdom.getCurrentBlockElement();
var E=this.rdom.getParentElementOf(D,["TD"],true);
if(!E){return true
}var C=this.rdom.getParentElementOf(E,["TABLE"]);
var B=new xq.RichTable(this.rdom,C);
B.insertNewCellAt(E,A);
this.rdom.placeCaretAtStartOf(D);
return true
},handleDeleteRow:function(){var E=this.rdom.getCurrentBlockElement();
var C=this.rdom.getParentElementOf(E,["TR"]);
if(!C){return true
}var B=this.rdom.getParentElementOf(C,["TABLE"]);
var A=new xq.RichTable(this.rdom,B);
var D=A.deleteRow(C);
this.rdom.placeCaretAtStartOf(D);
return true
},handleDeleteColumn:function(){var C=this.rdom.getCurrentBlockElement();
var D=this.rdom.getParentElementOf(C,["TD"],true);
if(!D){return true
}var B=this.rdom.getParentElementOf(D,["TABLE"]);
var A=new xq.RichTable(this.rdom,B);
A.deleteCell(D);
return true
},handleIndent:function(){if(this.rdom.hasSelection()){var C=this.rdom.getBlockElementsAtSelectionEdge(true,true);
if(C.first()!=C.last()){var D=this.rdom.indentElements(C.first(),C.last());
this.rdom.selectBlocksBetween(D.first(),D.last());
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
}}var A=this.rdom.getCurrentBlockElement();
var D=this.rdom.indentElement(A);
if(D){this.rdom.placeCaretAtStartOf(D);
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}}return true
},handleOutdent:function(){if(this.rdom.hasSelection()){var C=this.rdom.getBlockElementsAtSelectionEdge(true,true);
if(C.first()!=C.last()){var D=this.rdom.outdentElements(C.first(),C.last());
this.rdom.selectBlocksBetween(D.first(),D.last());
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
}}var A=this.rdom.getCurrentBlockElement();
var D=this.rdom.outdentElement(A);
if(D){this.rdom.placeCaretAtStartOf(D);
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}}return true
},handleList:function(A){if(this.rdom.hasSelection()){var D=this.rdom.getBlockElementsAtSelectionEdge(true,true);
if(D.first()!=D.last()){D=this.rdom.applyLists(D.first(),D.last(),A)
}else{D[0]=D[1]=this.rdom.applyList(D.first(),A)
}this.rdom.selectBlocksBetween(D.first(),D.last())
}else{var C=this.rdom.applyList(this.rdom.getCurrentBlockElement(),A);
this.rdom.placeCaretAtStartOf(C)
}var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
},handleJustify:function(A){var D=this.rdom.getCurrentBlockElement();
var A=(A=="left"||A=="both")&&(D.style.textAlign=="left"||D.style.textAlign=="")?"both":A;
if(this.rdom.hasSelection()){var C=this.rdom.getSelectedBlockElements();
this.rdom.justifyBlocks(C,A);
this.rdom.selectBlocksBetween(C.first(),C.last())
}else{this.rdom.justifyBlock(D,A)
}var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
},handleRemoveBlock:function(){var B=this.rdom.getCurrentBlockElement();
var A=this.rdom.removeBlock(B);
this.rdom.placeCaretAtStartOf(A);
A.scrollIntoView(false)
},handleBackgroundColor:function(A){this.rdom.applyBackgroundColor(A);
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
},handleForegroundColor:function(A){this.rdom.applyForegroundColor(A);
var B=this.editHistory.onCommand();
if(B){this._fireOnCurrentContentChanged(this)
}return true
},handleSuperscription:function(){this.rdom.applySuperscription();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleSubscription:function(){this.rdom.applySubscription();
var A=this.editHistory.onCommand();
if(A){this._fireOnCurrentContentChanged(this)
}return true
},handleApplyBlock:function(A){if(this.rdom.hasSelection()){var E=this.rdom.getBlockElementsAtSelectionEdge(true,true);
if(E.first()!=E.last()){var B=this.rdom.applyTagIntoElements(A,E.first(),E.last());
this.rdom.selectBlocksBetween(B.first(),B.last());
var D=this.editHistory.onCommand();
if(D){this._fireOnCurrentContentChanged(this)
}return true
}}var C=this.rdom.getCurrentBlockElement();
this.rdom.pushMarker();
var B=this.rdom.applyTagIntoElement(A,C)||C;
this.rdom.popMarker(true);
if(this.rdom.isEmptyBlock(B)){this.rdom.correctEmptyElement(B);
this.rdom.placeCaretAtStartOf(B)
}var D=this.editHistory.onCommand();
if(D){this._fireOnCurrentContentChanged(this)
}return true
},handleSeparator:function(){this.rdom.collapseSelection();
var E=this.rdom.getCurrentBlockElement();
if(this.rdom.tree.isBlockContainer(E)){E=this.rdom.wrapAllInlineOrTextNodesAs("P",E,true)[0]
}var B=this.rdom.pushMarker();
var D=this.rdom.splitElementUpto(B,E);
this.rdom.popMarker();
this.rdom.correctEmptyElement(D);
var A=this.rdom.insertNodeAt(this.rdom.createElement("P"),D,"before");
A.appendChild(this.rdom.createElement("HR"));
if(this.rdom.isEmptyBlock(E)){this.rdom.deleteNode(E,true)
}this.rdom.placeCaretAtStartOf(D);
var C=this.editHistory.onCommand();
if(C){this._fireOnCurrentContentChanged(this)
}return true
},handleUndo:function(){var A=this.editHistory.undo();
if(A){this._fireOnCurrentContentChanged(this)
}this.rdom.getCurrentBlockElement().scrollIntoView(false);
return true
},handleRedo:function(){var A=this.editHistory.redo();
if(A){this._fireOnCurrentContentChanged(this)
}this.rdom.getCurrentBlockElement().scrollIntoView(false);
return true
},addContextMenuHandler:function(A){if(!this._contextMenuEnabled){Event.observe(this.getDoc(),"contextmenu",this.onContextMenu.bindAsEventListener(this));
this._contextMenuEnabled=true
}this._contextMenuHandler=A
},onContextMenu:function(C){if(xq.Browser.isWebkit){if(C.metaKey||Event.isLeftClick(C)){return false
}}else{if(C.shiftKey||C.ctrlKey||C.altKey){return false
}}if(this._contextMenuHandler){var A=Event.pointerX(C);
var F=Event.pointerY(C);
var E=Position.cumulativeOffset(this.getFrame());
A+=E[0];
F+=E[1];
this._contextMenuTargetElement=C.target||C.srcElement;
if(!A||!F||xq.Browser.isTrident){var E=Position.cumulativeOffset(this._contextMenuTargetElement);
var D=Position.cumulativeOffset(this.getFrame());
A=E[0]+D[0]-this.getDoc().documentElement.scrollLeft;
F=E[1]+D[1]-this.getDoc().documentElement.scrollTop
}if(!xq.Browser.isTrident){A-=this.getDoc().documentElement.scrollLeft;
F-=this.getDoc().documentElement.scrollTop
}var B=this._contextMenuHandler(this,this._contextMenuTargetElement,A,F);
if(B){Event.stop(C)
}return B
}return false
},showContextMenu:function(C,A,D){if(!C||C.length<=0){return 
}if(!this._contextMenuContainer){this._contextMenuContainer=this.doc.createElement("UL");
this._contextMenuContainer.className="xqContextMenu";
this._contextMenuContainer.style.display="none";
Event.observe(this.doc,"click",this._contextMenuClicked.bindAsEventListener(this));
Event.observe(this.rdom.getDoc(),"click",this.hideContextMenu.bindAsEventListener(this));
this.body.appendChild(this._contextMenuContainer)
}else{while(this._contextMenuContainer.childNodes.length>0){this._contextMenuContainer.removeChild(this._contextMenuContainer.childNodes[0])
}}for(var B=0;
B<C.length;
B++){C[B]._node=this._addContextMenuItem(C[B])
}this._contextMenuContainer.style.display="block";
this._contextMenuContainer.style.left=Math.min(Math.max(this.doc.body.scrollWidth,this.doc.documentElement.clientWidth)-this._contextMenuContainer.offsetWidth,A)+"px";
this._contextMenuContainer.style.top=Math.min(Math.max(this.doc.body.scrollHeight,this.doc.documentElement.clientHeight)-this._contextMenuContainer.offsetHeight,D)+"px";
this._contextMenuItems=C
},hideContextMenu:function(){if(this._contextMenuContainer){this._contextMenuContainer.style.display="none"
}},_addContextMenuItem:function(B){if(!this._contextMenuContainer){throw"No conext menu container exists"
}var A=this.doc.createElement("LI");
if(B.disabled){A.className+=" disabled"
}if(B.title=="----"){A.innerHTML="&nbsp;";
A.className="separator"
}else{if(B.handler){A.innerHTML="<a href=\"javascript:;\" onclick=\"return false;\">"+(B.title.toString().escapeHTML())+"</a>"
}else{A.innerHTML=(B.title.toString().escapeHTML())
}}if(B.className){A.className=B.className
}this._contextMenuContainer.appendChild(A);
return A
},_contextMenuClicked:function(e){this.hideContextMenu();
if(!this._contextMenuContainer){return 
}var node=Event.findElement(e,"LI");
if(!node||!this.rdom.tree.isDescendantOf(this._contextMenuContainer,node)){return 
}for(var i=0;
i<this._contextMenuItems.length;
i++){if(this._contextMenuItems[i]._node==node){var handler=this._contextMenuItems[i].handler;
if(!this._contextMenuItems[i].disabled&&handler){var xed=this;
var element=this._contextMenuTargetElement;
if(typeof handler=="function"){handler(xed,element)
}else{eval(handler)
}}break
}}},insertTemplate:function(A){this.rdom.insertHtml(this._processTemplate(A))
},insertTemplateAt:function(B,C,A){this.rdom.insertHtml(this._processTemplate(B),C,A)
},_processTemplate:function(B){var C=$H(this.getTemplateProcessors()).values();
for(var A=0;
A<C.length;
A++){B=C[A].handler(B)
}return B=this.removeUnnecessarySpaces(B)
},insertMacro:function(B){var A=xq.Macro.create(B,this.rdom.getWin());
A.insertElement();
var C=this.getDoc();
if(xq.Browser.isGecko){this.rdom.pushMarker();
this.getDoc().designMode="Off"
}A.execute();
if(xq.Browser.isGecko){window.setTimeout(function(){this.getDoc().designMode="On";
this.rdom.popMarker(true)
}.bind(this),0)
}},execMacro:function(B){var A=xq.Macro.load(B);
A.execute()
},findMacroContainers:function(){return document.getElementsByClassName("xqMacro")
},_handleEnterAtEmptyBlock:function(){var A=this.rdom.getCurrentBlockElement();
A=this.rdom.outdentElement(A)||this.rdom.extractOutElementFromParent(A)||this.rdom.replaceTag("P",A)||this.rdom.insertNewBlockAround(A);
this.rdom.placeCaretAtStartOf(A);
A.scrollIntoView(false)
},_handleEnterAtEdge:function(B,A){var C=this.rdom.getCurrentBlockElement();
if(this.rdom.tree.isTableCell(C)){A=true
}var D=this.rdom.insertNewBlockAround(C,B,A?"P":null);
if(!B){this.rdom.placeCaretAtStartOf(D);
D.scrollIntoView(false)
}else{this.rdom.placeCaretAtStartOf(D.nextSibling);
D.nextSibling.scrollIntoView(false)
}}};
xq.Browser={isTrident:navigator.appName=="Microsoft Internet Explorer",isWebkit:navigator.userAgent.indexOf("AppleWebKit/")>-1,isGecko:navigator.userAgent.indexOf("Gecko")>-1&&navigator.userAgent.indexOf("KHTML")==-1,isKHTML:navigator.userAgent.indexOf("KHTML")!=-1,isPresto:navigator.appName=="Opera",isMac:navigator.userAgent.indexOf("Macintosh")!=-1,isUbuntu:navigator.userAgent.indexOf("Ubuntu")!=-1};
xq.Shortcut=function(A){this.keymap=(typeof A=="string")?xq.Shortcut.interprete(A).keymap:A
};
xq.Shortcut.prototype.matches=function(A){var B=xq.Browser.isGecko&&xq.Browser.isMac?(A.keyCode+"_"+A.charCode):A.keyCode;
var D=(this.keymap.which==B)||(this.keymap.which==32&&B==25);
if(typeof A.metaKey=="undefined"){A.metaKey=false
}var C=(typeof this.keymap.shiftKey=="undefined"||this.keymap.shiftKey==A.shiftKey)&&(typeof this.keymap.altKey=="undefined"||this.keymap.altKey==A.altKey)&&(typeof this.keymap.ctrlKey=="undefined"||this.keymap.ctrlKey==A.ctrlKey)&&(typeof this.keymap.metaKey=="undefined"||this.keymap.metaKey==A.metaKey);
return C&&D
};
xq.Shortcut.interprete=function(G){G=G.toUpperCase();
var F=xq.Shortcut._interpreteWhich(G.split("+").pop());
var E=xq.Shortcut._interpreteModifier(G,"CTRL");
var C=xq.Shortcut._interpreteModifier(G,"ALT");
var B=xq.Shortcut._interpreteModifier(G,"SHIFT");
var D=xq.Shortcut._interpreteModifier(G,"META");
var A={};
A.which=F;
if(typeof E!="undefined"){A.ctrlKey=E
}if(typeof C!="undefined"){A.altKey=C
}if(typeof B!="undefined"){A.shiftKey=B
}if(typeof D!="undefined"){A.metaKey=D
}return new xq.Shortcut(A)
};
xq.Shortcut._interpreteModifier=function(A,B){return A.match("\\("+B+"\\)")?undefined:A.match(B)?true:false
};
xq.Shortcut._keyNames=xq.Browser.isMac&&xq.Browser.isGecko?{BACKSPACE:"8_0",TAB:"9_0",RETURN:"13_0",ENTER:"13_0",ESC:"27_0",SPACE:"0_32",LEFT:"37_0",UP:"38_0",RIGHT:"39_0",DOWN:"40_0",DELETE:"46_0",HOME:"36_0",END:"35_0",PAGEUP:"33_0",PAGEDOWN:"34_0",COMMA:"0_44",HYPHEN:"0_45",EQUAL:"0_61",PERIOD:"0_46",SLASH:"0_47",F1:"112_0",F2:"113_0",F3:"114_0",F4:"115_0",F5:"116_0",F6:"117_0",F7:"118_0",F8:"119_0"}:{BACKSPACE:8,TAB:9,RETURN:13,ENTER:13,ESC:27,SPACE:32,LEFT:37,UP:38,RIGHT:39,DOWN:40,DELETE:46,HOME:36,END:35,PAGEUP:33,PAGEDOWN:34,COMMA:188,HYPHEN:xq.Browser.isTrident?189:109,EQUAL:xq.Browser.isTrident?187:61,PERIOD:190,SLASH:191,F1:112,F2:113,F3:114,F4:115,F5:116,F6:117,F7:118,F8:119,F9:120,F10:121,F11:122,F12:123};
xq.Shortcut._interpreteWhich=function(A){var B=A.length==1?((xq.Browser.isMac&&xq.Browser.isGecko)?"0_"+A.toLowerCase().charCodeAt(0):A.charCodeAt(0)):xq.Shortcut._keyNames[A];
if(typeof B=="undefined"){throw"Unknown special key name: ["+A+"]"
}return B
};
xq.DomTree=Class.create();
xq.DomTree.prototype={initialize:function(){this._blockTags=["DIV","DD","LI","ADDRESS","CAPTION","DT","H1","H2","H3","H4","H5","H6","P","BODY","BLOCKQUOTE","PRE","PARAM","DL","OL","UL","TABLE","THEAD","TBODY","TR","TH","TD"];
this._blockContainerTags=["DIV","DD","LI","BODY","BLOCKQUOTE","UL","OL","DL","TABLE","THEAD","TBODY","TR","TH","TD"];
this._listContainerTags=["OL","UL","DL"];
this._tableCellTags=["TH","TD"];
this._blockOnlyContainerTags=["BODY","BLOCKQUOTE"];
this._atomicTags=["IMG","OBJECT","BR","HR"]
},getBlockTags:function(){return this._blockTags
},findCommonAncestorAndImmediateChildrenOf:function(E,C){if(E.parentNode==C.parentNode){return{left:E,right:C,parent:E.parentNode}
}else{var D=this.collectParentsOf(E,true);
var G=this.collectParentsOf(C,true);
var B=this.getCommonAncestor(D,G);
var F=D.find(function(H){return H.parentNode==B
});
var A=G.find(function(H){return H.parentNode==B
});
return{left:F,right:A,parent:B}
}},getLeavesAtEdge:function(C){if(!C.hasChildNodes()){return[null,null]
}var D=function(G){for(var F=0;
F<G.childNodes.length;
F++){if(G.childNodes[F].nodeType==1&&this.isBlock(G.childNodes[F])){return D(G.childNodes[F])
}}return G
}.bind(this);
var B=function(G){for(var F=G.childNodes.length;
F--;
){if(G.childNodes[F].nodeType==1&&this.isBlock(G.childNodes[F])){return B(G.childNodes[F])
}}return G
}.bind(this);
var E=D(C);
var A=B(C);
return[E==C?null:E,A==C?null:A]
},getCommonAncestor:function(B,A){for(var D=0;
D<B.length;
D++){for(var C=0;
C<A.length;
C++){if(B[D]==A[C]){return B[D]
}}}},collectParentsOf:function(C,B){var A=[];
if(B){A.push(C)
}while((C=C.parentNode)&&(C.nodeName!="HTML")){A.push(C)
}return A
},isDescendantOf:function(B,C){if(B.length>0){for(var A=0;
A<B.length;
A++){if(this.isDescendantOf(B[A],C)){return true
}}return false
}if(B==C){return false
}while(C=C.parentNode){if(C==B){return true
}}return false
},walkForward:function(A){if(A.hasChildNodes()){return A.firstChild
}if(A.nextSibling){return A.nextSibling
}while(A=A.parentNode){if(A.nextSibling){return A.nextSibling
}}return null
},walkBackward:function(A){if(A.previousSibling){A=A.previousSibling;
while(A.hasChildNodes()){A=A.lastChild
}return A
}return A.parentNode
},walkNext:function(A){return A.nextSibling
},walkPrev:function(A){return A.previousSibling
},checkTargetForward:function(B,A){return this._check(B,this.walkForward,A)
},checkTargetBackward:function(B,A){return this._check(B,this.walkBackward,A)
},findForward:function(C,B,A){return this._find(C,this.walkForward,B,A)
},findBackward:function(C,B,A){return this._find(C,this.walkBackward,B,A)
},_check:function(C,B,A){if(C==A){return false
}while(C=B(C)){if(C==A){return true
}}return false
},_find:function(D,B,C,A){while(D=B(D)){if(A&&A(D)){return null
}if(C(D)){return D
}}return null
},collectNodesBetween:function(D,A,C){if(D==A){return[D,A].findAll(C||function(){return true
})
}var B=this.collectForward(D,function(E){return E==A
},C);
if(D!=A&&typeof C=="function"&&C(A)){B.push(A)
}return B
},collectForward:function(C,A,B){return this.collect(C,this.walkForward,A,B)
},collectBackward:function(C,A,B){return this.collect(C,this.walkBackward,A,B)
},collectNext:function(C,A,B){return this.collect(C,this.walkNext,A,B)
},collectPrev:function(C,A,B){return this.collect(C,this.walkPrev,A,B)
},collect:function(E,D,A,C){var B=[E];
while(true){E=D(E);
if((E==null)||(typeof A=="function"&&A(E))){break
}B.push(E)
}return(typeof C=="function")?B.findAll(C):B
},hasBlocks:function(C){var A=C.childNodes;
for(var B=0;
B<A.length;
B++){if(this.isBlock(A[B])){return true
}}return false
},hasMixedContents:function(C){if(!this.isBlock(C)){return false
}if(!this.isBlockContainer(C)){return false
}var A=false;
var E=false;
for(var B=0;
B<C.childNodes.length;
B++){var D=C.childNodes[B];
if(!A&&this.isTextOrInlineNode(D)){A=true
}if(!E&&this.isBlock(D)){E=true
}if(A&&E){break
}}if(!A||!E){return false
}return true
},isBlockOnlyContainer:function(A){if(!A){return false
}return this._blockOnlyContainerTags.include(typeof A=="string"?A:A.nodeName)
},isTableCell:function(A){if(!A){return false
}return this._tableCellTags.include(typeof A=="string"?A:A.nodeName)
},isBlockContainer:function(A){if(!A){return false
}return this._blockContainerTags.include(typeof A=="string"?A:A.nodeName)
},isHeading:function(A){if(!A){return false
}return(typeof A=="string"?A:A.nodeName).match(/H\d/)
},isBlock:function(A){if(!A){return false
}return this._blockTags.include(typeof A=="string"?A:A.nodeName)
},isAtomic:function(A){if(!A){return false
}return this._atomicTags.include(typeof A=="string"?A:A.nodeName)
},isListContainer:function(A){if(!A){return false
}return this._listContainerTags.include(typeof A=="string"?A:A.nodeName)
},isTextOrInlineNode:function(A){return A&&(A.nodeType==3||!this.isBlock(A))
}};
xq.RichDom=Class.create();
xq.RichDom.prototype={initialize:function(){this.tree=new xq.DomTree();
this._lastMarkerId=0
},setWin:function(A){if(!A){throw"[win] is null"
}this.win=A
},setRoot:function(A){if(!A){throw"[root] is null"
}if(this.win&&(A.ownerDocument!=this.win.document)){throw"root.ownerDocument != this.win.document"
}this.root=A;
this.doc=this.root.ownerDocument
},getWin:function(){return this.win
},getDoc:function(){return this.doc
},getRoot:function(){return this.root
},clearRoot:function(){this.root.innerHTML="";
this.root.appendChild(this.makeEmptyParagraph())
},removePlaceHoldersAndEmptyNodes:function(A){var C=A;
while(C){var B=this.tree.walkForward(C);
if(this.isPlaceHolder(C)||(C.nodeType==3&&C.nodeValue=="")){this.deleteNode(C)
}C=B
}},setAttributes:function(A,B){for(key in B){A.setAttribute(key,B[key])
}},createTextNode:function(A){return this.doc.createTextNode(A)
},createElement:function(A){return this.doc.createElement(A)
},createElementFromHtml:function(A){var B=this.createElement("div");
B.innerHTML=A;
if(B.childNodes.length!=1){throw"Illegal HTML fragment"
}return this.getFirstChildOf(B)
},deleteNode:function(D,A,C){if(!D||!D.parentNode){return 
}var B=D.parentNode;
B.removeChild(D);
if(A){while(!B.hasChildNodes()){D=B;
B=D.parentNode;
if(!B||this.getRoot()==D){break
}B.removeChild(D)
}}if(C&&this.isEmptyBlock(B)){B.innerHTML="";
this.correctEmptyElement(B)
}},insertNode:function(A){throw"Not implemented"
},insertHtml:function(A){return this.insertNode(this.createElementFromHtml(A))
},insertText:function(A){this.insertNode(this.createTextNode(A))
},insertNodeAt:function(B,F,E,D){if(["HTML","HEAD"].include(F.nodeName)||["BODY"].include(F.nodeName)&&["before","after"].include(E)){throw"Illegal argument. Cannot move node["+B.nodeName+"] to '"+E+"' of target["+F.nodeName+"]"
}var C;
var I;
var G;
switch(E.toLowerCase()){case"before":C=F.parentNode;
I="insertBefore";
G=F;
break;
case"start":if(F.firstChild){C=F;
I="insertBefore";
G=F.firstChild
}else{C=F;
I="appendChild"
}break;
case"end":C=F;
I="appendChild";
break;
case"after":if(F.nextSibling){C=F.parentNode;
I="insertBefore";
G=F.nextSibling
}else{C=F.parentNode;
I="appendChild"
}break
}if(D&&this.tree.isListContainer(C)&&B.nodeName!="LI"){var H=this.createElement("LI");
H.appendChild(B);
B=H;
C[I](B,G)
}else{if(D&&!this.tree.isListContainer(C)&&B.nodeName=="LI"){this.wrapAllInlineOrTextNodesAs("P",B,true);
var A=this.createElement("DIV");
this.moveChildNodes(B,A);
this.deleteNode(B);
C[I](A,G);
B=this.unwrapElement(A,true)
}else{C[I](B,G)
}}return B
},insertTextAt:function(C,B,A){return this.insertNodeAt(this.createTextNode(C),B,A)
},insertHtmlAt:function(B,C,A){return this.insertNodeAt(this.createElementFromHtml(B),C,A)
},replaceTag:function(A,B){if(B.nodeName==A){return null
}if(this.tree.isTableCell(B)){return null
}var C=this.createElement(A);
this.moveChildNodes(B,C);
this.copyAttributes(B,C,true);
B.parentNode.replaceChild(C,B);
if(!C.hasChildNodes()){this.correctEmptyElement(C)
}return C
},unwrapUnnecessaryParagraph:function(A){if(!A){return false
}if(!this.tree.isBlockOnlyContainer(A)&&A.childNodes.length==1&&A.firstChild.nodeName=="P"&&!this.hasImportantAttributes(A.firstChild)){var B=A.firstChild;
this.moveChildNodes(B,A);
this.deleteNode(B);
return true
}return false
},unwrapElement:function(B,A){if(A){this.wrapAllInlineOrTextNodesAs("P",B)
}var C=B.firstChild;
while(B.firstChild){this.insertNodeAt(B.firstChild,B,"before")
}this.deleteNode(B);
return C
},wrapElement:function(A,B){var C=this.insertNodeAt(this.createElement(A),B,"before");
C.appendChild(B);
return C
},testSmartWrap:function(A,B){return this.smartWrap(A,null,B,true)
},smartWrap:function(G,S,F,R){var H=this.getParentBlockElementOf(G);
S=S||"SPAN";
F=F||function(T){return -1
};
if(!R&&(!G.previousSibling||this.isEmptyBlock(H))){var E=this.insertNodeAt(this.createElement(S),G,"before");
return E
}var B=this.tree.collectForward(H,function(T){return T==G
},function(T){return T.nodeType==3
});
var M=0;
var Q=B.pluck("nodeValue");
var P=Q.join("");
var N=F(P);
var C=N;
if(C==-1){C=0
}else{P=P.substring(C)
}for(var L=0;
L<B.length;
L++){if(C>Q[L].length){C-=Q[L].length
}else{M=L;
break
}}if(R){return{text:P,textIndex:N,nodeIndex:M,breakPoint:C}
}if(C!=0){var I=B[M].splitText(C);
M++;
B.splice(M,0,I)
}var A=B[M]||H.firstChild;
var O=this.tree.findCommonAncestorAndImmediateChildrenOf(A,G);
var K=O.parent;
if(K){if(A.parentNode!=K){A=this.splitElementUpto(A,K,true)
}if(G.parentNode!=K){G=this.splitElementUpto(G,K,true)
}var D=A.previousSibling;
var J=G.nextSibling;
if(D&&D.nodeType==1&&this.isEmptyBlock(D)){this.deleteNode(D)
}if(J&&J.nodeType==1&&this.isEmptyBlock(J)){this.deleteNode(J)
}var E=this.insertNodeAt(this.createElement(S),A,"before");
while(E.nextSibling!=G){E.appendChild(E.nextSibling)
}return E
}else{var E=this.insertNodeAt(this.createElement(S),G,"before");
return E
}},wrapAllInlineOrTextNodesAs:function(A,B,E){var D=[];
if(!E&&!this.tree.hasMixedContents(B)){return D
}var C=B.firstChild;
while(C){if(this.tree.isTextOrInlineNode(C)){var F=this.wrapInlineOrTextNodesAs(A,C);
D.push(F);
C=F.nextSibling
}else{C=C.nextSibling
}}return D
},wrapInlineOrTextNodesAs:function(A,B){var D=this.createElement(A);
var C=B;
C.parentNode.replaceChild(D,C);
D.appendChild(C);
while(D.nextSibling&&this.tree.isTextOrInlineNode(D.nextSibling)){D.appendChild(D.nextSibling)
}return D
},turnElementIntoListItem:function(C,D){D=D.toUpperCase();
var B=this.insertNodeAt(this.createElement(D=="UL"?"UL":"OL"),C,"after");
if(D=="CODE"){B.className="code"
}var A=this.insertNodeAt(this.createElement("LI"),B,"start");
A.appendChild(C);
this.unwrapUnnecessaryParagraph(A);
this.mergeAdjustLists(B);
return A
},extractOutElementFromParent:function(B){if(B==this.root||this.root==B.parentNode||!B.offsetParent){return null
}if(B.nodeName=="LI"){this.wrapAllInlineOrTextNodesAs("P",B,true);
B=B.firstChild
}var A=B.parentNode;
var D=null;
if(A.nodeName=="LI"&&A.parentNode.parentNode.nodeName=="LI"){if(B.previousSibling){this.splitContainerOf(B,true);
this.correctEmptyElement(B)
}this.outdentListItem(B);
D=B
}else{if(A.nodeName=="LI"){if(this.tree.isListContainer(B.nextSibling)){var E=A.parentNode;
this.splitContainerOf(A,true);
this.correctEmptyElement(B);
D=A.firstChild;
while(A.firstChild){this.insertNodeAt(A.firstChild,E,"before")
}var C=E.previousSibling;
this.deleteNode(E);
if(C&&this.tree.isListContainer(C)){this.mergeAdjustLists(C)
}}else{this.splitContainerOf(B,true);
this.correctEmptyElement(B);
var E=this.splitContainerOf(A);
this.insertNodeAt(B,E.parentNode,"before");
this.deleteNode(E.parentNode);
D=B
}}else{if(this.tree.isTableCell(A)||this.tree.isTableCell(B)){}else{this.splitContainerOf(B,true);
this.correctEmptyElement(B);
D=this.insertNodeAt(B,A,"before");
this.deleteNode(A)
}}}return D
},insertNewBlockAround:function(E,D,B){var C=E.nodeName=="LI"||E.parentNode.nodeName=="LI";
this.removeTrailingWhitespace(E);
if(C&&!B){var A=this.getParentElementOf(E,["LI"]);
var F=this._insertNewBlockAround(E,D);
if(A!=E){F=this.splitContainerOf(F,false,"prev")
}return F
}else{if(this.tree.isBlockContainer(E)){this.wrapAllInlineOrTextNodesAs("P",E,true);
return this._insertNewBlockAround(E.firstChild,D,B)
}else{return this._insertNewBlockAround(E,D,this.tree.isHeading(E)?"P":B)
}}},_insertNewBlockAround:function(B,C,A){var D=this.createElement(A||B.nodeName);
this.copyAttributes(B,D,false);
this.correctEmptyElement(D);
D=this.insertNodeAt(D,B,C?"before":"after");
return D
},applyTagIntoElement:function(A,B){if(this.tree.isBlockOnlyContainer(A)){return this.wrapBlock(A,B)
}else{if(this.tree.isBlockContainer(B)){var C=this.createElement(A);
this.moveChildNodes(B,C);
return this.insertNodeAt(C,B,"start")
}else{if(this.tree.isBlockContainer(A)&&this.hasImportantAttributes(B)){return this.wrapBlock(A,B)
}else{return this.replaceTag(A,B)
}}}throw"IllegalArgumentException - ["+A+", "+B+"]"
},applyTagIntoElements:function(C,I,J){var E=[];
if(this.tree.isBlockContainer(C)){var G=this.tree.findCommonAncestorAndImmediateChildrenOf(I,J);
var D=G.left;
var B=this.insertNodeAt(this.createElement(C),D,"before");
var K=G.parent.nodeName=="LI"&&G.parent.parentNode.childNodes.length==1&&!G.left.previousSilbing&&!G.right.nextSibling;
if(K){var H=D.parentNode.parentNode;
this.insertNodeAt(B,H,"before");
B.appendChild(H)
}else{while(D!=G.right){next=D.nextSibling;
B.appendChild(D);
D=next
}B.appendChild(G.right)
}E.push(B)
}else{var A=this.getBlockElementsBetween(I,J);
for(var F=0;
F<A.length;
F++){if(this.tree.isBlockContainer(A[F])){E.push(this.wrapAllInlineOrTextNodesAs(C,A[F],true))
}else{E.push(this.replaceTag(C,A[F]))
}}}return E.flatten()
},moveBlock:function(H,A){H=this.getParentElementOf(H,["TR"])||H;
while(H.nodeName!="TR"&&H.parentNode!=this.getRoot()&&!H.previousSibling&&!H.nextSibling&&!this.tree.isListContainer(H.parentNode)){H=H.parentNode
}var G,B;
if(A){G=H.previousSibling;
if(G){var F=G.nodeName=="LI"&&((G.childNodes.length==1&&this.tree.isBlock(G.firstChild))||!this.tree.hasBlocks(G));
var E=["TABLE","TR"].include(G.nodeName);
B=this.tree.isBlockContainer(G)&&!F&&!E?"end":"before"
}else{if(H.parentNode!=this.getRoot()){G=H.parentNode;
B="before"
}}}else{G=H.nextSibling;
if(G){var F=G.nodeName=="LI"&&((G.childNodes.length==1&&this.tree.isBlock(G.firstChild))||!this.tree.hasBlocks(G));
var E=["TABLE","TR"].include(G.nodeName);
B=this.tree.isBlockContainer(G)&&!F&&!E?"start":"after"
}else{if(H.parentNode!=this.getRoot()){G=H.parentNode;
B="after"
}}}if(!G){return null
}if(["TBODY","THEAD"].include(G.nodeName)){return null
}this.wrapAllInlineOrTextNodesAs("P",G,true);
if(this.isFirstLiWithNestedList(H)){this.insertNewBlockAround(H,false,"P")
}var D=H.parentNode;
var C=this.insertNodeAt(H,G,B,true);
if(!D.hasChildNodes()){this.deleteNode(D,true)
}this.unwrapUnnecessaryParagraph(C);
this.unwrapUnnecessaryParagraph(G);
if(A){if(C.previousSibling&&this.isEmptyBlock(C.previousSibling)&&!C.previousSibling.previousSibling&&C.parentNode.nodeName=="LI"&&this.tree.isListContainer(C.nextSibling)){this.deleteNode(C.previousSibling)
}}else{if(C.nextSibling&&this.isEmptyBlock(C.nextSibling)&&!C.previousSibling&&C.parentNode.nodeName=="LI"&&this.tree.isListContainer(C.nextSibling.nextSibling)){this.deleteNode(C.nextSibling)
}}return C
},removeBlock:function(E){var D;
while(E.parentNode!=this.getRoot()&&!E.previousSibling&&!E.nextSibling&&!this.tree.isListContainer(E.parentNode)){E=E.parentNode
}var C=function(F){return this.tree.isBlock(F)&&!this.tree.isDescendantOf(E,F)&&!this.tree.hasBlocks(F)
}.bind(this);
var A=function(F){return this.tree.isBlock(F)&&!this.tree.isDescendantOf(this.getRoot(),F)
}.bind(this);
if(this.isFirstLiWithNestedList(E)){D=this.outdentListItem(E.nextSibling.firstChild);
this.deleteNode(D.previousSibling,true)
}else{if(this.tree.isTableCell(E)){var B=new xq.RichTable(this,this.getParentElementOf(E,["TABLE"]));
D=B.getBelowCellOf(E);
if(E.parentNode.parentNode.nodeName=="TBODY"&&B.hasHeadingAtTop()&&B.getDom().tBodies[0].rows.length==1){return D
}D=D||this.tree.findForward(E,C,A)||this.tree.findBackward(E,C,A);
this.deleteNode(E.parentNode,true)
}else{D=D||this.tree.findForward(E,C,A)||this.tree.findBackward(E,C,A);
this.deleteNode(E,true)
}}if(!this.getRoot().hasChildNodes()){D=this.createElement("P");
this.getRoot().appendChild(D);
this.correctEmptyElement(D)
}return D
},removeTrailingWhitespace:function(A){throw"Not implemented"
},changeListTypeTo:function(C,D){D=D.toUpperCase();
var A=this.getParentElementOf(C,["LI"]);
if(!A){throw"IllegalArgumentException"
}var B=A.parentNode;
this.splitContainerOf(A);
var E=this.insertNodeAt(this.createElement(D=="UL"?"UL":"OL"),B,"before");
if(D=="CODE"){E.className="code"
}this.insertNodeAt(A,E,"start");
this.deleteNode(B);
this.mergeAdjustLists(E);
return C
},splitContainerOf:function(C,F,B){if([C,C.parentNode].include(this.getRoot())){return C
}var A=C.parentNode;
if(C.previousSibling&&(!B||B.toLowerCase()=="prev")){var E=this.createElement(A.nodeName);
this.copyAttributes(A,E);
while(A.firstChild!=C){E.appendChild(A.firstChild)
}this.insertNodeAt(E,A,"before");
this.unwrapUnnecessaryParagraph(E)
}if(C.nextSibling&&(!B||B.toLowerCase()=="next")){var D=this.createElement(A.nodeName);
this.copyAttributes(A,D);
while(A.lastChild!=C){this.insertNodeAt(A.lastChild,D,"start")
}this.insertNodeAt(D,A,"after");
this.unwrapUnnecessaryParagraph(D)
}if(!F){C=this.unwrapUnnecessaryParagraph(A)?A:C
}return C
},splitParentElement:function(A){var C=A.parentNode;
if(["HTML","HEAD","BODY"].include(C.nodeName)){throw"Illegal argument. Cannot seperate element["+C.nodeName+"]"
}var D=A.previousSibling;
var E=A.nextSibling;
var F=this.insertNodeAt(this.createElement(C.nodeName),C,"after");
var B;
while(B=A.nextSibling){F.appendChild(B)
}this.insertNodeAt(A,F,"start");
this.copyAttributes(C,F);
return F
},splitElementUpto:function(B,A,C){while(B.previousSibling!=A){if(C&&B.parentNode==A){break
}B=this.splitParentElement(B)
}return B
},mergeElement:function(D,I,H){if(I){var C=D;
var E=this.tree.findForward(D,function(J){return this.tree.isBlock(J)&&!this.tree.isListContainer(J)&&J!=D.parentNode
}.bind(this))
}else{var E=D;
var C=this.tree.findBackward(D,function(J){return this.tree.isBlock(J)&&!this.tree.isListContainer(J)&&J!=D.parentNode
}.bind(this))
}if(E&&this.tree.isDescendantOf(this.getRoot(),E)){var F=E.parentNode;
if(this.tree.isBlockContainer(E)){F=E;
this.wrapAllInlineOrTextNodesAs("P",F,true);
E=F.firstChild
}}else{E=null
}if(C&&this.tree.isDescendantOf(this.getRoot(),C)){var G=C.parentNode;
if(this.tree.isBlockContainer(C)){G=C;
this.wrapAllInlineOrTextNodesAs("P",G,true);
C=G.lastChild
}}else{C=null
}try{var B=G&&(this.tree.isTableCell(G)||["TR","THEAD","TBODY"].include(G.nodeName))&&F&&(this.tree.isTableCell(F)||["TR","THEAD","TBODY"].include(F.nodeName));
if(B&&G!=F){return null
}if((!H||!C)&&E&&this.outdentElement(E)){return D
}if(F&&F.nodeName=="LI"&&this.tree.isListContainer(E.nextSibling)){this.extractOutElementFromParent(F);
return C
}if(F&&F.nodeName=="LI"&&this.tree.isListContainer(F.parentNode.previousSibling)){this.mergeAdjustLists(F.parentNode.previousSibling,true,"next");
return C
}if(E&&!B&&G&&G.nodeName=="LI"&&F&&F.nodeName=="LI"&&G.parentNode.nextSibling==F.parentNode){var A=F.parentNode;
this.moveChildNodes(F.parentNode,G.parentNode);
this.deleteNode(A);
return C
}if(E&&!B&&G&&G.nextSibling==F&&((H&&G.nodeName!="LI")||(!H&&G.nodeName=="LI"))){this.moveChildNodes(F,G);
return C
}if(F&&F.nodeName!="LI"&&!this.getParentElementOf(F,["TABLE"])&&!this.tree.isListContainer(F)&&F!=this.getRoot()&&!E.previousSibling){return this.unwrapElement(F,true)
}if(I&&F&&F.nodeName=="TABLE"){this.deleteNode(F,true);
return C
}else{if(!I&&G&&this.tree.isTableCell(G)&&!this.tree.isTableCell(F)){this.deleteNode(this.getParentElementOf(G,["TABLE"]),true);
return E
}}if(C==E){return null
}if(!C||!E||!G||!F){return null
}if(this.getParentElementOf(C,["TD","TH"])!=this.getParentElementOf(E,["TD","TH"])){return null
}if(this.isEmptyBlock(C)){C.innerHTML=""
}if(this.isEmptyBlock(E)){E.innerHTML=""
}this.moveChildNodes(E,C);
this.deleteNode(E);
this.removePlaceHoldersAndEmptyNodes(C);
return C
}finally{if(G&&this.isEmptyBlock(G)){this.deleteNode(G,true)
}if(F&&this.isEmptyBlock(F)){this.deleteNode(F,true)
}if(G){this.unwrapUnnecessaryParagraph(G)
}if(F){this.unwrapUnnecessaryParagraph(F)
}}},mergeAdjustLists:function(A,G,D){var F=A.previousSibling;
var C=F&&(F.nodeName==A.nodeName&&F.className==A.className);
if((!D||D.toLowerCase()=="prev")&&(C||(G&&this.tree.isListContainer(F)))){while(F.lastChild){this.insertNodeAt(F.lastChild,A,"start")
}this.deleteNode(F)
}var E=A.nextSibling;
var B=E&&(E.nodeName==A.nodeName&&E.className==A.className);
if((!D||D.toLowerCase()=="next")&&(B||(G&&this.tree.isListContainer(E)))){while(E.firstChild){this.insertNodeAt(E.firstChild,A,"end")
}this.deleteNode(E)
}},moveChildNodes:function(B,A){if(this.tree.isDescendantOf(B,A)||["HTML","HEAD"].include(A.nodeName)){throw"Illegal argument. Cannot move children of element["+B.nodeName+"] to element["+A.nodeName+"]"
}if(B==A){return 
}while(B.firstChild){A.appendChild(B.firstChild)
}},copyAttributes:function(E,D,B){var A=E.attributes;
if(!A){return 
}for(var C=0;
C<A.length;
C++){if(A[C].nodeName=="class"&&A[C].nodeValue){D.className=A[C].nodeValue
}else{if((B||!["id"].include(A[C].nodeName))&&A[C].nodeValue){D.setAttribute(A[C].nodeName,A[C].nodeValue)
}}}},_indentElements:function(C,E,D){for(var B=0;
B<D.length;
B++){if(D[B]==C||this.tree.isDescendantOf(D[B],C)){return 
}}leaves=this.tree.getLeavesAtEdge(C);
if(E.include(leaves[0])){var F=this.indentElement(C,true);
if(F){D.push(F);
return 
}}if(E.include(C)){var F=this.indentElement(C,true);
if(F){D.push(F);
return 
}}var A=$A(C.childNodes);
for(var B=0;
B<A.length;
B++){this._indentElements(A[B],E,D)
}return 
},indentElements:function(H,G){var E=this.getBlockElementsBetween(H,G);
var C=this.tree.findCommonAncestorAndImmediateChildrenOf(H,G);
var D=[];
leaves=this.tree.getLeavesAtEdge(C.parent);
if(E.include(leaves[0])){var F=this.indentElement(C.parent);
if(F){return[F]
}}var B=$A(C.parent.childNodes);
for(var A=0;
A<B.length;
A++){this._indentElements(B[A],E,D)
}D=D.flatten();
return D.length>0?D:E
},outdentElementsCode:function(A){if(A.tagName=="LI"){A=A.parentNode
}if(A.tagName=="OL"&&A.className=="code"){return true
}return false
},_outdentElements:function(C,F,E){for(var B=0;
B<E.length;
B++){if(E[B]==C||this.tree.isDescendantOf(E[B],C)){return 
}}leaves=this.tree.getLeavesAtEdge(C);
if(F.include(leaves[0])&&!this.outdentElementsCode(leaves[0])){var G=this.outdentElement(C,true);
if(G){E.push(G);
return 
}}if(F.include(C)){var A=$A(C.parentNode.childNodes);
var D=this.outdentElementsCode(C);
var G=this.outdentElement(C,true,D);
if(G){if(A.include(G)&&this.tree.isListContainer(C.parentNode)&&!D){for(var B=0;
B<A.length;
B++){if(F.include(A[B])&&!E.include(A[B])){E.push(A[B])
}}}else{E.push(G)
}return 
}}var A=$A(C.childNodes);
for(var B=0;
B<A.length;
B++){this._outdentElements(A[B],F,E)
}return 
},outdentElements:function(I,J){var B,D;
if(I.parentNode.tagName=="LI"){B=I.parentNode
}if(J.parentNode.tagName=="LI"){D=J.parentNode
}var A=this.getBlockElementsBetween(I,J);
var G=this.tree.findCommonAncestorAndImmediateChildrenOf(I,J);
var H=[];
leaves=this.tree.getLeavesAtEdge(G.parent);
if(A.include(leaves[0])&&!this.outdentElementsCode(G.parent)){var E=this.outdentElement(G.parent);
if(E){return[E]
}}var C=$A(G.parent.childNodes);
for(var F=0;
F<C.length;
F++){this._outdentElements(C[F],A,H)
}if(I.offsetParent&&J.offsetParent){B=I;
D=J
}else{if(A.first().offsetParent&&A.last().offsetParent){B=A.first();
D=A.last()
}}H=H.flatten();
if(!B||!B.offsetParent){B=H.first()
}if(!D||!D.offsetParent){D=H.last()
}return this.getBlockElementsBetween(B,D)
},indentElement:function(E,D,A){if(!A&&(E.nodeName=="LI"||(!this.tree.isListContainer(E)&&!E.previousSibling&&E.parentNode.nodeName=="LI"))){return this.indentListItem(E,D)
}var C=this.getRoot();
if(!E||E==C){return null
}if(E.parentNode!=C&&!E.previousSibling&&!D){E=E.parentNode
}var F=E.style.marginLeft;
var B=F?this._getCssValue(F,"px"):{value:0,unit:"em"};
B.value+=2;
E.style.marginLeft=B.value+B.unit;
return E
},outdentElement:function(E,D,A){if(!A&&E.nodeName=="LI"){return this.outdentListItem(E,D)
}var C=this.getRoot();
if(!E||E==C){return null
}var F=E.style.marginLeft;
var B=F?this._getCssValue(F,"px"):{value:0,unit:"em"};
if(B.value==0){return E.previousSibling||A?null:this.outdentElement(E.parentNode,D)
}B.value-=2;
E.style.marginLeft=B.value<=0?"":B.value+B.unit;
if(E.style.cssText==""){E.removeAttribute("style")
}return E
},indentListItem:function(E,B){var A=this.getParentElementOf(E,["LI"]);
var C=A.parentNode;
var G=A.previousSibling;
if(!A.previousSibling){return this.indentElement(C)
}if(A.parentNode.nodeName=="OL"&&A.parentNode.className=="code"){return this.indentElement(A,B,true)
}if(!G.lastChild){G.appendChild(this.makePlaceHolder())
}var F=this.tree.isListContainer(G.lastChild)?G.lastChild:this.insertNodeAt(this.createElement(C.nodeName),G,"end");
this.wrapAllInlineOrTextNodesAs("P",G,true);
F.appendChild(A);
if(!B&&A.lastChild&&this.tree.isListContainer(A.lastChild)){var D=A.lastChild;
var H;
while(H=D.lastChild){this.insertNodeAt(H,A,"after")
}this.deleteNode(D)
}this.unwrapUnnecessaryParagraph(A);
return A
},outdentListItem:function(E,C){var B=this.getParentElementOf(E,["LI"]);
var D=B.parentNode;
if(!B.previousSibling){var H=this.outdentElement(D);
if(H){return H
}}if(B.parentNode.nodeName=="OL"&&B.parentNode.className=="code"){return this.outdentElement(B,C,true)
}var A=D.parentNode;
if(A.nodeName!="LI"){return null
}if(C){while(D.lastChild!=B){this.insertNodeAt(D.lastChild,A,"after")
}}else{if(B.nextSibling){var G=B.lastChild&&this.tree.isListContainer(B.lastChild)?B.lastChild:this.insertNodeAt(this.createElement(D.nodeName),B,"end");
this.copyAttributes(D,G);
var F;
while(F=B.nextSibling){G.appendChild(F)
}}}B=this.insertNodeAt(B,A,"after");
if(D.childNodes.length==0){this.deleteNode(D)
}if(B.firstChild&&this.tree.isListContainer(B.firstChild)){this.insertNodeAt(this.makePlaceHolder(),B,"start")
}this.wrapAllInlineOrTextNodesAs("P",B);
this.unwrapUnnecessaryParagraph(A);
return B
},justifyBlock:function(C,B){while(C.parentNode!=this.getRoot()&&!C.previousSibling&&!C.nextSibling&&!this.tree.isListContainer(C.parentNode)){C=C.parentNode
}var A=B.toLowerCase()=="both"?"justify":B;
if(A=="left"){C.style.textAlign="";
if(C.style.cssText==""){C.removeAttribute("style")
}}else{C.style.textAlign=A
}return C
},justifyBlocks:function(B,A){B.each(function(C){this.justifyBlock(C,A)
}.bind(this));
return B
},applyList:function(C,D){D=D.toUpperCase();
var A=D=="UL"?"UL":"OL";
if(C.nodeName=="LI"||(C.parentNode.nodeName=="LI"&&!C.previousSibling)){var C=this.getParentElementOf(C,["LI"]);
var B=C.parentNode;
if(B.nodeName==A){return this.extractOutElementFromParent(C)
}else{return this.changeListTypeTo(C,D)
}}else{return this.turnElementIntoListItem(C,D)
}},applyLists:function(M,N,K){K=K.toUpperCase();
var I=K=="UL"?"UL":"OL";
var A=this.getBlockElementsBetween(M,N);
var J=A.findAll(function(P){return P.nodeName=="LI"||!this.tree.isBlockContainer(P)
}.bind(this));
var B=J.findAll(function(P){return P.nodeName=="LI"
}.bind(this));
var H=J.findAll(function(P){return P.nodeName!="LI"&&!(P.parentNode.nodeName=="LI"&&!P.previousSibling&&!P.nextSibling)&&!this.tree.isDescendantOf(B,P)
}.bind(this));
var O=B.findAll(function(P){return P.parentNode.nodeName!=I
}.bind(this));
var E=H.length>0;
var D=O.length>0;
var L=null;
if(E){L=H
}else{if(D){L=O
}else{L=B
}}for(var F=0;
F<L.length;
F++){var C=L[F];
var G=A.indexOf(C);
A[G]=this.applyList(C,K)
}return A
},correctEmptyElement:function(A){throw"Not implemented"
},correctParagraph:function(){throw"Not implemented"
},makePlaceHolder:function(){throw"Not implemented"
},makeEmptyParagraph:function(){throw"Not implemented"
},applyBackgroundColor:function(A){throw"Not implemented"
},applyForegroundColor:function(A){this.execCommand("forecolor",A)
},execCommand:function(A,B){throw"Not implemented"
},applyRemoveFormat:function(){throw"Not implemented"
},applyEmphasis:function(){throw"Not implemented"
},applyStrongEmphasis:function(){throw"Not implemented"
},applyStrike:function(){throw"Not implemented"
},applyUnderline:function(){throw"Not implemented"
},applySuperscription:function(){this.execCommand("superscript")
},applySubscription:function(){this.execCommand("subscript")
},applyQuote:function(){alert("TODO");
return 
},indentBlock:function(B,A){return(!B.previousSibling&&B.parentNode.nodeName=="LI")?this.indentListItem(B,A):this.indentElement(B)
},outdentBlock:function(B,A){while(true){if(!B.previousSibling&&B.parentNode.nodeName=="LI"){B=this.outdentListItem(B,A);
return B
}else{var C=this.outdentElement(B);
if(C){return C
}if(!B.previousSibling){B=B.parentNode
}else{break
}}}return null
},wrapBlock:function(B,F,C){if(!this.tree._blockTags.include(B)){throw"Unsuppored block container: ["+B+"]"
}if(!F){F=this.getCurrentBlockElement()
}if(!C){C=F
}var A=false;
if(F==C){A=true
}else{if(F.parentNode==C.parentNode&&!F.previousSibling&&!C.nextSibling){A=true;
F=C=F.parentNode
}else{A=(F.parentNode==C.parentNode)&&(F.nodeName!="LI")
}}if(!A){return null
}var E=this.createElement(B);
if(F==C){if(this.tree.isBlockContainer(F)&&!this.tree.isListContainer(F)){if(this.tree.isBlockOnlyContainer(E)){this.correctEmptyElement(F);
this.wrapAllInlineOrTextNodesAs("P",F,true)
}this.moveChildNodes(F,E);
F.appendChild(E)
}else{E=this.insertNodeAt(E,F,"after");
E.appendChild(F)
}this.correctEmptyElement(E)
}else{E=this.insertNodeAt(E,F,"before");
var D=F;
while(D!=C){next=D.nextSibling;
E.appendChild(D);
D=next
}E.appendChild(D)
}return E
},focus:function(){throw"Not implemented"
},sel:function(){throw"Not implemented"
},rng:function(){throw"Not implemented"
},hasSelection:function(){throw"Not implemented"
},hasFocus:function(){var A=this.getCurrentElement();
return(A&&A.ownerDocument==this.getDoc())
},scrollIntoView:function(C,B,A){C.scrollIntoView(B);
if(A){this.placeCaretAtStartOf(C)
}},selectAll:function(){return this.execCommand("selectall")
},selectElement:function(B,A){throw"Not implemented"
},selectBlocksBetween:function(B,A){throw"Not implemented"
},deleteSelection:function(){throw"Not implemented"
},collapseSelection:function(A){throw"Not implemented"
},getSelectionAsHtml:function(){throw"Not implemented"
},getSelectionAsText:function(){throw"Not implemented"
},placeCaretAtStartOf:function(A){throw"Not implemented"
},isEmptyTextNode:function(A){return A.nodeType==3&&A.nodeValue.length==0
},isCaretAtEmptyBlock:function(){return this.isEmptyBlock(this.getCurrentBlockElement())
},isCaretAtBlockStart:function(){throw"Not implemented"
},isCaretAtBlockEnd:function(){throw"Not implemented"
},saveSelection:function(){throw"Not implemented"
},restoreSelection:function(A){throw"Not implemented"
},createMarker:function(){var A=this.createElement("SPAN");
A.id="xquared_marker_"+(this._lastMarkerId++);
A.className="xquared_marker";
return A
},pushMarker:function(){var A=this.createMarker();
return this.insertNode(A)
},popMarker:function(B){var C="xquared_marker_"+(--this._lastMarkerId);
var A=this.$(C);
if(!A){return 
}if(B){this.selectElement(A,true);
this.collapseSelection(false)
}this.deleteNode(A)
},getOuterHTML:function(A){throw"Not implemented"
},getInnerText:function(A){return A.innerHTML.stripTags()
},isPlaceHolder:function(A){throw"Not implemented"
},isFirstLiWithNestedList:function(A){return !A.previousSibling&&A.parentNode.nodeName=="LI"&&this.tree.isListContainer(A.nextSibling)
},searchHeadings:function(A,C){if(!A){A=this.getRoot()
}if(!C){C=[]
}var B=/^h[1-6]/ig;
if(!A.childNodes){return[]
}$A(A.childNodes).each(function(F){var E=F&&this.tree._blockContainerTags.include(F.nodeName);
var D=F&&F.nodeName.match(B);
if(E){this.searchHeadings(F,C)
}else{if(D){C.push(F)
}}}.bind(this));
return C
},findBySelector:function(A){return Element.getElementsBySelector(this.root,A)
},findByAttribute:function(B,C){var A=[];
this._findByAttribute(A,this.root,B,C);
return A
},_findByAttribute:function(A,E,B,F){if(E.getAttribute(B)==F){A.push(E)
}if(!E.hasChildNodes()){return 
}var D=E.childNodes;
for(var C=0;
C<D.length;
C++){if(D[C].nodeType==1){this._findByAttribute(A,D[C],B,F)
}}},hasImportantAttributes:function(A){throw"Not implemented"
},isEmptyBlock:function(A){throw"Not implemented"
},getCurrentElement:function(){throw"Not implemented"
},getCurrentBlockElement:function(){var A=this.getParentBlockElementOf(this.getCurrentElement());
return(A.nodeName=="BODY")?A.firstChild:A
},getParentBlockElementOf:function(A){while(A){if(this.tree._blockTags.include(A.nodeName)){return A
}A=A.parentNode
}return null
},getParentElementOf:function(B,A){while(B){if(A.include(B.nodeName)){return B
}B=B.parentNode
}return null
},getBlockElementsBetween:function(B,A){return this.tree.collectNodesBetween(B,A,function(C){return C.nodeType==1&&this.tree.isBlock(C)
}.bind(this))
},getBlockElementAtSelectionStart:function(){throw"Not implemented"
},getBlockElementAtSelectionEnd:function(){throw"Not implemented"
},getBlockElementsAtSelectionEdge:function(B,A){throw"Not implemented"
},getSelectedBlockElements:function(){var B=this.getBlockElementsAtSelectionEdge(true,true);
var C=B[0];
var A=B[1];
return this.tree.collectNodesBetween(C,A,function(D){return D.nodeType==1&&this.tree.isBlock(D)
}.bind(this))
},getElementById:function(A){return this.doc.getElementById(A)
},$:function(A){return this.getElementById(A)
},getFirstChildOf:function(C){if(!C){return null
}var A=$A(C.childNodes);
for(var B=0;
B<A.length;
B++){if(!this.isEmptyTextNode(A[B])){return A[B]
}}return null
},getLastChildOf:function(A){throw"Not implemented"
},_getCssValue:function(C,A){if(!C||C.length==0){return{value:0,unit:A}
}var B=C.match(/(\d+)(.*)/);
return{value:parseInt(B[1]),unit:B[2]||A}
}};
xq.RichDom.createInstance=function(){if(xq.Browser.isTrident){return new xq.RichDomTrident()
}else{if(xq.Browser.isWebkit){return new xq.RichDomWebkit()
}else{return new xq.RichDomGecko()
}}};
xq.RichDomW3=Class.create();
xq.RichDomW3.prototype={insertNode:function(B){var A=this.rng();
A.insertNode(B);
A.selectNode(B);
A.collapse(false);
return B
},removeTrailingWhitespace:function(A){},getOuterHTML:function(A){var B=A.ownerDocument.createElement("div");
B.appendChild(A.cloneNode(true));
return B.innerHTML
},correctEmptyElement:function(A){if(!A||A.nodeType!=1||this.tree.isAtomic(A)){return 
}if(A.firstChild){this.correctEmptyElement(A.firstChild)
}else{A.appendChild(this.makePlaceHolder())
}},correctParagraph:function(){if(this.hasSelection()){return 
}var A=this.getCurrentElement();
if(this.tree.isBlockOnlyContainer(A)){this.execCommand("InsertParagraph")
}else{if(this.tree.hasMixedContents(A)){this.wrapAllInlineOrTextNodesAs("P",A,true)
}}},applyBackgroundColor:function(A){this.execCommand("styleWithCSS","true");
this.execCommand("hilitecolor",A);
this.execCommand("styleWithCSS","false");
var E=this.saveSelection();
var F=this.getSelectedBlockElements();
if(F.length==0){return 
}for(var D=0;
D<F.length;
D++){if((D==0||D==F.length-1)&&!F[D].style.backgroundColor){continue
}var C=this.wrapAllInlineOrTextNodesAs("SPAN",F[D],true);
for(var B=0;
B<C.length;
B++){C[B].style.backgroundColor=A
}F[D].style.backgroundColor=""
}this.restoreSelection(E)
},execCommand:function(A,B){return this.doc.execCommand(A,false,B||null)
},saveSelection:function(){var A=this.rng();
return[A.startContainer,A.startOffset,A.endContainer,A.endOffset]
},restoreSelection:function(B){var A=this.rng();
A.setStart(B[0],B[1]);
A.setEnd(B[2],B[3])
},applyRemoveFormat:function(){this.execCommand("RemoveFormat");
this.execCommand("Unlink")
},applyEmphasis:function(){this.execCommand("styleWithCSS","false");
this.execCommand("italic")
},applyStrongEmphasis:function(){this.execCommand("styleWithCSS","false");
this.execCommand("bold")
},applyStrike:function(){this.execCommand("styleWithCSS","false");
this.execCommand("strikethrough")
},applyUnderline:function(){this.execCommand("styleWithCSS","false");
this.execCommand("underline")
},execHeading:function(A){this.execCommand("Heading","H"+A)
},focus:function(){setTimeout(this._focus.bind(this),0)
},_focus:function(){this.win.focus();
if(!this.hasSelection()&&this.getCurrentElement().nodeName=="HTML"){this.selectElement(this.doc.body.firstChild);
this.collapseSelection(true)
}},sel:function(){return this.win.getSelection()
},rng:function(){var A=this.sel();
return(A==null||A.rangeCount==0)?null:A.getRangeAt(0)
},hasSelection:function(){var A=this.sel();
return A&&!A.isCollapsed
},deleteSelection:function(){this.rng().deleteContents();
this.sel().collapseToStart()
},selectElement:function(A,B){throw"Not implemented yet"
},selectBlocksBetween:function(C,B){this.doc.execCommand("SelectAll",false,null);
var A=this.rng();
A.setStart(C.firstChild,0);
A.setEnd(B,B.childNodes.length)
},collapseSelection:function(A){this.rng().collapse(A)
},placeCaretAtStartOf:function(A){while(this.tree.isBlock(A.firstChild)){A=A.firstChild
}this.selectElement(A,false);
this.collapseSelection(true)
},getSelectionAsHtml:function(){var A=document.createElement("div");
A.appendChild(this.rng().cloneContents());
return A.innerHTML
},getSelectionAsText:function(){return this.rng().toString()
},hasImportantAttributes:function(A){return !!(A.id||A.className||A.style.cssText)
},isEmptyBlock:function(C){if(!C.hasChildNodes()){return true
}var B=C.childNodes;
for(var A=0;
A<B.length;
A++){if(!this._isPlaceHolder(B[A])&&!this.isEmptyTextNode(B[A])){return false
}}return true
},getLastChildOf:function(C){if(!C||!C.hasChildNodes()){return null
}var A=$A(C.childNodes).reverse();
for(var B=0;
B<A.length;
B++){if(!this._isPlaceHolder(A[B])&&!this.isEmptyTextNode(A[B])){return A[B]
}}return null
},getCurrentElement:function(){var B=this.rng();
if(!B){return null
}var A=B.startContainer;
return A.nodeType==3?A.parentNode:A
},getBlockElementsAtSelectionEdge:function(E,A){var F=this.getBlockElementAtSelectionStart();
var B=this.getBlockElementAtSelectionEnd();
var D=false;
if(E&&F!=B&&this.tree.checkTargetBackward(F,B)){var C=F;
F=B;
B=C;
D=true
}if(A&&F!=B){}return[F,B]
},getBlockElementAtSelectionStart:function(){var A=this.getParentBlockElementOf(this.sel().anchorNode);
while(this.tree.isBlockContainer(A)&&A.firstChild&&this.tree.isBlock(A.firstChild)){A=A.firstChild
}return A
},getBlockElementAtSelectionEnd:function(){var A=this.getParentBlockElementOf(this.sel().focusNode);
while(this.tree.isBlockContainer(A)&&A.lastChild&&this.tree.isBlock(A.lastChild)){A=A.lastChild
}return A
},isCaretAtBlockStart:function(){if(this.isCaretAtEmptyBlock()){return true
}if(this.hasSelection()){return false
}var C=this.rng();
var D=this.getCurrentBlockElement();
var A=false;
if(D==C.startContainer){var B=this.pushMarker();
while(D=this.getFirstChildOf(D)){if(D==B){A=true;
break
}}this.popMarker()
}else{while(D=D.firstChild){if(D==C.startContainer&&C.startOffset==0){A=true;
break
}}}return A
},isCaretAtBlockEnd:function(){if(this.isCaretAtEmptyBlock()){return true
}if(this.hasSelection()){return false
}var C=this.rng();
var D=this.getCurrentBlockElement();
var A=false;
if(D==C.startContainer){var B=this.pushMarker();
while(D=this.getLastChildOf(D)){if((D==B)||(this.isPlaceHolder(D)&&D.previousSibling==B)){A=true;
break
}}this.popMarker()
}else{while(D=this.getLastChildOf(D)){if(D==C.endContainer&&C.endContainer.nodeType==1){A=true;
break
}else{if(D==C.endContainer&&C.endOffset==D.nodeValue.length){A=true;
break
}}}}return A
},_isPlaceHolder:function(A){return A.nodeType==1&&A.nodeName=="BR"&&A.getAttribute("type")=="_moz"
}};
xq.RichDomW3.prototype=Object.extend(new xq.RichDom(),xq.RichDomW3.prototype);
xq.RichDomGecko=Class.create();
xq.RichDomGecko.prototype={makePlaceHolder:function(){var A=this.createElement("BR");
A.setAttribute("type","_moz");
A.setAttribute("_moz_dirty","");
return A
},makeEmptyParagraph:function(){return this.createElementFromHtml("<p><br type=\"_moz\" _moz_dirty /></p>")
},isPlaceHolder:function(B){var A=B.nodeName=="BR"&&B.getAttribute("type")=="_moz";
var C=B.nodeName=="BR"&&B.parentNode&&!B.nextSibling;
return A||C
},selectElement:function(B,C){if(!B){throw"[element] is null"
}if(B.nodeType!=1){throw"[element] is not an element"
}try{this.doc.execCommand("SelectAll",false,null)
}catch(A){}if(C){this.rng().selectNode(B)
}else{this.rng().selectNodeContents(B)
}}};
xq.RichDomGecko.prototype=Object.extend(new xq.RichDomW3(),xq.RichDomGecko.prototype);
xq.RichDomWebkit=Class.create();
xq.RichDomWebkit.prototype={makePlaceHolder:function(){var A=this.createElement("BR");
A.className="webkit-block-placeholder";
return A
},makeEmptyParagraph:function(){return this.createElementFromHtml("<p><br class=\"webkit-block-placeholder\" /></p>")
},isPlaceHolder:function(A){return A.nodeName=="BR"&&A.className=="webkit-block-placeholder"
},selectElement:function(A,B){if(!A){throw"[element] is null"
}if(A.nodeType!=1){throw"[element] is not an element"
}if(B){this.rng().selectNode(A)
}else{this.rng().selectNodeContents(A)
}}};
xq.RichDomWebkit.prototype=Object.extend(new xq.RichDomW3(),xq.RichDomWebkit.prototype);
xq.RichDomTrident=Class.create();
xq.RichDomTrident.prototype={makePlaceHolder:function(){return this.createTextNode(" ")
},makeEmptyParagraph:function(){return this.createElementFromHtml("<p>&nbsp;</p>")
},isPlaceHolder:function(A){return false
},getOuterHTML:function(A){return A.outerHTML
},insertNode:function(B){if(this.hasSelection()){this.collapseSelection(true)
}this.rng().pasteHTML("<span id=\"xquared_temp\"></span>");
var A=this.$("xquared_temp");
if(B.id=="xquared_temp"){return A
}A.replaceNode(B);
return B
},removeTrailingWhitespace:function(D){if(!D){return 
}if(this.isEmptyBlock(D)){return 
}var C=D.innerText;
var A=C.charCodeAt(C.length-1);
if(C.length<=1||![32,160].include(A)){return 
}var B=D;
while(B&&B.nodeType!=3){B=B.lastChild
}if(!B){return 
}if(B.nodeValue.length==1){this.deleteNode(B)
}else{B.nodeValue=B.nodeValue.substring(0,B.nodeValue.length-1)
}},correctEmptyElement:function(A){if(!A||A.nodeType!=1||this.tree.isAtomic(A)){return 
}if(A.firstChild){this.correctEmptyElement(A.firstChild)
}else{A.innerHTML="&nbsp;"
}},copyAttributes:function(C,B,A){B.mergeAttributes(C,!A)
},correctParagraph:function(){if(!this.hasFocus()){return 
}if(this.hasSelection()){return 
}var B=this.getCurrentBlockElement();
if(B.nodeType==3){B=B.parentNode
}if(this.tree.hasMixedContents(B)){var A=this.pushMarker();
this.wrapAllInlineOrTextNodesAs("P",B,true);
this.popMarker(true)
}else{if((this.tree.isTextOrInlineNode(B.previousSibling)||this.tree.isTextOrInlineNode(B.nextSibling))&&this.tree.hasMixedContents(B.parentNode)){this.wrapAllInlineOrTextNodesAs("P",B.parentNode,true)
}}},applyBackgroundColor:function(A){this.execCommand("BackColor",A)
},execCommand:function(A,B){return this.doc.execCommand(A,false,B)
},applyEmphasis:function(){this.execCommand("Italic")
},applyStrongEmphasis:function(){this.execCommand("Bold")
},applyStrike:function(){this.execCommand("strikethrough")
},applyUnderline:function(){this.execCommand("underline")
},applyRemoveFormat:function(){this.execCommand("RemoveFormat");
this.execCommand("Unlink")
},execHeading:function(A){this.execCommand("FormatBlock","<H"+A+">")
},focus:function(){this.win.focus()
},sel:function(){return this.doc.selection
},rng:function(){try{var B=this.sel();
return(B==null)?null:B.createRange()
}catch(A){return null
}},hasSelection:function(){var A=this.sel().type.toLowerCase();
if("none"==A){return false
}if("text"==A&&this.getSelectionAsHtml().length==0){return false
}return true
},deleteSelection:function(){if(this.getSelectionAsText()!=""){this.sel().clear()
}},placeCaretAtStartOf:function(A){var B=this.createElement("SPAN");
this.insertNodeAt(B,A,"start");
this.selectElement(B);
this.collapseSelection(false);
this.deleteNode(B)
},selectElement:function(B,C){if(!B){throw"[element] is null"
}if(B.nodeType!=1){throw"[element] is not an element"
}var A=this.rng();
A.moveToElementText(B);
A.select()
},selectBlocksBetween:function(D,B){var A=this.rng();
var C=this.rng();
C.moveToElementText(D);
A.setEndPoint("StartToStart",C);
C.moveToElementText(B);
A.setEndPoint("EndToEnd",C);
A.select()
},collapseSelection:function(B){var A=this.rng();
A.collapse(B);
A.select()
},getSelectionAsHtml:function(){var A=this.rng();
return A&&A.htmlText?A.htmlText:""
},getSelectionAsText:function(){var A=this.rng();
return A&&A.text?A.text:""
},hasImportantAttributes:function(A){return !!(A.id||A.className||A.style.cssText)
},isEmptyBlock:function(A){if(!A.hasChildNodes()){return true
}if(A.nodeType==3&&!A.nodeValue){return true
}if(["&nbsp;"," ",""].include(A.innerHTML)){return true
}return false
},getLastChildOf:function(C){if(!C||!C.hasChildNodes()){return null
}var A=$A(C.childNodes).reverse();
for(var B=0;
B<A.length;
B++){if(A[B].nodeType!=3||A[B].nodeValue.length!=0){return A[B]
}}return null
},getCurrentElement:function(){if(this.sel().type.toLowerCase()=="control"){return this.rng().item(0)
}return this.rng().parentElement()
},getBlockElementAtSelectionStart:function(){var B=this.rng();
var C=B.duplicate();
C.collapse(true);
var A=this.getParentBlockElementOf(C.parentElement());
if(A.nodeName=="BODY"){A=A.firstChild
}return A
},getBlockElementAtSelectionEnd:function(){var B=this.rng();
var C=B.duplicate();
C.collapse(false);
var A=this.getParentBlockElementOf(C.parentElement());
if(A.nodeName=="BODY"){A=A.lastChild
}return A
},getBlockElementsAtSelectionEdge:function(B,A){return[this.getBlockElementAtSelectionStart(),this.getBlockElementAtSelectionEnd()]
},isCaretAtBlockStart:function(){if(this.isCaretAtEmptyBlock()){return true
}if(this.hasSelection()){return false
}var C=this.getCurrentBlockElement();
var B=this.pushMarker();
var A=false;
while(C=this.getFirstChildOf(C)){if(C==B){A=true;
break
}}this.popMarker();
return A
},isCaretAtBlockEnd:function(){if(this.isCaretAtEmptyBlock()){return true
}if(this.hasSelection()){return false
}var C=this.getCurrentBlockElement();
var B=this.pushMarker();
var A=false;
while(C=this.getLastChildOf(C)){if(C==B){A=true;
break
}else{if(C.nodeType==3&&C.previousSibling==B&&(C.nodeValue==" "||(C.nodeValue&&C.nodeValue.charCodeAt(0)==160))){A=true;
break
}}}this.popMarker();
return A
},saveSelection:function(){return this.rng()
},restoreSelection:function(A){A.select()
}};
xq.RichDomTrident.prototype=Object.extend(new xq.RichDom(),xq.RichDomTrident.prototype);
xq.RichTable=Class.create();
xq.RichTable.prototype={initialize:function(B,A){this.rdom=B;
this.table=A
},insertNewRowAt:function(E,C){var F=this.rdom.createElement("TR");
var B=E.cells;
for(var D=0;
D<B.length;
D++){var A=this.rdom.createElement(B[D].nodeName);
this.rdom.correctEmptyElement(A);
F.appendChild(A)
}return this.rdom.insertNodeAt(F,E,C)
},insertNewCellAt:function(B,D){var C=[];
var A=this.getXIndexOf(B);
var G=0;
while(true){var F=this.getCellAt(A,G);
if(!F){break
}C.push(F);
G++
}for(var E=0;
E<C.length;
E++){var B=this.rdom.createElement(C[E].nodeName);
this.rdom.correctEmptyElement(B);
this.rdom.insertNodeAt(B,C[E],D)
}},deleteRow:function(A){return this.rdom.removeBlock(A)
},deleteCell:function(B){if(!B.previousSibling&&!B.nextSibling){this.rdom.deleteNode(this.table);
return 
}var C=[];
var A=this.getXIndexOf(B);
var F=0;
while(true){var E=this.getCellAt(A,F);
if(!E){break
}C.push(E);
F++
}for(var D=0;
D<C.length;
D++){this.rdom.deleteNode(C[D])
}},getPreviousCellOf:function(A){if(A.previousSibling){return A.previousSibling
}var B=this.getPreviousRowOf(A.parentNode);
if(B){return B.lastChild
}return null
},getNextCellOf:function(A){if(A.nextSibling){return A.nextSibling
}var B=this.getNextRowOf(A.parentNode);
if(B){return B.firstChild
}return null
},getPreviousRowOf:function(B){if(B.previousSibling){return B.previousSibling
}var A=B.parentNode;
if(A.previousSibling&&A.previousSibling.lastChild){return A.previousSibling.lastChild
}return null
},getNextRowOf:function(B){if(B.nextSibling){return B.nextSibling
}var A=B.parentNode;
if(A.nextSibling&&A.nextSibling.firstChild){return A.nextSibling.firstChild
}return null
},getAboveCellOf:function(B){var C=this.getPreviousRowOf(B.parentNode);
if(!C){return null
}var A=this.getXIndexOf(B);
return C.cells[A]
},getBelowCellOf:function(B){var C=this.getNextRowOf(B.parentNode);
if(!C){return null
}var A=this.getXIndexOf(B);
return C.cells[A]
},getXIndexOf:function(A){var C=A.parentNode;
for(var B=0;
B<C.cells.length;
B++){if(C.cells[B]==A){return B
}}return -1
},getYIndexOf:function(A){var D=-1;
var C=row.parentNode;
for(var B=0;
B<C.rows.length;
B++){if(C.rows[B]==row){D=B;
break
}}if(this.hasHeadingAtTop()&&C.nodeName=="TBODY"){D=D+1
}return D
},getLocationOf:function(B){var A=this.getXIndexOf(B);
var C=this.getYIndexOf(B);
return{x:A,y:C}
},getCellAt:function(A,B){var B=this.getRowAt(B);
return(B&&B.cells.length>A)?B.cells[A]:null
},getRowAt:function(A){if(this.hasHeadingAtTop()){return A==0?this.table.tHead.rows[0]:this.table.tBodies[0].rows[A-1]
}else{var B=this.table.tBodies[0].rows;
return(B.length>A)?B[A]:null
}},getDom:function(){return this.table
},hasHeadingAtTop:function(){return !!(this.table.tHead&&this.table.tHead.rows[0])
},hasHeadingAtLeft:function(){return this.table.tBodies[0].rows[0].cells[0].nodeName=="TH"
},correctEmptyCells:function(){var A=$A(this.table.getElementsByTagName("TH"));
A.push($A(this.table.getElementsByTagName("TD")));
A=A.flatten();
for(var B=0;
B<A.length;
B++){if(this.rdom.isEmptyBlock(A[B])){this.rdom.correctEmptyElement(A[B])
}}}};
xq.RichTable.create=function(E,G,J,C){if(["t","tl","lt"].include(C)){var I=true
}if(["l","tl","lt"].include(C)){var K=true
}var F=[];
F.push("<table class=\"datatable\">");
if(I){F.push("<thead><tr>");
for(var D=0;
D<G;
D++){F.push("<th></th>")
}F.push("</tr></thead>");
J-=1
}F.push("<tbody>");
for(var D=0;
D<J;
D++){F.push("<tr>");
for(var B=0;
B<G;
B++){if(K&&B==0){F.push("<th></th>")
}else{F.push("<td></td>")
}}F.push("</tr>")
}F.push("</tbody>");
F.push("</table>");
var A=E.createElement("div");
A.innerHTML=F.join("");
var H=new xq.RichTable(E,A.firstChild);
H.correctEmptyCells();
return H
};
xq.Validator=Class.create();
xq.Validator.prototype={initialize:function(){this.allowedTags="a abbr acronym address blockquote br caption cite code dd dfn div dl dt em h1 h2 h3 h4 h5 h6 hr img kbd li ol p pre q samp span sup sub strong table thead tbody td th tr ul var ";
this.allowedAttrs="href src width height alt cite datetime title class style id "
},validate:function(B,A){throw"Not implemented"
},invalidate:function(A){throw"Not implemented"
},validateStrike:function(A){A=A.replace(/<strike(>|\s+[^>]*>)/ig,"<span class=\"strike\"$1");
A=A.replace(/<\/strike>/ig,"</span>");
return A
},validateUnderline:function(A){A=A.replace(/<u(>|\s+[^>]*>)/ig,"<em class=\"underline\"$1");
A=A.replace(/<\/u>/ig,"</em>");
return A
},replaceTag:function(A,C,B){return A.replace(new RegExp("(</?)"+C+"(>|\\s+[^>]*>)","ig"),"$1"+B+"$2")
},validateSelfClosingTags:function(A){return A.replace(/<(br|hr|img)([^>]*?)>/img,function(D,B,C){return"<"+B+C+" />"
})
},removeComments:function(A){return A.replace(/<!--.*?-->/img,"")
},applyWhitelist:function(A){var C=this.allowedTags;
var B=this.allowedAttrs;
return A.replace(new RegExp("(</?)([^>]+?)(>|\\s+([^>]*?)(\\s?/?)>)","g"),function(H,K,M,G,L,I){if(C.indexOf(M)==-1){return""
}if(L){L=L.replace(/(^|\s")([^"=]+)(\s|$)/g,"$1$2=\"$2\"$3");
var J=[];
var E=L.match(/([^=]+)="[^"]*?"/g);
for(var F=0;
F<E.length;
F++){E[F]=E[F].strip();
var D=E[F].split("=")[0];
if(B.indexOf(D)!=-1){J.push(E[F])
}}L=J.join(" ");
if(L!=""){L=" "+L
}return K+M+L+I+">"
}else{return H
}})
}};
xq.Validator.createInstance=function(){if(xq.Browser.isTrident){return new xq.ValidatorTrident()
}else{if(xq.Browser.isWebkit){return new xq.ValidatorWebkit()
}else{return new xq.ValidatorGecko()
}}};
xq.ValidatorW3=Class.create();
xq.ValidatorW3.prototype={validate:function(C,B){this.validateFontColor(C);
var D=C.innerHTML;
try{D=this.replaceTag(D,"b","strong");
D=this.replaceTag(D,"i","em");
D=this.validateStrike(D);
D=this.validateUnderline(D);
if(B){D=this.performFullValidation(D)
}}catch(A){}return D
},invalidate:function(C){var F=xq.RichDom.createInstance();
F.setRoot(C);
this.invalidateFontColor(C);
var E=F.findByAttribute("class","strike");
for(var B=0;
B<E.length;
B++){if("SPAN"==E[B].nodeName){F.replaceTag("strike",E[B]).removeAttribute("class")
}}var A=F.findByAttribute("class","underline");
for(var B=0;
B<A.length;
B++){if(["EM","I"].include(A[B].nodeName)){F.replaceTag("u",A[B]).removeAttribute("class")
}}var D=F.getRoot().innerHTML;
D=this.replaceTag(D,"strong","b");
D=this.replaceTag(D,"em","i");
D=this.removeComments(D);
return D
},performFullValidation:function(A){A=this.validateSelfClosingTags(A);
A=this.applyWhitelist(A);
return A
},validateFontColor:function(D){var F=xq.RichDom.createInstance();
F.setRoot(D);
var G=D.getElementsByTagName("FONT");
for(var C=0;
C<G.length;
C++){var B=G[C];
var A=B.getAttribute("color");
if(A){var E=F.replaceTag("span",B);
E.removeAttribute("color");
E.style.color=A
}}},invalidateFontColor:function(E){var G=xq.RichDom.createInstance();
G.setRoot(E);
var D=E.getElementsByTagName("SPAN");
for(var C=0;
C<D.length;
C++){var F=D[C];
var B=F.style.color;
if(B){var A=G.replaceTag("font",F);
A.style.color="";
A.setAttribute("color",B)
}}}};
xq.ValidatorW3.prototype=Object.extend(new xq.Validator(),xq.ValidatorW3.prototype);
xq.ValidatorGecko=Class.create();
xq.ValidatorGecko.prototype={};
xq.ValidatorGecko.prototype=Object.extend(new xq.ValidatorW3(),xq.ValidatorGecko.prototype);
xq.ValidatorWebkit=Class.create();
xq.ValidatorWebkit.prototype={};
xq.ValidatorWebkit.prototype=Object.extend(new xq.ValidatorW3(),xq.ValidatorWebkit.prototype);
xq.ValidatorTrident=Class.create();
xq.ValidatorTrident.prototype={validate:function(C,B){this.validateFontColor(C);
this.validateBackgroundColor(C);
var D=C.innerHTML;
try{D=this.validateStrike(D);
D=this.validateUnderline(D);
if(B){D=this.performFullValidation(D)
}}catch(A){}return D
},invalidate:function(C){var F=xq.RichDom.createInstance();
F.setRoot(C);
this.invalidateFontColor(C);
this.invalidateBackgroundColor(C);
var E=F.findByAttribute("className","strike");
for(var B=0;
B<E.length;
B++){if("SPAN"==E[B].nodeName){F.replaceTag("strike",E[B]).removeAttribute("className")
}}var A=F.findByAttribute("className","underline");
for(var B=0;
B<A.length;
B++){if(["EM","I"].include(A[B].nodeName)){F.replaceTag("u",A[B]).removeAttribute("className")
}}var D=F.getRoot().innerHTML;
D=this.removeComments(D);
return D
},performFullValidation:function(A){A=this.lowerTagNamesAndUniformizeQuotation(A);
A=this.validateSelfClosingTags(A);
A=this.applyWhitelist(A);
return A
},validateFontColor:function(D){var F=xq.RichDom.createInstance();
F.setRoot(D);
var G=D.getElementsByTagName("FONT");
for(var C=0;
C<G.length;
C++){var B=G[C];
var A=B.getAttribute("color");
if(A){var E=F.replaceTag("span",B);
E.removeAttribute("color");
E.style.color=A
}}},invalidateFontColor:function(E){var G=xq.RichDom.createInstance();
G.setRoot(E);
var D=E.getElementsByTagName("SPAN");
for(var C=0;
C<D.length;
C++){var F=D[C];
var B=F.style.color;
if(B){var A=G.replaceTag("font",F);
A.style.color="";
A.setAttribute("color",B)
}}},validateBackgroundColor:function(B){var C=xq.RichDom.createInstance();
C.setRoot(B);
var D=B.getElementsByTagName("FONT");
for(var A=0;
A<D.length;
A++){if(D[A].style.color||D[A].style.backgroundColor){C.replaceTag("span",D[A])
}}},invalidateBackgroundColor:function(C){var D=xq.RichDom.createInstance();
D.setRoot(C);
var B=C.getElementsByTagName("SPAN");
for(var A=0;
A<B.length;
A++){if(B[A].style.color||B[A].style.backgroundColor){D.replaceTag("font",B[A])
}}},lowerTagNamesAndUniformizeQuotation:function(A){A=A.replace(/<(\/?)(\w+)([^>]*?)>/img,function(E,B,D,C){return"<"+B+D.toLowerCase()+this.correctHtmlAttrQuotation(C)+">"
}.bind(this));
return A
},correctHtmlAttrQuotation:function(A){A=A.replace(/\s(\w+?)=\s+"([^"]+)"/mg,function(D,B,C){return" "+B.toLowerCase()+"=\""+C+"\""
});
A=A.replace(/\s(\w+?)=([^ "]+)/mg,function(D,B,C){return" "+B.toLowerCase()+"=\""+C+"\""
});
return A
}};
xq.ValidatorTrident.prototype=Object.extend(new xq.Validator(),xq.ValidatorTrident.prototype);
xq.EditHistory=Class.create();
xq.EditHistory.prototype={initialize:function(B,A){if(!B){throw"IllegalArgumentException"
}this.disabled=false;
this.max=A||100;
this.rdom=B;
this.root=B.getRoot();
this.clear();
this.lastModified=Date.get()
},getLastModifiedDate:function(){return this.lastModified
},isUndoable:function(){return this.queue.length>0&&this.index>0
},isRedoable:function(){return this.queue.length>0&&this.index<this.queue.length-1
},disable:function(){this.disabled=true
},enable:function(){this.disabled=false
},undo:function(){this.pushContent();
if(this.isUndoable()){this.index--;
this.popContent();
return true
}else{return false
}},redo:function(){if(this.isRedoable()){this.index++;
this.popContent();
return true
}else{return false
}},onCommand:function(){this.lastModified=Date.get();
if(this.disabled){return false
}return this.pushContent()
},onEvent:function(A){this.lastModified=Date.get();
if(this.disabled){return false
}if("keydown"==A.type&&!(A.ctrlKey||A.metaKey)){return false
}if(["keydown","keyup","keypress"].include(A.type)&&!A.ctrlKey&&!A.altKey&&!A.metaKey&&![33,34,35,36,37,38,39,40].include(A.keyCode)){return false
}if(["keydown","keyup","keypress"].include(A.type)&&(A.ctrlKey||A.metaKey)&&[89,90].include(A.keyCode)){return false
}if([16,17,18,224].include(A.keyCode)){return false
}return this.pushContent()
},popContent:function(){this.lastModified=Date.get();
if(this.queue[this.index].caret>0){var A=this.queue[this.index].html.substring(0,this.queue[this.index].caret)+"<span id=\"caret_marker_00700\"></span>"+this.queue[this.index].html.substring(this.queue[this.index].caret);
this.root.innerHTML=A
}else{this.root.innerHTML=this.queue[this.index].html
}this.restoreCaret()
},pushContent:function(B){if(xq.Browser.isTrident&&!B&&!this.rdom.hasFocus()){return false
}var A=this.root.innerHTML;
if(A==(this.queue[this.index]?this.queue[this.index].html:null)){return false
}var C=B?-1:this.saveCaret();
if(this.queue.length>=this.max){this.queue.shift()
}else{this.index++
}this.queue.splice(this.index,this.queue.length-this.index,{html:A,caret:C});
return true
},clear:function(){this.index=-1;
this.queue=[];
this.pushContent(true)
},saveCaret:function(){if(this.rdom.hasSelection()){return null
}var B=this.rdom.saveSelection();
var A=this.rdom.pushMarker();
var D=xq.Browser.isTrident?"<SPAN class="+A.className:"<span class=\""+A.className+"\"";
var C=this.rdom.getRoot().innerHTML.indexOf(D);
this.rdom.popMarker();
this.rdom.restoreSelection(B);
return C
},restoreCaret:function(){var A=this.rdom.$("caret_marker_00700");
if(A){this.rdom.selectElement(A,true);
this.rdom.collapseSelection(false);
this.rdom.deleteNode(A)
}else{var B=this.rdom.tree.findForward(this.rdom.getRoot(),function(C){return this.isBlock(C)&&!this.hasBlocks(C)
}.bind(this.rdom.tree));
this.rdom.selectElement(B,false);
this.rdom.collapseSelection(false)
}}};
xq.Macro=Class.create();
xq.Macro.create=function(className,win){var MacroClass=eval(className);
var macro=new MacroClass(win);
return macro
};
xq.Macro.load=function(A){throw"TODO"
};
xq.Macro.prototype={initialize:function(A){this.rdom=xq.RichDom.createInstance();
this.rdom.setWin(A);
this.rdom.setRoot(A.document.body);
this.element=null;
this.canvas=null;
this.iframe=null;
this.name=null
},getName:function(){throw"Not implemented"
},insertElement:function(){this.element=this.rdom.createElement("DIV");
this.element.className="xqMacro "+this.getName();
this.rdom.insertNode(this.element);
if(xq.Browser.isTrident){this.element.contentEditable=false
}},execute:function(){this.canvas=this.rdom.createElement("DIV");
this.canvas.className="xqMacroCanvas";
this.iframe=this.rdom.createElement("IFRAME");
this.canvas.appendChild(this.iframe);
this.element.appendChild(this.canvas)
}};
xq.Macro.HelloWorld=Class.create();
Object.extend(xq.Macro.HelloWorld.prototype,xq.Macro.prototype);
Object.extend(xq.Macro.HelloWorld.prototype,{getName:function(){return"HelloWorld"
},run:function(){this.getBody().innerHTML="Hello World, "+new Date()
}});
xq.controls={};
xq.controls.QuickSearchDialog=Class.create();
xq.controls.QuickSearchDialog.prototype={initialize:function(A,B){this.xed=A;
this.rdom=xq.RichDom.createInstance();
this.rdom.setRoot(document.body);
this.param=B;
if(!this.param.renderItem){this.param.renderItem=function(C){return this.rdom.getInnerText(C)
}.bind(this)
}this.container=null
},getQuery:function(){if(!this.container){return""
}return this._getInputField().value
},onSubmit:function(A){if(this.matchCount()>0){this.param.onSelect(this.xed,this.list[this._getSelectedIndex()])
}this.close();
Event.stop(A);
return false
},onCancel:function(A){this.close()
},onBlur:function(A){setTimeout(function(){this.onCancel(A)
}.bind(this),400)
},onKey:function(C){var B=new xq.Shortcut("ESC");
var D=new xq.Shortcut("ENTER");
var A=new xq.Shortcut("UP");
var E=new xq.Shortcut("DOWN");
if(B.matches(C)){this.onCancel(C)
}else{if(D.matches(C)){this.onSubmit(C)
}else{if(A.matches(C)){this._moveSelectionUp()
}else{if(E.matches(C)){this._moveSelectionDown()
}else{this.updateList()
}}}}},onClick:function(C){var B=C.srcElement||C.target;
if(B.nodeName=="LI"){var A=this._getIndexOfLI(B);
this.param.onSelect(this.xed,this.list[A])
}},onList:function(A){this.list=A;
this.renderList(A)
},updateList:function(){this.param.listProvider(this.getQuery(),this.xed,this.onList.bind(this))
},renderList:function(D){var B=this._getListContainer();
B.innerHTML="";
for(var C=0;
C<D.length;
C++){var A=this.rdom.createElement("LI");
A.innerHTML=this.param.renderItem(D[C]);
B.appendChild(A)
}if(B.hasChildNodes()){B.firstChild.className="selected"
}},show:function(){if(!this.container){this.container=this._create()
}var A=this.rdom.insertNodeAt(this.container,this.rdom.getRoot(),"end");
this.moveToCenter("editor");
this.updateList();
this.focus()
},close:function(){this.rdom.deleteNode(this.container)
},focus:function(){this._getInputField().focus()
},moveToCenter:function(G){var D;
if(G=="window"){D=this.rdom.getDoc().documentElement
}else{D=this.xed.getDoc().documentElement
}var E=D.clientWidth;
var B=D.clientHeight;
var F=this.container.clientWidth;
var C=this.container.clientHeight;
var A=parseInt((E-F)/2);
var H=parseInt((B-C)/2);
this.container.style.left=A+"px";
this.container.style.top=H+"px"
},matchCount:function(){return this.list?this.list.length:0
},_create:function(){var A=this.rdom.createElement("DIV");
A.className="xqQuickSearch";
if(this.param.title){var F=this.rdom.createElement("H1");
F.innerHTML=this.param.title;
A.appendChild(F)
}var C=this.rdom.createElement("DIV");
C.className="input";
var D=this.rdom.createElement("FORM");
var B=this.rdom.createElement("INPUT");
B.type="text";
B.value="";
D.appendChild(B);
C.appendChild(D);
A.appendChild(C);
var E=this.rdom.createElement("OL");
Event.observe(B,"blur",this.onBlur.bindAsEventListener(this));
Event.observe(B,"keypress",this.onKey.bindAsEventListener(this));
Event.observe(E,"click",this.onClick.bindAsEventListener(this),true);
Event.observe(D,"submit",this.onSubmit.bindAsEventListener(this));
Event.observe(D,"reset",this.onCancel.bindAsEventListener(this));
A.appendChild(E);
return A
},_getInputField:function(){return this.container.getElementsByTagName("INPUT")[0]
},_getListContainer:function(){return this.container.getElementsByTagName("OL")[0]
},_getSelectedIndex:function(){var A=this._getListContainer();
for(var B=0;
B<A.childNodes.length;
B++){if(A.childNodes[B].className=="selected"){return B
}}},_getIndexOfLI:function(A){var B=this._getListContainer();
for(var C=0;
C<B.childNodes.length;
C++){if(B.childNodes[C]==A){return C
}}},_moveSelectionUp:function(){var C=this.matchCount();
if(C==0){return 
}var B=this._getSelectedIndex();
var A=this._getListContainer();
A.childNodes[B].className="";
B--;
if(B<0){B=C-1
}A.childNodes[B].className="selected"
},_moveSelectionDown:function(){var C=this.matchCount();
if(C==0){return 
}var B=this._getSelectedIndex();
var A=this._getListContainer();
A.childNodes[B].className="";
B++;
if(B>=C){B=0
}A.childNodes[B].className="selected"
}}
