/**
 * Namespace for entire Xquared classes
 */
var xq = {};

/**
 * Make given object as event source
 *
 * @param {Object} object target object
 * @param {String} prefix prefix for generated functions
 * @param {Array} events array of string which contains name of events
 */
xq.asEventSource = function(object, prefix, events) {
	object._listeners = []
	object._registerEventFirer = function(prefix, name) {
		this["_fireOn" + name] = function() {
			for(var i = 0; i < this._listeners.length; i++) {
				var listener = this._listeners[i]
				var func = listener["on" + prefix + name]
				if(func) func.apply(listener, $A(arguments))
			}
		}
	}
	object.addListener = function(l) {
		this._listeners.push(l)
	}
	
	for(var i = 0; i < events.length; i++) {
		object._registerEventFirer(prefix, events[i])
	}
}

/**
 * Returns the index of given element
 *
 * @returns {Number} index or -1
 */
Array.prototype.indexOf = function(n) {
	for(var i = 0; i < this.length; i++) {
		if(this[i] == n) return i;
	}
	
	return -1;
}

Date.preset = null;
Date.pass = function(msec) {
	if(Date.preset == null) return;
	Date.preset = new Date(Date.preset.getTime() + msec);
}
Date.get = function() {
	return Date.preset == null ? new Date() : Date.preset;
}
Date.prototype.elapsed = function(msec) {
	return Date.get().getTime() - this.getTime() >= msec;
}

String.prototype.merge = function(data) {
	var newString = this;
	for(k in data) {
		newString = newString.replace("{" + k + "}", data[k]);
	}
	return newString;
}
/**
 * @fileOverview xq.Editor manages configurations such as autocompletion and autocorrection, edit mode/normal mode switching, handles editing commands, keyboard shortcuts and other events.
 */
xq.Editor = Class.create();
xq.Editor.prototype = {
	/**
	 * Initialize editor but it doesn't automatically start designMode. setEditMode should be called after initialization.
	 *
     * @constructor
	 * @param {Element} contentElement HTML element(TEXTAREA or normal block element such as DIV) to be replaced with editable area
	 * 
	 * TODO: Should accept textarea as contentElement
	 */
	initialize: function(contentElement) {
		if(!contentElement) throw "[contentElement] is null";
		if(contentElement.nodeType != 1) throw "[contentElement] is not an element";
		
		xq.asEventSource(this, "Editor", ["ElementChanged", "BeforeEvent", "AfterEvent", "CurrentContentChanged", "StaticContentChanged", "ModeChanged"]);
		
		/**
		 * Original content element
		 * @type Element
		 */
		this.contentElement = contentElement;
		
		/**
		 * Owner document of content element
		 * @type Document
		 */
		this.doc = this.contentElement.ownerDocument;
		
		/**
		 * Body of content element
		 * @type Element
		 */
		this.body = this.doc.body;
		
		/**
		 * True means design mode, false means normal mode
		 * @type boolean
		 */
		this.editMode = false;
		
		/**
		 * RichDom instance
		 * @type xq.RichDom
		 */
		this.rdom = xq.RichDom.createInstance();

		/**
		 * Validator instance
		 * @type xq.Validator
		 */
		this.validator = xq.Validator.createInstance();
		
		/**
		 * Design mode iframe
		 * @type IFrame
		 */
		this.editorFrame = null;
		
		/**
		 * Window that contains design mode iframe
		 * @type Window
		 */
		this.editorWin = null;
		
		/**
		 * Document that contained by design mode iframe
		 * @type Document
		 */
		this.editorDoc = null;
		
		/**
		 * Body that contained by design mode iframe
		 * @type Element
		 */
		this.editorBody = null;
		
		/**
		 * Editor's configuration
		 * @type object
		 */
		this.config = {};
		this.config.enableLinkClick = false;
		this.config.shortcuts = {};
		this.config.autocorrections = {};
		this.config.autocompletions = {};
		this.config.templateProcessors = {};
		
		/**
		 * Undo/redo manager
		 * @type xq.EditHistory
		 */
		this.editHistory = null;
		
		this._contextMenuEnabled = false;
		this._contextMenuContainer = null;
		this._contextMenuHandler = null;
		this._contextMenuItems = null;

		this._validContentCache = null;
		this._lastModified = null;
		
		this.addShortcuts(this._getDefaultShortcuts());
		this.addTemplateProcessors(this._getDefaultTemplateProcessors());
	},
	
	
	
	/////////////////////////////////////////////
	// Configuration Management
	
	_getDefaultShortcuts: function() {
		if(xq.Browser.isMac) {
			// Mac FF & Safari
			return [
				{event:"Ctrl+Shift+SPACE", handler:"this.handleAutocompletion(); stop = true;"},
				{event:"ENTER", handler:"this.handleEnter(false, false)"},
				{event:"Ctrl+ENTER", handler:"this.handleEnter(true, false)"},
				{event:"Ctrl+Shift+ENTER", handler:"this.handleEnter(true, true)"},
				{event:"TAB", handler:"this.handleTab()"},
				{event:"Shift+TAB", handler:"this.handleShiftTab()"},
				{event:"DELETE", handler:"this.handleDelete()"},
				{event:"BACKSPACE", handler:"this.handleBackspace()"},
				
				{event:"Ctrl+B", handler:"this.handleStrongEmphasis()"},
				{event:"Ctrl+I", handler:"this.handleEmphasis()"},
				{event:"Ctrl+U", handler:"this.handleUnderline()"},
				{event:"Ctrl+K", handler:"this.handleStrike()"},
				{event:"Meta+Z", handler:"this.handleUndo()"},
				{event:"Meta+Shift+Z", handler:"this.handleRedo()"},
				{event:"Meta+Y", handler:"this.handleRedo()"}
			];
		} else if(xq.Browser.isUbunto) {
			//  Ubunto FF
			return [
				{event:"Ctrl+SPACE", handler:"this.handleAutocompletion(); stop = true;"},
				{event:"ENTER", handler:"this.handleEnter(false, false)"},
				{event:"Ctrl+ENTER", handler:"this.handleEnter(true, false)"},
				{event:"Ctrl+Shift+ENTER", handler:"this.handleEnter(true, true)"},
				{event:"TAB", handler:"this.handleTab()"},
				{event:"Shift+TAB", handler:"this.handleShiftTab()"},
				{event:"DELETE", handler:"this.handleDelete()"},
				{event:"BACKSPACE", handler:"this.handleBackspace()"},
			
				{event:"Ctrl+B", handler:"this.handleStrongEmphasis()"},
				{event:"Ctrl+I", handler:"this.handleEmphasis()"},
				{event:"Ctrl+U", handler:"this.handleUnderline()"},
				{event:"Ctrl+K", handler:"this.handleStrike()"},
				{event:"Ctrl+Z", handler:"this.handleUndo()"},
				{event:"Ctrl+Y", handler:"this.handleRedo()"}
			];
		} else {
			// Win IE & FF
			return [
				{event:"Ctrl+SPACE", handler:"this.handleAutocompletion(); stop = true;"},
				{event:"ENTER", handler:"this.handleEnter(false, false)"},
				{event:"Ctrl+ENTER", handler:"this.handleEnter(true, false)"},
				{event:"Ctrl+Shift+ENTER", handler:"this.handleEnter(true, true)"},
				{event:"TAB", handler:"this.handleTab()"},
				{event:"Shift+TAB", handler:"this.handleShiftTab()"},
				{event:"DELETE", handler:"this.handleDelete()"},
				{event:"BACKSPACE", handler:"this.handleBackspace()"},
			
				{event:"Ctrl+B", handler:"this.handleStrongEmphasis()"},
				{event:"Ctrl+I", handler:"this.handleEmphasis()"},
				{event:"Ctrl+U", handler:"this.handleUnderline()"},
				{event:"Ctrl+K", handler:"this.handleStrike()"},
				{event:"Ctrl+Z", handler:"this.handleUndo()"},
				{event:"Ctrl+Y", handler:"this.handleRedo()"}
			];
		}
	},
	
	_getDefaultTemplateProcessors: function() {
		return [
			{
				id:"predefinedKeywordProcessor",
				handler:function(html) {
					var today = Date.get();
					var keywords = {
						year: today.getFullYear(),
						month: today.getMonth() + 1,
						date: today.getDate(),
						hour: today.getHours(),
						min: today.getMinutes(),
						sec: today.getSeconds()
					};
					
					return html.replace(/\{xq:(year|month|date|hour|min|sec)\}/img, function(text, keyword) {
						return keywords[keyword] || keyword;
					});
				}
			}
		];
	},
	
	/**
	 * Adds or replaces keyboard shortcut.
	 *
	 * @param {String} shortcut keymap expression like "CTRL+Space"
	 * @param {Object} handler string or function to be evaluated or called
	 */
	addShortcut: function(shortcut, handler) {
		this.config.shortcuts[shortcut] = {"event":new xq.Shortcut(shortcut), "handler":handler};
	},
	
	/**
	 * Adds several keyboard shortcuts at once.
	 *
	 * @param {Array} list of shortcuts. each element should have following structure: {event:"keymap expression", handler:handler}
	 */
	addShortcuts: function(list) {
		list.each(function(shortcut) {
			this.addShortcut(shortcut.event, shortcut.handler);
		}.bind(this));
	},

	/**
	 * Returns keyboard shortcut matches with given keymap expression.
	 *
	 * @param {String} shortcut keymap expression like "CTRL+Space"
	 */
	getShortcut: function(shortcut) {return this.config.shortcuts[shortcut];},

	/**
	 * Returns entire keyboard shortcuts' map
	 */
	getShortcuts: function() {return this.config.shortcuts;},
	
	/**
	 * Remove keyboard shortcut matches with given keymap expression.
	 *
	 * @param {String} shortcut keymap expression like "CTRL+Space"
	 */
	removeShortcut: function(shortcut) {delete this.config.shortcuts[shortcut];},
	
	/**
	 * Adds or replaces autocorrection handler.
	 *
	 * @param {String} id unique identifier
	 * @param {Object} criteria regex pattern or function to be used as a criterion for match
	 * @param {Object} handler string or function to be evaluated or called when criteria met
	 */
	addAutocorrection: function(id, criteria, handler) {
		if(criteria.exec) {
			var pattern = criteria;
			criteria = function(text) {return text.match(pattern)};
		}
		this.config.autocorrections[id] = {"criteria":criteria, "handler":handler};
	},
	
	/**
	 * Adds several autocorrection handlers at once.
	 *
	 * @param {Array} list of autocorrection. each element should have following structure: {id:"identifier", criteria:criteria, handler:handler}
	 */
	addAutocorrections: function(list) {
		list.each(function(ac) {
			this.addAutocorrection(ac.id, ac.criteria, ac.handler);
		}.bind(this));
	},
	
	/**
	 * Returns autocorrection handler matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	getAutocorrection: function(id) {return this.config.autocorrection[id];},

	/**
	 * Returns entire autocorrections' map
	 */
	getAutocorrections: function() {return this.config.autocorrections;},

	/**
	 * Removes autocorrection handler matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	removeAutocorrection: function(id) {delete this.config.autocorrections[id];},
	
	/**
	 * Adds or replaces autocompletion handler.
	 *
	 * @param {String} id unique identifier
	 * @param {Object} criteria regex pattern or function to be used as a criterion for match
	 * @param {Object} handler string or function to be evaluated or called when criteria met
	 */
	addAutocompletion: function(id, criteria, handler) {
		if(criteria.exec) {
			var pattern = criteria;
			criteria = function(text) {
				var m = pattern.exec(text);
				return m ? m.index : -1;
			};
		}
		this.config.autocompletions[id] = {"criteria":criteria, "handler":handler};
	},
	
	/**
	 * Adds several autocompletion handlers at once.
	 *
	 * @param {Array} list of autocompletion. each element should have following structure: {id:"identifier", criteria:criteria, handler:handler}
	 */
	addAutocompletions: function(list) {
		list.each(function(ac) {
			this.addAutocompletion(ac.id, ac.criteria, ac.handler);
		}.bind(this));
	},
	
	/**
	 * Returns autocompletion handler matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	getAutocompletion: function(id) {return this.config.autocompletions[id];},

	/**
	 * Returns entire autocompletions' map
	 */
	getAutocompletions: function() {return this.config.autocompletions;},

	/**
	 * Removes autocompletion handler matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	removeAutocompletion: function(id) {delete this.config.autocompletions[id];},

	/**
	 * Adds or replaces template processor.
	 *
	 * @param {String} id unique identifier
	 * @param {Object} handler string or function to be evaluated or called when template inserted
	 */
	addTemplateProcessor: function(id, handler) {
		this.config.templateProcessors[id] = {"handler":handler};
	},
	
	/**
	 * Adds several template processors at once.
	 *
	 * @param {Array} list of template processors. Each element should have following structure: {id:"identifier", handler:handler}
	 */
	addTemplateProcessors: function(list) {
		list.each(function(tp) {
			this.addTemplateProcessor(tp.id, tp.handler);
		}.bind(this));
	},
	
	/**
	 * Returns template processor matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	getTemplateProcessor: function(id) {return this.config.templateProcessors[id];},

	/**
	 * Returns entire template processors' map
	 */
	getTemplateProcessors: function() {return this.config.templateProcessors;},

	/**
	 * Removes template processor matches with given id
	 *
	 * @param {String} id unique identifier
	 */
	removeTemplateProcessors: function(id) {delete this.config.templateProcessors[id];},



	/////////////////////////////////////////////
	// Edit mode/normal mode management
	
	/**
	 * Switches between edit-mode/normal mode.
	 *
	 * @param {boolean} on true means editing-mode, false means readonly-mode
	 */
	setEditMode: function(on) {
		if(this.editMode == on) return;
		
		if(on) {
			this.contentElement.style.display = "none";
			if(!this.editorFrame) {
				this._createEditorFrame();
				this._registerEventHandlers();
			}
			this.loadCurrentContentFromStaticContent();
			this.editorFrame.style.display = "block";

			if(!xq.Browser.isTrident) {
				// Without it, Firefox doesn't display embedded SWF
				window.setTimeout(function() {this.getDoc().designMode = 'On';}.bind(this), 0);
			}
		} else {
			this.editorFrame.style.display = "none";
			this.setStaticContent(this.getCurrentContent());
			this.contentElement.style.display = "block";
		}
		
		this.editMode = on;
		this._fireOnModeChanged(this, on);
	},
	
	/**
	 * Load CSS into editing-mode document
	 *
	 * @param {string} path URL
	 */
	loadStylesheet: function(path) {
		var head = this.editorDoc.getElementsByTagName("HEAD")[0];
		var link = this.editorDoc.createElement("LINK");
		link.rel = "Stylesheet";
		link.type = "text/css";
		link.href = path;
		head.appendChild(link);
	},
	
	/**
	 * Sets editor's dynamic content from static content
	 */
	loadCurrentContentFromStaticContent: function() {
		var html = this.validator.invalidate(this.contentElement);
		html = this.removeUnnecessarySpaces(html);
		
		if(html.blank()) {
			this.rdom.clearRoot();
		} else {
			this.rdom.getRoot().innerHTML = html;
		}

		this.rdom.wrapAllInlineOrTextNodesAs("P", this.rdom.getRoot(), true);

		this.editHistory.clear();
		this._fireOnCurrentContentChanged(this);
	},

	removeUnnecessarySpaces: function(html) {
		var blocks = this.rdom.tree.getBlockTags().join("|");
		var regex = new RegExp("\\s*<(/?)(" + blocks + ")>\\s*", "img")
		return html.replace(regex, '<$1$2>');
	},
	
	/**
	 * Gets editor's dynamic content
	 * 
	 * @return {Object} HTML String
	 */
	getCurrentContent: function(performFullValidation) {
		if(!performFullValidation) return this.validator.validate(this.rdom.getRoot());
		
		var lastModified = this.editHistory.getLastModifiedDate();
		if(this._lastModified != lastModified) {
			this._validContentCache = this.validator.validate(this.rdom.getRoot(), performFullValidation);
			this._lastModified = lastModified;
		}
		return this._validContentCache;
	},
	
	/**
	 * Sets editor's original content
	 *
	 * @param {Object} content HTML String
	 */
	setStaticContent: function(content) {
		this.contentElement.innerHTML = content;
		this._fireOnStaticContentChanged(this, content);
	},
	
	/**
	 * Gets editor's original content
	 *
	 * @return {Object} HTML String
	 */
	getStaticContent: function() {
		return this.contentElement.innerHTML;
	},
	
	/**
	 * Gives focus to editor
	 */
	focus: function() {
		this.rdom.focus();
	},
	
	/**
	 * Returns designmode iframe object
	 */
	getFrame: function() {
		return this.editorFrame;
	},
	
	/**
	 * Returns designmode window object
	 */
	getWin: function() {
		return this.editorWin;
	},
	
	/**
	 * Returns designmode document object
	 */
	getDoc: function() {
		return this.editorDoc;
	},
	
	/**
	 * Returns designmode body object
	 */
	getBody: function() {
		return this.editorBody;
	},
	
	_createEditorFrame: function() {
		this.editorFrame = this.doc.createElement('iframe');
		this.rdom.setAttributes(this.editorFrame, {
			"frameBorder": "0",
			"marginWidth": "0",
			"marginHeight": "0",
			"leftMargin": "0",
			"topMargin": "0",
			"allowTransparency": "true"
		});
		
		this.contentElement.parentNode.insertBefore(this.editorFrame, this.contentElement);
		
		var doc = this.editorFrame.contentWindow.document;
		
		doc.open();
		doc.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">')
		doc.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">')
		doc.write('<head>')
		doc.write('<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />')
		doc.write('<title>XQuared</title>')
		doc.write('</head>')
		doc.write(xq.Browser.isTrident ? '<body contentEditable="true"><p></p></body>' : '<body><p></p></body>')
		doc.write('</html>')
		doc.close();
		
		this.editorWin = this.editorFrame.contentWindow;
		this.editorDoc = this.editorWin.document;
		this.editorBody = this.editorDoc.body;
		this.editorBody.className = "xed";
		this.rdom.setWin(this.editorWin);
		this.rdom.setRoot(this.editorBody);
		this.editHistory = new xq.EditHistory(this.rdom);
	},
	


	/////////////////////////////////////////////
	// Event Management
	
	_registerEventHandlers: function() {
		var events = ['keydown', 'click', 'keyup', 'mouseup', 'contextmenu', 'scroll'];
		if(xq.Browser.isMac && xq.Browser.isGecko) events.push('keypress');
		
		for(var i = 0; i < events.length; i++) {
			Event.observe(this.getDoc(), events[i], this._handleEvent.bindAsEventListener(this));
		}
	},
	
	_handleEvent: function(e) {
		this._fireOnBeforeEvent(this, e);
		
		var stop = false;
		
		if(e.type == 'click' && this.config.enableLinkClick) {
			var a = this.rdom.getParentElementOf(e.target || e.srcElement, ["A"]);
			if(a) stop = this.handleClick(e, a);
		} else if(e.type == (xq.Browser.isMac && xq.Browser.isGecko ? "keypress" : "keydown")) {
			this.rdom.correctParagraph();
			for(var key in this.config.shortcuts) {
				if(!this.config.shortcuts[key].event.matches(e)) continue;
				
				var handler = this.config.shortcuts[key].handler;
				var xed = this;
				stop = (typeof handler == "function") ? handler(this) : eval(handler)
			}
		} else if(["mouseup", "keyup", "contextmenu"].include(e.type)) {
			this.rdom.correctParagraph();
		}
		
		var curFocusElement = this.rdom.getCurrentElement();
		
		if(this._lastFocusElement != curFocusElement) {
			if(!this.rdom.tree.isBlockContainer(this._lastFocusElement)) this.rdom.removeTrailingWhitespace(this._lastFocusElement);
			this._fireOnElementChanged(this._lastFocusElement, curFocusElement);
			this._lastFocusElement = curFocusElement;
		}
		
		if(stop) Event.stop(e);
		
		var historyAdded = this.editHistory.onEvent(e);
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		this._fireOnAfterEvent(this, e);
		
		return !stop;
	},

	/**
	 * TODO: remove dup with handleAutocompletion
	 */
	handleAutocorrection: function() {
		var block = this.rdom.getCurrentBlockElement();
		
		// TODO: use complete unescape algorithm
		var text = this.rdom.getInnerText(block).replace(/&nbsp;/gi, " ");
		
		var acs = this.config.autocorrections;
		var performed = false;
		
		this.editHistory.disable();
		
		var stop = false;
		for(var key in acs) {
			var ac = acs[key];
			if(ac.criteria(text)) {
				try {
					if(typeof ac.handler == "String") {
						var xed = this;
						var rdom = this.rdom;
						eval(ac.handler);
					} else {
						stop = ac.handler(this, this.rdom, block, text);
					}
				} catch(ignored) {}
				
				block = this.rdom.getCurrentBlockElement();
				text = this.rdom.getInnerText(block);
				
				performed = true;
				if(stop) break;
			}
			
		}
		this.editHistory.enable();
		
		if(performed) this.editHistory.onCommand();
		
		return stop;
	},
	
	/**
	 * TODO: remove dup with handleAutocorrection
	 */
	handleAutocompletion: function() {
		var acs = $H(this.config.autocompletions);
		if(acs.size() == 0) return;

		if(this.rdom.hasSelection()) {
			var text = this.rdom.getSelectionAsText();
			this.rdom.deleteSelection();
			var wrapper = this.rdom.insertNode(this.rdom.createElement("SPAN"));
			wrapper.innerHTML = text;
			
			var marker = this.rdom.pushMarker();
			
			var filtered = 
				acs.map(function(pair) {
					return [pair.key, pair.value.criteria(text)];
				}.bind(this)).findAll(function(elem) {
					return elem[1] != -1;
				}).sortBy(function(elem) {
					return elem[1];
				});
			
			if(filtered.length == 0) {
				this.rdom.popMarker(true);
				return;
			}
			
			var ac = acs[filtered[0][0]];
			
			this.editHistory.disable();
		} else {
			var marker = this.rdom.pushMarker();
			
			var filtered = 
				acs.map(function(pair) {
					return [pair.key, this.rdom.testSmartWrap(marker, pair.value.criteria).textIndex];
				}.bind(this)).findAll(function(elem) {
					return elem[1] != -1;
				}).sortBy(function(elem) {
					return elem[1];
				});
			
			if(filtered.length == 0) {
				this.rdom.popMarker(true);
				return;
			}
			
			var ac = acs[filtered[0][0]];
			
			this.editHistory.disable();
			
			var wrapper = this.rdom.smartWrap(marker, "SPAN", ac.criteria);
		}

		var block = this.rdom.getCurrentBlockElement();
		
		// TODO: use complete unescape algorithm
		var text = this.rdom.getInnerText(wrapper).replace(/&nbsp;/gi, " ");
		
		try {
			// call handler
			if(typeof ac.handler == "String") {
				var xed = this;
				var rdom = this.rdom;
				eval(ac.handler);
			} else {
				ac.handler(this, this.rdom, block, wrapper, text);
			}
		} catch(ignored) {}
		
		try {
			this.rdom.unwrapElement(wrapper);
		} catch(ignored) {}

		
		if(this.rdom.isEmptyBlock(block)) this.rdom.correctEmptyElement(block);
		
		this.editHistory.enable();
		this.editHistory.onCommand();
		
		this.rdom.popMarker(true);
	},

	/**
	 * Handles click event
	 *
	 * @param {Event} e click event
	 * @param {Element} target target element(usually has A tag)
	 */
	handleClick: function(e, target) {
		var href = decodeURI(target.href);
		if(!xq.Browser.isTrident) {
			if(!e.ctrlKey && !e.shiftKey && e.button != 1) {
				window.location.href = href;
				return true;
			}
		} else {
			if(e.shiftKey) {
				window.open(href, "_blank");
			} else {
				window.location.href = href;
			}
			return true;
		}
		
		return false;
	},
	
	/**
	 * Called when enter key pressed.
	 *
	 * @param {boolean} skipAutocorrection if set true, skips autocorrection
	 * @param {boolean} forceInsertParagraph if set true, inserts paragraph
	 */
	handleEnter: function(skipAutocorrection, forceInsertParagraph) {
		// If it has selection, perform default action.
		if(this.rdom.hasSelection()) return false;
		
		// Perform autocorrection
		if(!skipAutocorrection && this.handleAutocorrection()) return true;
		
		var atEmptyBlock = this.rdom.isCaretAtEmptyBlock();
		var atStart = atEmptyBlock || this.rdom.isCaretAtBlockStart();
		var atEnd = atEmptyBlock || (!atStart && this.rdom.isCaretAtBlockEnd());
		var atEdge = atEmptyBlock || atStart || atEnd;
		
		if(!atEdge) {
			var block = this.rdom.getCurrentBlockElement();
			var marker = this.rdom.pushMarker();
			
			if(this.rdom.isFirstLiWithNestedList(block) && !forceInsertParagraph) {
				var parent = block.parentNode;
				this.rdom.unwrapElement(block);
				block = parent;
			} else if(block.nodeName != "LI" && this.rdom.tree.isBlockContainer(block)) {
				block = this.rdom.wrapAllInlineOrTextNodesAs("P", block, true).first();
			}
			this.rdom.splitElementUpto(marker, block);
			
			this.rdom.popMarker(true);
		} else if(atEmptyBlock) {
			this._handleEnterAtEmptyBlock();
		} else {
			this._handleEnterAtEdge(atStart, forceInsertParagraph);
		}
		
		return true;
	},
	
	/**
	 * Moves current block upward or downward
	 *
	 * @param {boolean} up moves current block upward
	 */
	handleMoveBlock: function(up) {
		var block = this.rdom.moveBlock(this.rdom.getCurrentBlockElement(), up);
		if(block) {
			this.rdom.selectElement(block, false);
			block.scrollIntoView(false);
			
			var historyAdded = this.editHistory.onCommand();
			if(historyAdded) this._fireOnCurrentContentChanged(this);
		}
		return true;
	},
	
	/**
	 * Called when tab key pressed
	 */
	handleTab: function() {
		var hasSelection = this.rdom.hasSelection();
		
		if(hasSelection) {
			this.handleIndent();
		} else if (this.rdom.getParentElementOf(this.rdom.getCurrentBlockElement(), ["TD", "TH"])) {
			this.handleMoveToNextCell();
		} else if (this.rdom.isCaretAtBlockStart()) {
			this.handleIndent();
		} else {
			this.handleInsertTab();
		}

		return true;
	},

	/**
	 * Inserts three non-breaking spaces
	 */
	handleInsertTab: function() {
		this.rdom.insertHtml('&nbsp;');
		this.rdom.insertHtml('&nbsp;');
		this.rdom.insertHtml('&nbsp;');
		
		return true;
	},
	
	/**
	 * Called when shift+tab key pressed
	 */
	handleShiftTab: function() {
		var hasSelection = this.rdom.hasSelection();
		
		if(hasSelection) {
			this.handleOutdent();
		} else if (this.rdom.getParentElementOf(this.rdom.getCurrentBlockElement(), ["TD", "TH"])) {
			this.handleMoveToPreviousCell();
		} else {
			this.handleOutdent();
		}
		
		return true;
	},
	
	/**
	 * Called when delete key pressed
	 */
	handleDelete: function() {
		if(this.rdom.hasSelection() || !this.rdom.isCaretAtBlockEnd()) return false;
		return this._handleMerge(true);
	},
	
	/**
	 * Called when backspace key pressed
	 */
	handleBackspace: function() {
		if(this.rdom.hasSelection() || !this.rdom.isCaretAtBlockStart()) return false;
		return this._handleMerge(false);
	},
	
	_handleMerge: function(withNext) {
		var block = this.rdom.getCurrentBlockElement();
		
		// save caret position;
		var marker = this.rdom.pushMarker();

		// perform merge
		var merged =
			this.rdom.mergeElement(block, withNext, withNext) ||
			this.rdom.extractOutElementFromParent(block) ||
			block;
		
		// restore caret position
		this.rdom.popMarker(true);
		this.rdom.correctEmptyElement(merged);
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * (in table) Moves caret to the next cell
	 */
	handleMoveToNextCell: function() {
		this._handleMoveToCell("next");
	},

	/**
	 * (in table) Moves caret to the previous cell
	 */
	handleMoveToPreviousCell: function() {
		this._handleMoveToCell("prev");
	},

	/**
	 * (in table) Moves caret to the above cell
	 */
	handleMoveToAboveCell: function() {
		this._handleMoveToCell("above");
	},

	/**
	 * (in table) Moves caret to the below cell
	 */
	handleMoveToBelowCell: function() {
		this._handleMoveToCell("below");
	},

	_handleMoveToCell: function(dir) {
		var block = this.rdom.getCurrentBlockElement();
		var cell = this.rdom.getParentElementOf(block, ["TD", "TH"]);
		var table = this.rdom.getParentElementOf(cell, ["TABLE"]);
		var rtable = new xq.RichTable(this.rdom, table);
		var target = null;
		
		if(["next", "prev"].include(dir)) {
			var toNext = dir == "next";
			target = toNext ? rtable.getNextCellOf(cell) : rtable.getPreviousCellOf(cell);
		} else {
			var toBelow = dir == "below";
			target = toBelow ? rtable.getBelowCellOf(cell) : rtable.getAboveCellOf(cell);
		}

		if(!target) {
			var finder = function(node) {return !['TD', 'TH'].include(node.nodeName) && this.tree.isBlock(node) && !this.tree.hasBlocks(node);}.bind(this.rdom);
			var exitCondition = function(node) {return this.tree.isBlock(node) && !this.tree.isDescendantOf(this.getRoot(), node)}.bind(this.rdom);
			
			target = (toNext || toBelow) ? 
				this.rdom.tree.findForward(cell, finder, exitCondition) :
				this.rdom.tree.findBackward(table, finder, exitCondition);
		}
		
		if(target) this.rdom.placeCaretAtStartOf(target);
	},
	
	/**
	 * Applies STRONG tag
	 */
	handleStrongEmphasis: function() {
		this.rdom.applyStrongEmphasis();
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Applies EM tag
	 */
	handleEmphasis: function() {
		this.rdom.applyEmphasis();
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Applies EM.underline tag
	 */
	handleUnderline: function() {
		this.rdom.applyUnderline();
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Applies SPAN.strike tag
	 */
	handleStrike: function() {
		this.rdom.applyStrike();

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},
	
	/**
	 * Applies Q tag
	 */
	handleQuote: function() {
		this.rdom.applyQuote();

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},

	/**
	 * Removes all style
	 */
	handleRemoveFormat: function() {
		this.rdom.applyRemoveFormat();

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},
	
	/**
	 * Inserts table
	 *
	 * @param {Number} cols number of columns
	 * @param {Number} rows number of rows
	 * @param {String} headerPosition position of THs. "T" or "L" or "TL". "T" means top, "L" means left.
	 */
	handleTable: function(cols, rows, headerPositions) {
		var cur = this.rdom.getCurrentBlockElement();
		if(this.rdom.getParentElementOf(cur, ["TABLE"])) return true;
		
		var rtable = xq.RichTable.create(this.rdom, cols, rows, headerPositions);
		if(this.rdom.tree.isBlockContainer(cur)) {
			var wrappers = this.rdom.wrapAllInlineOrTextNodesAs("P", cur, true);
			cur = wrappers.last();
		}
		var tableDom = this.rdom.insertNodeAt(rtable.getDom(), cur, "after");
		this.rdom.placeCaretAtStartOf(rtable.getCellAt(0, 0));
		
		if(this.rdom.isEmptyBlock(cur)) this.rdom.deleteNode(cur, true);
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Performs block indentation
	 */
	handleIndent: function() {
		if(this.rdom.hasSelection()) {
			var blocks = this.rdom.getBlockElementsAtSelectionEdge(true, true);
			if(blocks.first() != blocks.last()) {
				var affected = this.rdom.indentElements(blocks.first(), blocks.last());
				this.rdom.selectBlocksBetween(affected.first(), affected.last());
				
				var historyAdded = this.editHistory.onCommand();
				if(historyAdded) this._fireOnCurrentContentChanged(this);
				
				return true;
			}
		}
		
		var block = this.rdom.getCurrentBlockElement();
		var affected = this.rdom.indentElement(block);
		
		if(affected) {
			this.rdom.placeCaretAtStartOf(affected);
			
			var historyAdded = this.editHistory.onCommand();
			if(historyAdded) this._fireOnCurrentContentChanged(this);
		}
		
		return true;
	},

	/**
	 * Performs block outdentation
	 */
	handleOutdent: function() {
		if(this.rdom.hasSelection()) {
			var blocks = this.rdom.getBlockElementsAtSelectionEdge(true, true);
			if(blocks.first() != blocks.last()) {
				var affected = this.rdom.outdentElements(blocks.first(), blocks.last());
				this.rdom.selectBlocksBetween(affected.first(), affected.last());
				
				var historyAdded = this.editHistory.onCommand();
				if(historyAdded) this._fireOnCurrentContentChanged(this);
				
				return true;
			}
		}
		
		var block = this.rdom.getCurrentBlockElement();
		var affected = this.rdom.outdentElement(block);
		
		if(affected) {
			this.rdom.placeCaretAtStartOf(affected);

			var historyAdded = this.editHistory.onCommand();
			if(historyAdded) this._fireOnCurrentContentChanged(this);
		}
		
		return true;
	},
	
	/**
	 * Applies list.
	 *
	 * @param {String} type "UL" or "OL" or "CODE". CODE generates OL.code
	 */
	handleList: function(type) {
		if(this.rdom.hasSelection()) {
			var blocks = this.rdom.getBlockElementsAtSelectionEdge(true, true);
			if(blocks.first() != blocks.last()) {
				blocks = this.rdom.applyLists(blocks.first(), blocks.last(), type);
			} else {
				blocks[0] = blocks[1] = this.rdom.applyList(blocks.first(), type);
			}
			this.rdom.selectBlocksBetween(blocks.first(), blocks.last());
		} else {
			var block = this.rdom.applyList(this.rdom.getCurrentBlockElement(), type);
			this.rdom.placeCaretAtStartOf(block);
		}
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Applies justification
	 *
	 * @param {String} dir "left", "center", "right" or "both"
	 */
	handleJustify: function(dir) {
		var block = this.rdom.getCurrentBlockElement();
		var dir = (dir == "left" || dir == "both") && (block.style.textAlign == "left" || block.style.textAlign == "") ? "both" : dir;
		
		if(this.rdom.hasSelection()) {
			var blocks = this.rdom.getSelectedBlockElements();
			this.rdom.justifyBlocks(blocks, dir);
			this.rdom.selectBlocksBetween(blocks.first(), blocks.last());
		} else {
			this.rdom.justifyBlock(block, dir);
		}
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Removes current block element
	 */
	handleRemoveBlock: function() {
		var block = this.rdom.getCurrentBlockElement();
		var blockToMove = this.rdom.removeBlock(block);
		this.rdom.placeCaretAtStartOf(blockToMove);
		blockToMove.scrollIntoView(false);
	},
	
	/**
	 * Applies background color
	 *
	 * @param {String} color CSS color string
	 */
	handleBackgroundColor: function(color) {
		this.rdom.applyBackgroundColor(color);

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},
	
	/**
	 * Applies foreground color
	 *
	 * @param {String} color CSS color string
	 */
	handleForegroundColor: function(color) {
		this.rdom.applyForegroundColor(color);

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},

	/**
	 * Applies superscription
	 */	
	handleSuperscription: function() {
		this.rdom.applySuperscription();

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},
	
	/**
	 * Applies subscription
	 */	
	handleSubscription: function() {
		this.rdom.applySubscription();

		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);

		return true;
	},
	
	/**
	 * Change of wrap current block's tag
	 */	
	handleApplyBlock: function(tagName) {
		if(this.rdom.hasSelection()) {
			var blocks = this.rdom.getBlockElementsAtSelectionEdge(true, true);
			if(blocks.first() != blocks.last()) {
				var applied = this.rdom.applyTagIntoElements(tagName, blocks.first(), blocks.last());
				this.rdom.selectBlocksBetween(applied.first(), applied.last());
				
				var historyAdded = this.editHistory.onCommand();
				if(historyAdded) this._fireOnCurrentContentChanged(this);
				
				return true;
			}
		}
		
		var block = this.rdom.getCurrentBlockElement();
		this.rdom.pushMarker();
		var applied =
			this.rdom.applyTagIntoElement(tagName, block) ||
			block;
		this.rdom.popMarker(true);

		if(this.rdom.isEmptyBlock(applied)) {
			this.rdom.correctEmptyElement(applied);
			this.rdom.placeCaretAtStartOf(applied);
		}
		
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},

	/**
	 * Inserts seperator (HR)
	 */
	handleSeparator: function() {
		this.rdom.collapseSelection();
		
		// get current block
		var curBlock = this.rdom.getCurrentBlockElement();
		if(this.rdom.tree.isBlockContainer(curBlock)) curBlock = this.rdom.wrapAllInlineOrTextNodesAs("P", curBlock, true)[0];
		
		// separate block into two pieces
		var marker = this.rdom.pushMarker();
		var newBlock = this.rdom.splitElementUpto(marker, curBlock);
		this.rdom.popMarker();
		this.rdom.correctEmptyElement(newBlock);
		
		// insert P and HR between two pieces
		var hrContainer = this.rdom.insertNodeAt(this.rdom.createElement("P"), newBlock, "before");
		hrContainer.appendChild(this.rdom.createElement("HR"));
		
		// delete current block if it is empty
		if(this.rdom.isEmptyBlock(curBlock)) this.rdom.deleteNode(curBlock, true);
		this.rdom.placeCaretAtStartOf(newBlock);
		
		// add undo history
		var historyAdded = this.editHistory.onCommand();
		if(historyAdded) this._fireOnCurrentContentChanged(this);
		
		return true;
	},
	
	/**
	 * Performs UNDO
	 */
	handleUndo: function() {
		var performed = this.editHistory.undo();
		if(performed) this._fireOnCurrentContentChanged(this);
		
		this.rdom.getCurrentBlockElement().scrollIntoView(false);
		return true;
	},
	
	/**
	 * Performs REDO
	 */
	handleRedo: function() {
		var performed = this.editHistory.redo();
		if(performed) this._fireOnCurrentContentChanged(this);
		
		this.rdom.getCurrentBlockElement().scrollIntoView(false);
		return true;
	},
	
	
	
	addContextMenuHandler: function(func) {
		if (!this._contextMenuEnabled) {
			Event.observe(this.getDoc(), 'contextmenu', this.onContextMenu.bindAsEventListener(this));
			this._contextMenuEnabled = true;
		}
		this._contextMenuHandler = func;
	},
	
	onContextMenu: function(e) {
		if (xq.Browser.isWebkit) {
			if (e.metaKey || Event.isLeftClick(e)) return false;
		} else if (e.shiftKey || e.ctrlKey || e.altKey) {
			return false;
		}
		
		if (this._contextMenuHandler) {
			var x=Event.pointerX(e);
			var y=Event.pointerY(e);
			var pos=Position.cumulativeOffset(this.getFrame());
			x+=pos[0];
			y+=pos[1];
			this._contextMenuTargetElement = e.target || e.srcElement;
			
			//TODO: Safari on Windows doesn't work with context key(app key)
			if (!x || !y || xq.Browser.isTrident) {
				var pos = Position.cumulativeOffset(this._contextMenuTargetElement);
				var posFrame = Position.cumulativeOffset(this.getFrame());
				x = pos[0] + posFrame[0] - this.getDoc().documentElement.scrollLeft;
				y = pos[1] + posFrame[1] - this.getDoc().documentElement.scrollTop;
			}
			
			var stop = this._contextMenuHandler(this, this._contextMenuTargetElement, x, y);
			if(stop) Event.stop(e);
			return stop;
		}
		
		return false;
	},
	
	showContextMenu: function(menuItems, x, y) {
		if (!menuItems || menuItems.length <= 0) return;
		
		if (!this._contextMenuContainer) {
			this._contextMenuContainer = this.doc.createElement('UL');
			this._contextMenuContainer.className = 'xqContextMenu';
			with (this._contextMenuContainer.style) {
				position='absolute';
				display='none';
				zIndex='1000';
			}
			
			Event.observe(this.doc, 'click', this._contextMenuClicked.bindAsEventListener(this));
			Event.observe(this.rdom.getDoc(), 'click', this.hideContextMenu.bindAsEventListener(this));
			
			this.body.appendChild(this._contextMenuContainer);
		} else {
			while (this._contextMenuContainer.childNodes.length > 0)
				this._contextMenuContainer.removeChild(this._contextMenuContainer.childNodes[0]);
		}
		
		for (var i=0; i < menuItems.length; i++) {
			menuItems[i]._node = this._addContextMenuItem(menuItems[i]);
		}

		this._contextMenuContainer.style.display='block';
		this._contextMenuContainer.style.left=x+'px';
		this._contextMenuContainer.style.top=y+'px';

		this._contextMenuItems = menuItems;
	},
	
	hideContextMenu: function() {
		if (this._contextMenuContainer)
			this._contextMenuContainer.style.display='none';
	},
	
	_addContextMenuItem: function(item) {
		if (!this._contextMenuContainer) throw "No conext menu container exists";
		
		var node = this.doc.createElement('LI');
		if (item.disabled) node.className += ' disabled'; 
		
		if (item.title == '----') {
			node.innerHTML = '&nbsp;';
			node.className = 'separator';
		} else {
			if(item.func) {
				node.innerHTML = '<a href="javascript:;">'+(item.title.toString().escapeHTML())+'</a>';
			} else {
				node.innerHTML = (item.title.toString().escapeHTML());
			}
		}
		
		if(item.className) node.className = item.className;
		
		this._contextMenuContainer.appendChild(node);
		
		return node;
	},
	
	_contextMenuClicked: function(e) {
		this.hideContextMenu();
		
		if (!this._contextMenuContainer) return;
		
		var node = Event.findElement(e, 'LI');
		if (!node || !this.rdom.tree.isDescendantOf(this._contextMenuContainer, node)) return;
		
		for (var i=0; i < this._contextMenuItems.length; i++) {
			if (this._contextMenuItems[i]._node == node) {
				if (!this._contextMenuItems[i].disabled && this._contextMenuItems[i].func) {
					this._contextMenuItems[i].func(this, this._contextMenuTargetElement);
				}
				break;
			}
		}
	},
	
	/**
	 * Inserts HTML template
	 *
	 * @param {String} html Template string. It should have single root element
	 * @returns {Element} inserted element
	 */
	insertTemplate: function(html) {
		this.rdom.insertHtml(this._processTemplate(html));
	},
	
	/**
	 * Places given HTML template nearby target.
	 *
	 * @param {String} html Template string. It should have single root element
	 * @param {Node} target Target node.
	 * @param {String} where Possible values: "before", "start", "end", "after"
	 *
	 * @returns {Element} Inserted element.
	 */
	insertTemplateAt: function(html, target, where) {
		this.rdom.insertHtml(this._processTemplate(html), target, where);
	},
	
	_processTemplate: function(html) {
		// apply template processors
		var tps = $H(this.getTemplateProcessors()).values();
		for(var i = 0; i < tps.length; i++) {
			html = tps[i].handler(html);
		}
		
		// remove all whitespace characters between block tags
		return html = this.removeUnnecessarySpaces(html);
	},
	
	
	
	insertMacro: function(className) {
		var instance = xq.Macro.create(className, this.rdom.getWin());
		instance.insertElement();
		
		var doc = this.getDoc();
		
		if(xq.Browser.isGecko) {
			this.rdom.pushMarker();
			this.getDoc().designMode = 'Off';
		}
		
		instance.execute();
		
		if(xq.Browser.isGecko) {
			window.setTimeout(function() {
				this.getDoc().designMode = 'On';
				this.rdom.popMarker(true);
			}.bind(this), 0);
		}
	},
	
	execMacro: function(container) {
		var instance = xq.Macro.load(container);
		instance.execute();
	},

	findMacroContainers: function() {
		return document.getElementsByClassName('xqMacro');
	},
	
	
	
	/** @private */
	_handleEnterAtEmptyBlock: function() {
		var block = this.rdom.getCurrentBlockElement();
		block = 
			this.rdom.outdentElement(block) ||
			this.rdom.extractOutElementFromParent(block) ||
			this.rdom.replaceTag("P", block) ||
			this.rdom.insertNewBlockAround(block);
		this.rdom.placeCaretAtStartOf(block);
		block.scrollIntoView(false);
	},
	
	/** @private */
	_handleEnterAtEdge: function(atStart, forceInsertParagraph) {
		var block = this.rdom.getCurrentBlockElement();
		if(this.rdom.tree.isTableCell(block)) forceInsertParagraph = true;
		
		var newBlock = this.rdom.insertNewBlockAround(block, atStart, forceInsertParagraph ? "P" : null);
		if(!atStart) {
			this.rdom.placeCaretAtStartOf(newBlock);
			newBlock.scrollIntoView(false);
		} else {
			this.rdom.placeCaretAtStartOf(newBlock.nextSibling);
			newBlock.nextSibling.scrollIntoView(false);
		}
	}
}
xq.Browser = {
	// By Layout Engines
	isTrident: navigator.appName == "Microsoft Internet Explorer",
	isWebkit: navigator.userAgent.indexOf('AppleWebKit/') > -1,
	isGecko: navigator.userAgent.indexOf('Gecko') > -1 && navigator.userAgent.indexOf('KHTML') == -1,
	isKHTML: navigator.userAgent.indexOf('KHTML') != -1,
	isPresto: navigator.appName == "Opera",
	
	// By Platforms
	isMac: navigator.userAgent.indexOf("Macintosh") != -1,
	isUbuntu: navigator.userAgent.indexOf('Ubuntu') != -1
};
xq.Shortcut = function(keymapOrExpression) {
	this.keymap = (typeof keymapOrExpression == "string") ?
		xq.Shortcut.interprete(keymapOrExpression).keymap :
		keymapOrExpression;
}

xq.Shortcut.prototype.matches = function(e) {
	var which = xq.Browser.isGecko && xq.Browser.isMac ? (e.keyCode + "_" + e.charCode) : e.keyCode;

	var keyMatches =
		(this.keymap.which == which) ||
		(this.keymap.which == 32 && which == 25); // 25 is SPACE in Type-3 keyboard.
	
	if(typeof e.metaKey == "undefined") e.metaKey = false;
	
	var modifierMatches = 
		(typeof this.keymap.shiftKey == "undefined" || this.keymap.shiftKey == e.shiftKey) &&
		(typeof this.keymap.altKey == "undefined" || this.keymap.altKey == e.altKey) &&
		(typeof this.keymap.ctrlKey == "undefined" || this.keymap.ctrlKey == e.ctrlKey) &&
		(typeof this.keymap.metaKey == "undefined" || this.keymap.metaKey == e.metaKey)

	return modifierMatches && keyMatches;
}

xq.Shortcut.interprete = function(expression) {
	expression = expression.toUpperCase();
	
	var which = xq.Shortcut._interpreteWhich(expression.split("+").pop());
	var ctrlKey = xq.Shortcut._interpreteModifier(expression, "CTRL");
	var altKey = xq.Shortcut._interpreteModifier(expression, "ALT");
	var shiftKey = xq.Shortcut._interpreteModifier(expression, "SHIFT");
	var metaKey = xq.Shortcut._interpreteModifier(expression, "META");
	
	var keymap = {};
	
	keymap.which = which;
	if(typeof ctrlKey != "undefined") keymap.ctrlKey = ctrlKey;
	if(typeof altKey != "undefined") keymap.altKey = altKey;
	if(typeof shiftKey != "undefined") keymap.shiftKey = shiftKey;
	if(typeof metaKey != "undefined") keymap.metaKey = metaKey;
	
	return new xq.Shortcut(keymap);
}

xq.Shortcut._interpreteModifier = function(expression, modifierName) {
	return expression.match("\\(" + modifierName + "\\)") ?
		undefined :
			expression.match(modifierName) ?
			true : false;
}
xq.Shortcut._keyNames =
	xq.Browser.isMac && xq.Browser.isGecko ?
	{
		BACKSPACE: "8_0",
		TAB: "9_0",
		RETURN: "13_0",
		ENTER: "13_0",
		ESC: "27_0",
		SPACE: "0_32",
		LEFT: "37_0",
		UP: "38_0",
		RIGHT: "39_0",
		DOWN: "40_0",
		DELETE: "46_0",
		HOME: "36_0",
		END: "35_0",
		PAGEUP: "33_0",
		PAGEDOWN: "34_0",
		COMMA: "0_44",
		HYPHEN: "0_45",
		EQUAL: "0_61",
		PERIOD: "0_46",
		SLASH: "0_47",
		F1: "112_0",
		F2: "113_0",
		F3: "114_0",
		F4: "115_0",
		F5: "116_0",
		F6: "117_0",
		F7: "118_0",
		F8: "119_0"
	}
	:
	{
		BACKSPACE: 8,
		TAB: 9,
		RETURN: 13,
		ENTER: 13,
		ESC: 27,
		SPACE: 32,
		LEFT: 37,
		UP: 38,
		RIGHT: 39,
		DOWN: 40,
		DELETE: 46,
		HOME: 36,
		END: 35,
		PAGEUP: 33,
		PAGEDOWN: 34,
		COMMA: 188,
		HYPHEN: xq.Browser.isTrident ? 189 : 109,
		EQUAL: xq.Browser.isTrident ? 187 : 61,
		PERIOD: 190,
		SLASH: 191,
		F1:112,
		F2:113,
		F3:114,
		F4:115,
		F5:116,
		F6:117,
		F7:118,
		F8:119,
		F9:120,
		F10:121,
		F11:122,
		F12:123
	}

xq.Shortcut._interpreteWhich = function(keyName) {
	var which = keyName.length == 1 ?
		((xq.Browser.isMac && xq.Browser.isGecko) ? "0_" + keyName.toLowerCase().charCodeAt(0) : keyName.charCodeAt(0)) :
		xq.Shortcut._keyNames[keyName];
	
	if(typeof which == "undefined") throw "Unknown special key name: [" + keyName + "]"
	
	return which;
}
/**
 * Provide various tree operations.
 *
 * TODO: Add specs
 */
xq.DomTree = Class.create();
xq.DomTree.prototype = {
	initialize: function() {
		this._blockTags = ["DIV", "DD", "LI", "ADDRESS", "CAPTION", "DT", "H1", "H2", "H3", "H4", "H5", "H6", "P", "BODY", "BLOCKQUOTE", "PRE", "PARAM", "DL", "OL", "UL", "TABLE", "THEAD", "TBODY", "TR", "TH", "TD"];
		this._blockContainerTags = ["DIV", "DD", "LI", "BODY", "BLOCKQUOTE", "UL", "OL", "DL", "TABLE", "THEAD", "TBODY", "TR", "TH", "TD"];
		this._listContainerTags = ["OL", "UL", "DL"];
		this._tableCellTags = ["TH", "TD"];
		this._blockOnlyContainerTags = ["BODY", "BLOCKQUOTE"];
		this._atomicTags = ["IMG", "OBJECT", "BR", "HR"];
	},
	
	getBlockTags: function() {
		return this._blockTags;
	},
	
	/**
	 * Find common ancestor(parent) and his immediate children(left and right).
	 *
	 * A --- B -+- C -+- D -+- E
	 *          |
	 *          +- F -+- G
	 *
	 * For example:
	 * > findCommonAncestorAndImmediateChildrenOf("E", "G")
	 *
	 * will return
	 *
	 * > {parent:"B", left:"C", right:"F"}
	 */
	findCommonAncestorAndImmediateChildrenOf: function(left, right) {
		if(left.parentNode == right.parentNode) {
			return {
				left:left,
				right:right,
				parent:left.parentNode
			};
		} else {
			var parentsOfLeft = this.collectParentsOf(left, true);
			var parentsOfRight = this.collectParentsOf(right, true);
			var ca = this.getCommonAncestor(parentsOfLeft, parentsOfRight);
	
			var leftAncestor = parentsOfLeft.find(function(node) {return node.parentNode == ca});
			var rightAncestor = parentsOfRight.find(function(node) {return node.parentNode == ca});
			
			return {
				left:leftAncestor,
				right:rightAncestor,
				parent:ca
			};
		}
	},
	
	/**
	 * Find leaves at edge.
	 *
	 * A --- B -+- C -+- D -+- E
	 *          |
	 *          +- F -+- G
	 *
	 * For example:
	 * > getLeavesAtEdge("A")
	 *
	 * will return
	 *
	 * > ["E", "G"]
	 */
	getLeavesAtEdge: function(element) {
		if(!element.hasChildNodes()) return [null, null];
		
		var findLeft = function(el) {
			for (var i = 0; i < el.childNodes.length; i++) {
				if (el.childNodes[i].nodeType == 1 && this.isBlock(el.childNodes[i])) return findLeft(el.childNodes[i]);
			}
			return el;
		}.bind(this);
		
		var findRight=function(el) {
			for (var i = el.childNodes.length; i--;) {
				if (el.childNodes[i].nodeType == 1 && this.isBlock(el.childNodes[i])) return findRight(el.childNodes[i]);
			}
			return el;
		}.bind(this);
		
		var left = findLeft(element);
		var right = findRight(element);
		return [left == element ? null : left, right == element ? null : right];
	},
	
	getCommonAncestor: function(parents1, parents2) {
		for(var i = 0; i < parents1.length; i++) {
			for(var j = 0; j < parents2.length; j++) {
				if(parents1[i] == parents2[j]) return parents1[i];
			}
		}
	},
	
	collectParentsOf: function(node, includeSelf) {
		var parents = [];
		if(includeSelf) parents.push(node);
		
		while((node = node.parentNode) && (node.nodeName != "HTML")) parents.push(node);
		return parents;
	},
	
	isDescendantOf: function(parent, child) {
		if(parent.length > 0) {
			for(var i = 0; i < parent.length; i++) {
				if(this.isDescendantOf(parent[i], child)) return true;
			}
			return false;
		}
		
		if(parent == child) return false;
		
	    while (child = child.parentNode)
	      if (child == parent) return true;
	    return false;
	},

	/**
	 * Perform tree walking (foreward)
	 */
	walkForward: function(node) {
		if(node.hasChildNodes()) return node.firstChild;
		if(node.nextSibling) return node.nextSibling;
		
		while(node = node.parentNode) {
			if(node.nextSibling) return node.nextSibling;
		}
		
		return null;
	},
	
	/**
	 * Perform tree walking (backward)
	 */
	walkBackward: function(node) {
		if(node.previousSibling) {
			node = node.previousSibling;
			while(node.hasChildNodes()) {node = node.lastChild;}
			return node;
		}
		
		return node.parentNode;
	},
	
	/**
	 * Perform tree walking (to next siblings)
	 */
	walkNext: function(node) {return node.nextSibling},
	
	/**
	 * Perform tree walking (to next siblings)
	 */
	walkPrev: function(node) {return node.previousSibling},
	
	/**
	 * Returns true if target is followed by start
	 */
	checkTargetForward: function(start, target) {
		return this._check(start, this.walkForward, target);
	},

	/**
	 * Returns true if start is followed by target
	 */
	checkTargetBackward: function(start, target) {
		return this._check(start, this.walkBackward, target);
	},
	
	findForward: function(start, condition, exitCondition) {
		return this._find(start, this.walkForward, condition, exitCondition);
	},
	
	findBackward: function(start, condition, exitCondition) {
		return this._find(start, this.walkBackward, condition, exitCondition);
	},
	
	/** @private */
	_check: function(start, direction, target) {
		if(start == target) return false;
		
		while(start = direction(start)) {
			if(start == target) return true;
		}
		return false;
	},
	
	/** @private */
	_find: function(start, direction, condition, exitCondition) {
		while(start = direction(start)) {
			if(exitCondition && exitCondition(start)) return null;
			if(condition(start)) return start;
		}
		return null;
	},

	/**
	 * Walks Forward through DOM tree from start to end, and collects all nodes that matches with a filter.
	 * If no filter provided, it just collects all nodes.
	 *
	 * @param function filter a filter function
	 */
	collectNodesBetween: function(start, end, filter) {
		if(start == end) return [start, end].findAll(filter || function() {return true});
		
		var nodes = this.collectForward(start, function(node) {return node == end}, filter);
		if(
			start != end &&
			typeof filter == "function" &&
			filter(end)
		) nodes.push(end);
		
		return nodes;
	},

	collectForward: function(start, exitCondition, filter) {
		return this.collect(start, this.walkForward, exitCondition, filter);
	},
	
	collectBackward: function(start, exitCondition, filter) {
		return this.collect(start, this.walkBackward, exitCondition, filter);
	},
	
	collectNext: function(start, exitCondition, filter) {
		return this.collect(start, this.walkNext, exitCondition, filter);
	},
	
	collectPrev: function(start, exitCondition, filter) {
		return this.collect(start, this.walkPrev, exitCondition, filter);
	},
	
	collect: function(start, next, exitCondition, filter) {
		var nodes = [start];

		while(true) {
			start = next(start);
			if(
				(start == null) ||
				(typeof exitCondition == "function" && exitCondition(start))
			) break;
			
			nodes.push(start);
		}

		return (typeof filter == "function") ? nodes.findAll(filter) : nodes;
	},


	hasBlocks: function(element) {
		var nodes = element.childNodes;
		for(var i = 0; i < nodes.length; i++) {
			if(this.isBlock(nodes[i])) return true;
		}
		return false;
	},
	
	hasMixedContents: function(element) {
		if(!this.isBlock(element)) return false;
		if(!this.isBlockContainer(element)) return false;
		
		var hasTextOrInline = false;
		var hasBlock = false;
		for(var i = 0; i < element.childNodes.length; i++) {
			var node = element.childNodes[i];
			if(!hasTextOrInline && this.isTextOrInlineNode(node)) hasTextOrInline = true;
			if(!hasBlock && this.isBlock(node)) hasBlock = true;
			
			if(hasTextOrInline && hasBlock) break;
		}
		if(!hasTextOrInline || !hasBlock) return false;
		
		return true;
	},
	
	isBlockOnlyContainer: function(element) {
		if(!element) return false;
		return this._blockOnlyContainerTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isTableCell: function(element) {
		if(!element) return false;
		return this._tableCellTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isBlockContainer: function(element) {
		if(!element) return false;
		return this._blockContainerTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isHeading: function(element) {
		if(!element) return false;
		return (typeof element == 'string' ? element : element.nodeName).match(/H\d/);
	},
	
	isBlock: function(element) {
		if(!element) return false;
		return this._blockTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isAtomic: function(element) {
		if(!element) return false;
		return this._atomicTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isListContainer: function(element) {
		if(!element) return false;
		return this._listContainerTags.include(typeof element == 'string' ? element : element.nodeName);
	},
	
	isTextOrInlineNode: function(node) {
		return node && (node.nodeType == 3 || !this.isBlock(node));
	}
}
/**
 * Encapsulates browser incompatibility problem and provides rich set of DOM manipulation API.
 *
 * RichDom provides basic CRUD + Advanced DOM manipulation API, various query methods and caret/selection management API
 */
xq.RichDom = Class.create();
xq.RichDom.prototype = {
	/**
	 * Initialize RichDom. Target window and root element should be set after initialization. See setWin and setRoot.
	 *
     * @constructor
	 * @param {Element} contentElement HTML element(TEXTAREA or normal block element such as DIV) to be replaced with editable area
	 */
	initialize: function() {
		/**
		 * {xq.DomTree} instance of DomTree
		 */
		this.tree = new xq.DomTree();
		
		this._lastMarkerId = 0;
	},
	
	
	
	/**
	 * @param {Window} win Browser's window object
	 */
	setWin: function(win) {
		if(!win) throw "[win] is null";
		this.win = win;
	},
	
	/**
	 * @param {Element} root Root element
	 */
	setRoot: function(root) {
		if(!root) throw "[root] is null";
		if(this.win && (root.ownerDocument != this.win.document)) throw "root.ownerDocument != this.win.document";
		this.root = root;
		this.doc = this.root.ownerDocument;
	},
	
	/**
	 * @returns Browser's window object.
	 */
	getWin: function() {return this.win},
	
	/**
	 * @returns Document object of root element.
	 */
	getDoc: function() {return this.doc},
	
	/**
	 * @returns Root element.
	 */
	getRoot: function() {return this.root},
	
	
	
	/////////////////////////////////////////////
	// CRUDs
	
	clearRoot: function() {
		this.root.innerHTML = "";
		this.root.appendChild(this.makeEmptyParagraph());
	},
	
	/**
	 * Removes place holders and empty text nodes of given element
	 *
	 * @param {Element} element target element
	 */
	removePlaceHoldersAndEmptyNodes: function(element) {
		var node = element;
		
		while(node) {
			var next = this.tree.walkForward(node);
			if(this.isPlaceHolder(node) || (node.nodeType == 3 && node.nodeValue == "")) this.deleteNode(node);
			node = next;
		}
	},
	
	/**
	 * Sets multiple attributes into element at once
	 *
	 * @param {Element} element target element
	 * @param {Object} map key-value pairs
	 */
	setAttributes: function(element, map) {
		for(key in map) element.setAttribute(key, map[key]);
	},

	/**
	 * Creates textnode by given node value.
	 *
	 * @param {String} value value of textnode
	 * @returns {Node} Created text node
	 */	
	createTextNode: function(value) {return this.doc.createTextNode(value);},

	/**
	 * Creates empty element by given tag name.
	 *
	 * @param {String} tagName name of tag
	 * @returns {Element} Created element
	 */	
	createElement: function(tagName) {return this.doc.createElement(tagName);},

	/**
	 * Creates element from HTML string
	 * 
	 * @param {String} html HTML string
	 * @returns {Element} Created element
	 */
	createElementFromHtml: function(html) {
		var node = this.createElement("div");
		node.innerHTML = html;
		if(node.childNodes.length != 1) {
			throw "Illegal HTML fragment";
		}
		return this.getFirstChildOf(node);
	},
	
	/**
	 * Deletes node from DOM tree.
	 *
	 * @param {Node} node Target node which should be deleted
	 * @param {boolean} deleteEmptyParentsRecursively Recursively delete empty parent elements
	 * @param {boolean} correctEmptyParent Call #correctEmptyElement on empty parent element after deletion
	 */	
	deleteNode: function(node, deleteEmptyParentsRecursively, correctEmptyParent) {
		if(!node || !node.parentNode) return;
		
		var parent = node.parentNode;
		parent.removeChild(node);
		
		if(deleteEmptyParentsRecursively) {
			while(!parent.hasChildNodes()) {
				node = parent;
				parent = node.parentNode;
				if(!parent || this.getRoot() == node) break;
				parent.removeChild(node);
			}
		}
		
		if(correctEmptyParent && this.isEmptyBlock(parent)) {
			parent.innerHTML = "";
			this.correctEmptyElement(parent);
		}
	},

	/**
	 * Inserts given node into current caret position
	 *
	 * @param {Node} node Target node
	 * @returns {Node} Inserted node. It could be different with given node.
	 */
	insertNode: function(node) {throw "Not implemented"},

	/**
	 * Inserts given html into current caret position
	 *
	 * @param {String} html HTML string
	 * @returns {Node} Inserted node. It could be different with given node.
	 */
	insertHtml: function(html) {
		return this.insertNode(this.createElementFromHtml(html));
	},
	
	/**
	 * Creates textnode from given text and inserts it into current caret position
	 *
	 * @param {String} text Value of textnode
	 * @returns {Node} Inserted node
	 */
	insertText: function(text) {
		this.insertNode(this.createTextNode(text));
	},
	
	/**
	 * Places given node nearby target.
	 *
	 * @param {Node} node Node to be inserted.
	 * @param {Node} target Target node.
	 * @param {String} where Possible values: "before", "start", "end", "after"
	 * @param {boolean} performValidation Validate node if needed. For example when P placed into UL, its tag name automatically replaced with LI
	 *
	 * @returns {Node} Inserted node. It could be different with given node.
	 */
	insertNodeAt: function(node, target, where, performValidation) {
		if(
			["HTML", "HEAD"].include(target.nodeName) ||
			["BODY"].include(target.nodeName) && ["before", "after"].include(where)
		) throw "Illegal argument. Cannot move node[" + node.nodeName + "] to '" + where + "' of target[" + target.nodeName + "]"
		
		var object;
		var message;
		var secondParam;
		
		switch(where.toLowerCase()) {
			case "before":
				object = target.parentNode;
				message = 'insertBefore';
				secondParam = target;
				break
			case "start":
				if(target.firstChild) {
					object = target;
					message = 'insertBefore';
					secondParam = target.firstChild;
				} else {
					object = target;
					message = 'appendChild';
				}
				break
			case "end":
				object = target;
				message = 'appendChild';
				break
			case "after":
				if(target.nextSibling) {
					object = target.parentNode;
					message = 'insertBefore';
					secondParam = target.nextSibling;
				} else {
					object = target.parentNode;
					message = 'appendChild';
				}
				break
		}

		if(performValidation && this.tree.isListContainer(object) && node.nodeName != "LI") {
			var li = this.createElement("LI");
			li.appendChild(node);
			node = li;
			object[message](node, secondParam);		
		} else if(performValidation && !this.tree.isListContainer(object) && node.nodeName == "LI") {
			this.wrapAllInlineOrTextNodesAs("P", node, true);
			var div = this.createElement("DIV");
			this.moveChildNodes(node, div);
			this.deleteNode(node);
			object[message](div, secondParam);
			node = this.unwrapElement(div, true);
		} else {
			object[message](node, secondParam);
		}
		
		return node;
	},

	/**
	 * Creates textnode from given text and places given node nearby target.
	 *
	 * @param {String} text Text to be inserted.
	 * @param {Node} target Target node.
	 * @param {String} where Possible values: "before", "start", "end", "after"
	 *
	 * @returns {Node} Inserted node.
	 */
	insertTextAt: function(text, target, where) {
		return this.insertNodeAt(this.createTextNode(text), target, where);
	},

	/**
	 * Creates element from given HTML string and places given it nearby target.
	 *
	 * @param {String} html HTML to be inserted.
	 * @param {Node} target Target node.
	 * @param {String} where Possible values: "before", "start", "end", "after"
	 *
	 * @returns {Node} Inserted node.
	 */
	insertHtmlAt: function(html, target, where) {
		return this.insertNodeAt(this.createElementFromHtml(html), target, where);
	},

	/**
	 * Replaces element's tag by removing current element and creating new element by given tag name.
	 *
	 * @param {String} tag New tag name
	 * @param {Element} element Target element
	 *
	 * @returns {Element} Replaced element
	 */	
	replaceTag: function(tag, element) {
		if(element.nodeName == tag) return null;
		if(this.tree.isTableCell(element)) return null;
		
		var newElement = this.createElement(tag);
		this.moveChildNodes(element, newElement);
		this.copyAttributes(element, newElement, true);
		element.parentNode.replaceChild(newElement, element);
		
		if(!newElement.hasChildNodes()) this.correctEmptyElement(newElement);
		
		return newElement;
	},

	/**
	 * Unwraps unnecessary paragraph.
	 *
	 * Unnecessary paragraph is P which is the only child of given container element.
	 * For example, P which is contained by LI and is the only child is the unnecessary paragraph.
	 * But if given container element is a block-only-container(BLOCKQUOTE, BODY), this method does nothing.
	 *
	 * @param {Element} element Container element
	 * @returns {boolean} True if unwrap performed.
	 */
	unwrapUnnecessaryParagraph: function(element) {
		if(!element) return false;
		
		if(!this.tree.isBlockOnlyContainer(element) && element.childNodes.length == 1 && element.firstChild.nodeName == "P" && !this.hasImportantAttributes(element.firstChild)) {
			var p = element.firstChild;
			this.moveChildNodes(p, element);
			this.deleteNode(p);
			return true;
		}
		return false;
	},
	
	/**
	 * Unwraps element by extracting all children out and removing the element.
	 *
	 * @param {Element} element Target element
	 * @param {boolean} wrapInlineAndTextNodes Wrap all inline and text nodes with P before unwrap
	 * @returns {Node} First child of unwrapped element
	 */
	unwrapElement: function(element, wrapInlineAndTextNodes) {
		if(wrapInlineAndTextNodes) this.wrapAllInlineOrTextNodesAs("P", element);
		
		var nodeToReturn = element.firstChild;
		
		while(element.firstChild) this.insertNodeAt(element.firstChild, element, "before");
		this.deleteNode(element);
		
		return nodeToReturn;
	},
	
	/**
	 * Wraps element by given tag
	 *
	 * @param {String} tag tag name
	 * @param {Element} element target element to wrap
	 * @returns {Element} wrapper
	 */
	wrapElement: function(tag, element) {
		var wrapper = this.insertNodeAt(this.createElement(tag), element, "before");
		wrapper.appendChild(element);
		return wrapper;
	},
	
	/**
	 * Tests #smartWrap with given criteria but doesn't change anything
	 */
	testSmartWrap: function(endElement, criteria) {
		return this.smartWrap(endElement, null, criteria, true);
	},
	
	/**
	 * Create inline element with given tag name and wraps nodes nearby endElement by given criteria
	 *
	 * @param {Element} endElement Boundary(end point, exclusive) of wrapper.
	 * @param {String} tag Tag name of wrapper.
	 * @param {Object} function which returns text index of start boundary.
	 * @param {boolean} testOnly just test boundary and do not perform actual wrapping.
	 *
	 * @returns {Element} wrapper
	 */
	smartWrap: function(endElement, tag, criteria, testOnly) {
		var block = this.getParentBlockElementOf(endElement);

		tag = tag || "SPAN";
		criteria = criteria || function(text) {return -1};
		
		// check for empty wrapper
		if(!testOnly && (!endElement.previousSibling || this.isEmptyBlock(block))) {
			var wrapper = this.insertNodeAt(this.createElement(tag), endElement, "before");
			return wrapper;
		}
		
		// collect all textnodes
		var textNodes = this.tree.collectForward(block, function(node) {return node == endElement}, function(node) {return node.nodeType == 3});
		
		// find textnode and break-point
		var nodeIndex = 0;
		var nodeValues = textNodes.pluck("nodeValue");
		var textToWrap = nodeValues.join("");
		var textIndex = criteria(textToWrap)
		var breakPoint = textIndex;
		
		if(breakPoint == -1) {
			breakPoint = 0;
		} else {
			textToWrap = textToWrap.substring(breakPoint);
		}
		
		for(var i = 0; i < textNodes.length; i++) {
			if(breakPoint > nodeValues[i].length) {
				breakPoint -= nodeValues[i].length;
			} else {
				nodeIndex = i;
				break;
			}
		}
		
		if(testOnly) return {text:textToWrap, textIndex:textIndex, nodeIndex:nodeIndex, breakPoint:breakPoint};
		
		// break textnode if necessary 
		if(breakPoint != 0) {
			var splitted = textNodes[nodeIndex].splitText(breakPoint);
			nodeIndex++;
			textNodes.splice(nodeIndex, 0, splitted);
		}
		var startElement = textNodes[nodeIndex] || block.firstChild;
		
		// split inline elements up to parent block if necessary
		var family = this.tree.findCommonAncestorAndImmediateChildrenOf(startElement, endElement);
		var ca = family.parent;
		if(ca) {
			if(startElement.parentNode != ca) startElement = this.splitElementUpto(startElement, ca, true);
			if(endElement.parentNode != ca) endElement = this.splitElementUpto(endElement, ca, true);
			
			var prevStart = startElement.previousSibling;
			var nextEnd = endElement.nextSibling;
			
			// remove empty inline elements
			if(prevStart && prevStart.nodeType == 1 && this.isEmptyBlock(prevStart)) this.deleteNode(prevStart);
			if(nextEnd && nextEnd.nodeType == 1 && this.isEmptyBlock(nextEnd)) this.deleteNode(nextEnd);
			
			// wrap
			var wrapper = this.insertNodeAt(this.createElement(tag), startElement, "before");
			while(wrapper.nextSibling != endElement) wrapper.appendChild(wrapper.nextSibling);
			return wrapper;
		} else {
			// wrap
			var wrapper = this.insertNodeAt(this.createElement(tag), endElement, "before");
			return wrapper;
		}
	},
	
	/**
	 * Wraps all adjust inline elements and text nodes into block element.
	 *
	 * TODO: empty element should return empty array when it is not forced and (at least) single item array when forced
	 *
	 * @param {String} tag Tag name of wrapper
	 * @param {Element} element Target element
	 * @param {boolean} force Force wrapping. If it is set to false, this method do not makes unnecessary wrapper.
	 *
	 * @returns {Array} Array of wrappers. If nothing performed it returns empty array
	 */
	wrapAllInlineOrTextNodesAs: function(tag, element, force) {
		var wrappers = [];
		
		if(!force && !this.tree.hasMixedContents(element)) return wrappers;
		
		var node = element.firstChild;
		while(node) {
			if(this.tree.isTextOrInlineNode(node)) {
				var wrapper = this.wrapInlineOrTextNodesAs(tag, node);
				wrappers.push(wrapper);
				node = wrapper.nextSibling;
			} else {
				node = node.nextSibling;
			}
		}

		return wrappers;
	},

	/**
	 * Wraps node and its adjust next siblings into an element
	 */
	wrapInlineOrTextNodesAs: function(tag, node) {
		var wrapper = this.createElement(tag);
		var from = node;

		from.parentNode.replaceChild(wrapper, from);
		wrapper.appendChild(from);

		// move nodes into wrapper
		while(wrapper.nextSibling && this.tree.isTextOrInlineNode(wrapper.nextSibling)) wrapper.appendChild(wrapper.nextSibling);

		return wrapper;
	},
	
	/**
	 * Turns block element into list item
	 *
	 * @param {Element} element Target element
	 * @param {String} type One of "UL", "OL", "CODE". "CODE" is same with "OL" but it gives "OL" a class name "code"
	 *
	 * @return {Element} LI element
	 */
	turnElementIntoListItem: function(element, type) {
		type = type.toUpperCase();
		
		var container = this.insertNodeAt(this.createElement(type == "UL" ? "UL" : "OL"), element, "after");
		if(type == "CODE") container.className = "code";
		
		var li = this.insertNodeAt(this.createElement("LI"), container, "start");
		li.appendChild(element);
		
		this.unwrapUnnecessaryParagraph(li);
		this.mergeAdjustLists(container);
		
		return li;
	},
	
	/**
	 * Extracts given element out from its parent element.
	 * 
	 * @param {Element} element Target element
	 */
	extractOutElementFromParent: function(element) {
		if(element == this.root || this.root == element.parentNode || !element.offsetParent) return null;
		
		if(element.nodeName == "LI") {
			this.wrapAllInlineOrTextNodesAs("P", element, true);
			element = element.firstChild;
		}

		var container = element.parentNode;
		var nodeToReturn = null;
		
		if(container.nodeName == "LI" && container.parentNode.parentNode.nodeName == "LI") {
			// nested list item
			if(element.previousSibling) {
				this.splitContainerOf(element, true);
				this.correctEmptyElement(element);
			}
			
			this.outdentListItem(element);
			nodeToReturn = element;
		} else if(container.nodeName == "LI") {
			// not-nested list item
			
			if(this.tree.isListContainer(element.nextSibling)) {
				// 1. split listContainer
				var listContainer = container.parentNode;
				this.splitContainerOf(container, true);
				this.correctEmptyElement(element);
				
				// 2. extract out LI's children
				nodeToReturn = container.firstChild;
				while(container.firstChild) {
					this.insertNodeAt(container.firstChild, listContainer, "before");
				}
				
				// 3. remove listContainer and merge adjust lists
				var prevContainer = listContainer.previousSibling;
				this.deleteNode(listContainer);
				if(prevContainer && this.tree.isListContainer(prevContainer)) this.mergeAdjustLists(prevContainer);
			} else {
				// 1. split LI
				this.splitContainerOf(element, true);
				this.correctEmptyElement(element);
				
				// 2. split list container
				var listContainer = this.splitContainerOf(container);
				
				// 3. extract out
				this.insertNodeAt(element, listContainer.parentNode, "before");
				this.deleteNode(listContainer.parentNode);
				
				nodeToReturn = element;
			}
		} else if(this.tree.isTableCell(container) || this.tree.isTableCell(element)) {
			// do nothing
		} else {
			// normal block
			this.splitContainerOf(element, true);
			this.correctEmptyElement(element);
			nodeToReturn = this.insertNodeAt(element, container, "before");
			
			this.deleteNode(container);
		}
		
		return nodeToReturn;
	},
	
	/**
	 * Insert new block above or below given element.
	 *
	 * @param {Element} block Target block
	 * @param {boolean} before Insert new block above(before) target block
	 * @param {String} forceTag New block's tag name. If omitted, target block's tag name will be used.
	 *
	 * @returns {Element} Inserted block
	 */
	insertNewBlockAround: function(block, before, forceTag) {
		var isListItem = block.nodeName == "LI" || block.parentNode.nodeName == "LI";
		
		this.removeTrailingWhitespace(block);
		
		if(isListItem && !forceTag) {
			var li = this.getParentElementOf(block, ["LI"]);
			var newBlock = this._insertNewBlockAround(block, before);
			if(li != block) newBlock = this.splitContainerOf(newBlock, false, "prev");
			return newBlock;
		} else if(this.tree.isBlockContainer(block)) {
			this.wrapAllInlineOrTextNodesAs("P", block, true);
			return this._insertNewBlockAround(block.firstChild, before, forceTag);
		} else {
			return this._insertNewBlockAround(block, before, this.tree.isHeading(block) ? "P" : forceTag);
		}
	},
	
	/**
	 * @private
	 *
	 * TODO: Rename
	 */
	_insertNewBlockAround: function(element, before, tagName) {
		var newElement = this.createElement(tagName || element.nodeName);
		this.copyAttributes(element, newElement, false);
		this.correctEmptyElement(newElement);
		newElement = this.insertNodeAt(newElement, element, before ? "before" : "after");
		return newElement;
	},
	
	/**
	 * Wrap or replace element with given tag name.
	 *
	 * @param {String} tag Tag name
	 * @param {Element} element Target element
	 *
	 * @return {Element} wrapper element or replaced element.
	 */
	applyTagIntoElement: function(tag, element) {
		if(this.tree.isBlockOnlyContainer(tag)) {
			return this.wrapBlock(tag, element);
		} else if(this.tree.isBlockContainer(element)) {
			var wrapper = this.createElement(tag);
			this.moveChildNodes(element, wrapper);
			return this.insertNodeAt(wrapper, element, "start");
		} else {
			if(this.tree.isBlockContainer(tag) && this.hasImportantAttributes(element)) {
				return this.wrapBlock(tag, element);
			} else {
				return this.replaceTag(tag, element);
			}
		}
		
		throw "IllegalArgumentException - [" + tag + ", " + element + "]";
	},
	
	/**
	 * Wrap or replace elements with given tag name.
	 *
	 * @param {String} tag Tag name
	 * @param {Element} from Start boundary (inclusive)
	 * @param {Element} to End boundary (inclusive)
	 *
	 * @returns {Array} Array of wrappers or replaced elements
	 */
	applyTagIntoElements: function(tagName, from, to) {
		var applied = [];
		
		if(this.tree.isBlockContainer(tagName)) {
			var family = this.tree.findCommonAncestorAndImmediateChildrenOf(from, to);
			var node = family.left;
			var wrapper = this.insertNodeAt(this.createElement(tagName), node, "before");
			
			var coveringWholeList =
				family.parent.nodeName == "LI" &&
				family.parent.parentNode.childNodes.length == 1 &&
				!family.left.previousSilbing &&
				!family.right.nextSibling;
				
			if(coveringWholeList) {
				var ul = node.parentNode.parentNode;
				this.insertNodeAt(wrapper, ul, "before");
				wrapper.appendChild(ul);
			} else {
				while(node != family.right) {
					next = node.nextSibling;
					wrapper.appendChild(node);
					node = next;
				}
				wrapper.appendChild(family.right);
			}
			applied.push(wrapper);
		} else {
			// is normal tagName
			var elements = this.getBlockElementsBetween(from, to);
			for(var i = 0; i < elements.length; i++) {
				if(this.tree.isBlockContainer(elements[i])) {
					applied.push(this.wrapAllInlineOrTextNodesAs(tagName, elements[i], true));
				} else {
					applied.push(this.replaceTag(tagName, elements[i]));
				}
			}
		}
		return applied.flatten();
	},
	
	/**
	 * Moves block up or down
	 *
	 * @param {Element} block Target block
	 * @param {boolean} up Move up if true
	 * 
	 * @returns {Element} Moved block. It could be different with given block.
	 */
	moveBlock: function(block, up) {
		// if block is table cell or contained by table cell, select its row as mover
		block = this.getParentElementOf(block, ["TR"]) || block;
		
		// if block is only child, select its parent as mover
		while(block.nodeName != "TR" && block.parentNode != this.getRoot() && !block.previousSibling && !block.nextSibling && !this.tree.isListContainer(block.parentNode)) {
			block = block.parentNode;
		}
		
		// find target and where
		var target, where;
		if (up) {
			target = block.previousSibling;
			
			if(target) {
				var singleNodeLi = target.nodeName == 'LI' && ((target.childNodes.length == 1 && this.tree.isBlock(target.firstChild)) || !this.tree.hasBlocks(target));
				var table = ['TABLE', 'TR'].include(target.nodeName);

				where = this.tree.isBlockContainer(target) && !singleNodeLi && !table ? "end" : "before";
			} else if(block.parentNode != this.getRoot()) {
				target = block.parentNode;
				where = "before";
			}
		} else {
			target = block.nextSibling;
			
			if(target) {
				var singleNodeLi = target.nodeName == 'LI' && ((target.childNodes.length == 1 && this.tree.isBlock(target.firstChild)) || !this.tree.hasBlocks(target));
				var table = ['TABLE', 'TR'].include(target.nodeName);
				
				where = this.tree.isBlockContainer(target) && !singleNodeLi && !table ? "start" : "after";
			} else if(block.parentNode != this.getRoot()) {
				target = block.parentNode;
				where = "after";
			}
		}
		
		
		// no way to go?
		if(!target) return null;
		if(["TBODY", "THEAD"].include(target.nodeName)) return null;
		
		// normalize
		this.wrapAllInlineOrTextNodesAs("P", target, true);
		
		// make placeholder if needed
		if(this.isFirstLiWithNestedList(block)) {
			this.insertNewBlockAround(block, false, "P");
		}
		
		// perform move
		var parent = block.parentNode;
		var moved = this.insertNodeAt(block, target, where, true);
		
		// cleanup
		if(!parent.hasChildNodes()) this.deleteNode(parent, true);
		this.unwrapUnnecessaryParagraph(moved);
		this.unwrapUnnecessaryParagraph(target);

		// remove placeholder
		if(up) {
			if(moved.previousSibling && this.isEmptyBlock(moved.previousSibling) && !moved.previousSibling.previousSibling && moved.parentNode.nodeName == "LI" && this.tree.isListContainer(moved.nextSibling)) {
				this.deleteNode(moved.previousSibling);
			}
		} else {
			if(moved.nextSibling && this.isEmptyBlock(moved.nextSibling) && !moved.previousSibling && moved.parentNode.nodeName == "LI" && this.tree.isListContainer(moved.nextSibling.nextSibling)) {
				this.deleteNode(moved.nextSibling);
			}
		}
		
		return moved;
	},
	
	/**
	 * Remove given block
	 *
	 * @param {Element} block Target block
	 * @returns {Element} Nearest block of remove element
	 */
	removeBlock: function(block) {
		var blockToMove;

		// if block is only child, select its parent as mover
		while(block.parentNode != this.getRoot() && !block.previousSibling && !block.nextSibling && !this.tree.isListContainer(block.parentNode)) {
			block = block.parentNode;
		}
		
		var finder = function(node) {return this.tree.isBlock(node) && !this.tree.isDescendantOf(block, node) && !this.tree.hasBlocks(node);}.bind(this);
		var exitCondition = function(node) {return this.tree.isBlock(node) && !this.tree.isDescendantOf(this.getRoot(), node)}.bind(this);
		
		if(this.isFirstLiWithNestedList(block)) {
			blockToMove = this.outdentListItem(block.nextSibling.firstChild);
			this.deleteNode(blockToMove.previousSibling, true);
		} else if(this.tree.isTableCell(block)) {
			var rtable = new xq.RichTable(this, this.getParentElementOf(block, ["TABLE"]));
			blockToMove = rtable.getBelowCellOf(block);
			
			// should not delete row when there's thead and the row is the only child of tbody
			if(
				block.parentNode.parentNode.nodeName == "TBODY" &&
				rtable.hasHeadingAtTop() &&
				rtable.getDom().tBodies[0].rows.length == 1) return blockToMove;
			
			blockToMove = blockToMove ||
				this.tree.findForward(block, finder, exitCondition) ||
				this.tree.findBackward(block, finder, exitCondition);
			
			this.deleteNode(block.parentNode, true);
		} else {
			blockToMove = blockToMove ||
				this.tree.findForward(block, finder, exitCondition) ||
				this.tree.findBackward(block, finder, exitCondition);
			
			this.deleteNode(block, true);
		}
		
		if(!this.getRoot().hasChildNodes()) {
			blockToMove = this.createElement("P");
			this.getRoot().appendChild(blockToMove);
			this.correctEmptyElement(blockToMove);
		}
		
		return blockToMove;
	},
	
	/**
	 * Removes trailing whitespaces of given block
	 *
	 * @param {Element} block Target block
	 */
	removeTrailingWhitespace: function(block) {throw "Not implemented"},
	
	/**
	 * Extract given list item out and change its container's tag
	 *
	 * @param {Element} element LI or P which is a child of LI
	 * @param {String} type "OL", "UL", or "CODE"
	 *
	 * @returns {Element} changed element
	 */
	changeListTypeTo: function(element, type) {
		type = type.toUpperCase();
		
		var li = this.getParentElementOf(element, ["LI"]);
		if(!li) throw "IllegalArgumentException";
		
		var container = li.parentNode;

		this.splitContainerOf(li);
		
		var newContainer = this.insertNodeAt(this.createElement(type == "UL" ? "UL" : "OL"), container, "before");
		if(type == "CODE") newContainer.className = "code";
		
		this.insertNodeAt(li, newContainer, "start");
		this.deleteNode(container);
		
		this.mergeAdjustLists(newContainer);
		
		return element;
	},
	
	/**
	 * Split container of element into (maxium) three pieces.
	 */
	splitContainerOf: function(element, preserveElementItself, dir) {
		if([element, element.parentNode].include(this.getRoot())) return element;
		
		var container = element.parentNode;
		if(element.previousSibling && (!dir || dir.toLowerCase() == "prev")) {
			var prev = this.createElement(container.nodeName);
			this.copyAttributes(container, prev);
			while(container.firstChild != element) {
				prev.appendChild(container.firstChild);
			}
			this.insertNodeAt(prev, container, "before");
			this.unwrapUnnecessaryParagraph(prev);
		}
		
		if(element.nextSibling && (!dir || dir.toLowerCase() == "next")) {
			var next = this.createElement(container.nodeName);
			this.copyAttributes(container, next);
			while(container.lastChild != element) {
				this.insertNodeAt(container.lastChild, next, "start");
			}
			this.insertNodeAt(next, container, "after");
			this.unwrapUnnecessaryParagraph(next);
		}
		
		if(!preserveElementItself) element = this.unwrapUnnecessaryParagraph(container) ? container : element;
		return element;
	},

	/**
	 * TODO: Add specs
	 */
	splitParentElement: function(seperator) {
		var parent = seperator.parentNode;
		if(["HTML", "HEAD", "BODY"].include(parent.nodeName)) throw "Illegal argument. Cannot seperate element[" + parent.nodeName + "]";

		var previousSibling = seperator.previousSibling;
		var nextSibling = seperator.nextSibling;
		
		var newElement = this.insertNodeAt(this.createElement(parent.nodeName), parent, "after");
		
		var next;
		while(next = seperator.nextSibling) newElement.appendChild(next);
		
		this.insertNodeAt(seperator, newElement, "start");
		this.copyAttributes(parent, newElement);
		
		return newElement;
	},
	
	/**
	 * TODO: Add specs
	 */
	splitElementUpto: function(seperator, element, excludeElement) {
		while(seperator.previousSibling != element) {
			if(excludeElement && seperator.parentNode == element) break;
			seperator = this.splitParentElement(seperator);
		}
		return seperator;
	},
	
	/**
	 * Merges two adjust elements
	 *
	 * @param {Element} element base element
	 * @param {boolean} withNext merge base element with next sibling
	 * @param {boolean} skip skip merge steps
	 */
	mergeElement: function(element, withNext, skip) {
		// find two block
		if(withNext) {
			var prev = element;
			var next = this.tree.findForward(
				element,
				function(node) {return this.tree.isBlock(node) && !this.tree.isListContainer(node) && node != element.parentNode}.bind(this)
			);
		} else {
			var next = element;
			var prev = this.tree.findBackward(
				element,
				function(node) {return this.tree.isBlock(node) && !this.tree.isListContainer(node) && node != element.parentNode}.bind(this)
			);
		}
		
		// normalize next block
		if(next && this.tree.isDescendantOf(this.getRoot(), next)) {
			var nextContainer = next.parentNode;
			if(this.tree.isBlockContainer(next)) {
				nextContainer = next;
				this.wrapAllInlineOrTextNodesAs("P", nextContainer, true);
				next = nextContainer.firstChild;
			}
		} else {
			next = null;
		}
		
		// normalize prev block
		if(prev && this.tree.isDescendantOf(this.getRoot(), prev)) {
			var prevContainer = prev.parentNode;
			if(this.tree.isBlockContainer(prev)) {
				prevContainer = prev;
				this.wrapAllInlineOrTextNodesAs("P", prevContainer, true);
				prev = prevContainer.lastChild;
			}
		} else {
			prev = null;
		}
		
		try {
			var containersAreTableCell =
				prevContainer && (this.tree.isTableCell(prevContainer) || ['TR', 'THEAD', 'TBODY'].include(prevContainer.nodeName)) &&
				nextContainer && (this.tree.isTableCell(nextContainer) || ['TR', 'THEAD', 'TBODY'].include(nextContainer.nodeName));
			
			if(containersAreTableCell && prevContainer != nextContainer) return null;
			
			// if next has margin, perform outdent
			if((!skip || !prev) && next && this.outdentElement(next)) return element;

			// nextContainer is first li and next of it is list container
			if(nextContainer && nextContainer.nodeName == 'LI' && this.tree.isListContainer(next.nextSibling)) {
				this.extractOutElementFromParent(nextContainer);
				return prev;
			}
			
			// merge two list containers
			if(nextContainer && nextContainer.nodeName == 'LI' && this.tree.isListContainer(nextContainer.parentNode.previousSibling)) {
				this.mergeAdjustLists(nextContainer.parentNode.previousSibling, true, "next");
				return prev;
			}

			if(next && !containersAreTableCell && prevContainer && prevContainer.nodeName == 'LI' && nextContainer && nextContainer.nodeName == 'LI' && prevContainer.parentNode.nextSibling == nextContainer.parentNode) {
				var nextContainerContainer = nextContainer.parentNode;
				this.moveChildNodes(nextContainer.parentNode, prevContainer.parentNode);
				this.deleteNode(nextContainerContainer);
				return prev;
			}
			
			// merge two containers
			if(next && !containersAreTableCell && prevContainer && prevContainer.nextSibling == nextContainer && ((skip && prevContainer.nodeName != "LI") || (!skip && prevContainer.nodeName == "LI"))) {
				this.moveChildNodes(nextContainer, prevContainer);
				return prev;
			}

			// unwrap container
			if(nextContainer && nextContainer.nodeName != "LI" && !this.getParentElementOf(nextContainer, ["TABLE"]) && !this.tree.isListContainer(nextContainer) && nextContainer != this.getRoot() && !next.previousSibling) {
				return this.unwrapElement(nextContainer, true);
			}
			
			// delete table
			if(withNext && nextContainer && nextContainer.nodeName == "TABLE") {
				this.deleteNode(nextContainer, true);
				return prev;
			} else if(!withNext && prevContainer && this.tree.isTableCell(prevContainer) && !this.tree.isTableCell(nextContainer)) {
				this.deleteNode(this.getParentElementOf(prevContainer, ["TABLE"]), true);
				return next;
			}
			
			// if prev is same with next, do nothing
			if(prev == next) return null;
			
			// if there is a null block, do nothing
			if(!prev || !next || !prevContainer || !nextContainer) return null;
			
			// if two blocks are not in the same table cell, do nothing
			if(this.getParentElementOf(prev, ["TD", "TH"]) != this.getParentElementOf(next, ["TD", "TH"])) return null;
			
			// cleanup empty block before merge
			if(this.isEmptyBlock(prev)) prev.innerHTML = "";
			if(this.isEmptyBlock(next)) next.innerHTML = "";
			
			// perform merge
			this.moveChildNodes(next, prev);
			this.deleteNode(next);
			this.removePlaceHoldersAndEmptyNodes(prev);
			
			return prev;
		} finally {
			// cleanup
			if(prevContainer && this.isEmptyBlock(prevContainer)) this.deleteNode(prevContainer, true);
			if(nextContainer && this.isEmptyBlock(nextContainer)) this.deleteNode(nextContainer, true);
			
			if(prevContainer) this.unwrapUnnecessaryParagraph(prevContainer);
			if(nextContainer) this.unwrapUnnecessaryParagraph(nextContainer);
		}
	},
	
	/**
	 * Merges adjust list containers which has same tag name
	 *
	 * @param {Element} container target list container
	 * @param {boolean} force force adjust list container even if they have different list type
	 * @param {String} dir Specify merge direction: PREV or NEXT. If not supplied it will be merged with both direction.
	 */
	mergeAdjustLists: function(container, force, dir) {
		var prev = container.previousSibling;
		var isPrevSame = prev && (prev.nodeName == container.nodeName && prev.className == container.className);
		if((!dir || dir.toLowerCase() == 'prev') && (isPrevSame || (force && this.tree.isListContainer(prev)))) {
			while(prev.lastChild) {
				this.insertNodeAt(prev.lastChild, container, "start");
			}
			this.deleteNode(prev);
		}
		
		var next = container.nextSibling;
		var isNextSame = next && (next.nodeName == container.nodeName && next.className == container.className);
		if((!dir || dir.toLowerCase() == 'next') && (isNextSame || (force && this.tree.isListContainer(next)))) {
			while(next.firstChild) {
				this.insertNodeAt(next.firstChild, container, "end");
			}
			this.deleteNode(next);
		}
	},
	
	/**
	 * Moves child nodes from one element into another.
	 *
	 * @param {Elemet} from source element
	 * @param {Elemet} to target element
	 */
	moveChildNodes: function(from, to) {
		if(this.tree.isDescendantOf(from, to) || ["HTML", "HEAD"].include(to.nodeName))
			throw "Illegal argument. Cannot move children of element[" + from.nodeName + "] to element[" + to.nodeName + "]";
		
		if(from == to) return;
		
		while(from.firstChild) to.appendChild(from.firstChild);
	},
	
	/**
	 * Copies attributes from one element into another.
	 *
	 * @param {Element} from source element
	 * @param {Element} to target element
	 * @param {boolean} copyId copy ID attribute of source element
	 */
	copyAttributes: function(from, to, copyId) {
		// IE overrides this
		
		var attrs = from.attributes;
		if(!attrs) return;
		
		for(var i = 0; i < attrs.length; i++) {
			if(attrs[i].nodeName == "class" && attrs[i].nodeValue) {
				to.className = attrs[i].nodeValue;
			} else if((copyId || !["id"].include(attrs[i].nodeName)) && attrs[i].nodeValue) {
				to.setAttribute(attrs[i].nodeName, attrs[i].nodeValue);
			}
		}
	},

	_indentElements: function(node, blocks, affect) {
		for (var i=0; i < affect.length; i++) {
			if (affect[i] == node || this.tree.isDescendantOf(affect[i], node))
				return;
		}
		leaves = this.tree.getLeavesAtEdge(node);
		
		if (blocks.include(leaves[0])) {
			var affected = this.indentElement(node, true);
			if (affected) {
				affect.push(affected);
				return;
			}
		}
		
		if (blocks.include(node)) {
			var affected = this.indentElement(node, true);
			if (affected) {
				affect.push(affected);
				return;
			}
		}

		var children=$A(node.childNodes);
		for (var i=0; i < children.length; i++)
			this._indentElements(children[i], blocks, affect);
		return;
	},

	indentElements: function(from, to) {
		var blocks = this.getBlockElementsBetween(from, to);
		var top = this.tree.findCommonAncestorAndImmediateChildrenOf(from, to);
		
		var affect = [];
		
		leaves = this.tree.getLeavesAtEdge(top.parent);
		if (blocks.include(leaves[0])) {
			var affected = this.indentElement(top.parent);
			if (affected)
				return [affected];
		}
		
		var children = $A(top.parent.childNodes);
		for (var i=0; i < children.length; i++) {
			this._indentElements(children[i], blocks, affect);
		}
		
		affect = affect.flatten()
		return affect.length > 0 ? affect : blocks;
	},
	
	outdentElementsCode: function(node) {
		if (node.tagName == 'LI')
			node = node.parentNode;
		if (node.tagName == 'OL' && node.className == 'code')
			return true;
		return false;
	},
	
	_outdentElements: function(node, blocks, affect) {
		for (var i=0; i < affect.length; i++) {
			if (affect[i] == node || this.tree.isDescendantOf(affect[i], node))
				return;
		}
		leaves = this.tree.getLeavesAtEdge(node);
		
		if (blocks.include(leaves[0]) && !this.outdentElementsCode(leaves[0])) {
			var affected = this.outdentElement(node, true);
			if (affected) {
				affect.push(affected);
				return;
			}
		}
		
		if (blocks.include(node)) {
			var children = $A(node.parentNode.childNodes);
			var isCode = this.outdentElementsCode(node);
			var affected = this.outdentElement(node, true, isCode);
			if (affected) {
				if (children.include(affected) && this.tree.isListContainer(node.parentNode) && !isCode) {
					for (var i=0; i < children.length; i++) {
						if (blocks.include(children[i]) && !affect.include(children[i]))
							affect.push(children[i]);
					}
				}else
					affect.push(affected);
				return;
			}
		}

		var children=$A(node.childNodes);
		for (var i=0; i < children.length; i++)
			this._outdentElements(children[i], blocks, affect);
		return;
	},

	outdentElements: function(from, to) {
		var start, end;
		
		if (from.parentNode.tagName == 'LI') start=from.parentNode;
		if (to.parentNode.tagName == 'LI') end=to.parentNode;
		
		var blocks = this.getBlockElementsBetween(from, to);
		var top = this.tree.findCommonAncestorAndImmediateChildrenOf(from, to);
		
		var affect = [];
		
		leaves = this.tree.getLeavesAtEdge(top.parent);
		if (blocks.include(leaves[0]) && !this.outdentElementsCode(top.parent)) {
			var affected = this.outdentElement(top.parent);
			if (affected)
				return [affected];
		}
		
		var children = $A(top.parent.childNodes);
		for (var i=0; i < children.length; i++) {
			this._outdentElements(children[i], blocks, affect);
		}

		if (from.offsetParent && to.offsetParent) {
			start = from;
			end = to;
		}else if (blocks.first().offsetParent && blocks.last().offsetParent) {
			start = blocks.first();
			end = blocks.last();
		}
		
		affect = affect.flatten()
		if (!start || !start.offsetParent)
			start = affect.first();
		if (!end || !end.offsetParent)
			end = affect.last();
		
		return this.getBlockElementsBetween(start, end);
	},
	
	/**
	 * Performs indent by increasing element's margin-left
	 */	
	indentElement: function(element, noParent, forceMargin) {
		if(
			!forceMargin &&
			(element.nodeName == "LI" || (!this.tree.isListContainer(element) && !element.previousSibling && element.parentNode.nodeName == "LI"))
		) return this.indentListItem(element, noParent);
		
		var root = this.getRoot();
		if(!element || element == root) return null;
		
		if (element.parentNode != root && !element.previousSibling && !noParent) element=element.parentNode;
		
		var margin = element.style.marginLeft;
		var cssValue = margin ? this._getCssValue(margin, "px") : {value:0, unit:"em"};
		
		cssValue.value += 2;
		element.style.marginLeft = cssValue.value + cssValue.unit;
		
		return element;
	},
	
	/**
	 * Performs outdent by decreasing element's margin-left
	 */	
	outdentElement: function(element, noParent, forceMargin) {
		if(!forceMargin && element.nodeName == "LI") return this.outdentListItem(element, noParent);
		
		var root = this.getRoot();
		if(!element || element == root) return null;
		
		var margin = element.style.marginLeft;
		
		var cssValue = margin ? this._getCssValue(margin, "px") : {value:0, unit:"em"};
		if(cssValue.value == 0) {
			return element.previousSibling || forceMargin ?
				null :
				this.outdentElement(element.parentNode, noParent);
		}
		
		cssValue.value -= 2;
		element.style.marginLeft = cssValue.value <= 0 ? "" : cssValue.value + cssValue.unit;
		if(element.style.cssText == "") element.removeAttribute("style");
		
		return element;
	},
	
	/**
	 * Performs indent for list item
	 */
	indentListItem: function(element, treatListAsNormalBlock) {
		var li = this.getParentElementOf(element, ["LI"]);
		var container = li.parentNode;
		var prev = li.previousSibling;
		if(!li.previousSibling) return this.indentElement(container);
		
		if(li.parentNode.nodeName == "OL" && li.parentNode.className == "code") return this.indentElement(li, treatListAsNormalBlock, true);
		
		if(!prev.lastChild) prev.appendChild(this.makePlaceHolder());
		
		var targetContainer = 
			this.tree.isListContainer(prev.lastChild) ?
			// if there's existing list container, select it as target container
			prev.lastChild :
			// if there's nothing, create new one
			this.insertNodeAt(this.createElement(container.nodeName), prev, "end");
		
		this.wrapAllInlineOrTextNodesAs("P", prev, true);
		
		// perform move
		targetContainer.appendChild(li);
		
		// flatten nested list
		if(!treatListAsNormalBlock && li.lastChild && this.tree.isListContainer(li.lastChild)) {
			var childrenContainer = li.lastChild;
			var child;
			while(child = childrenContainer.lastChild) {
				this.insertNodeAt(child, li, "after");
			}
			this.deleteNode(childrenContainer);
		}
		
		this.unwrapUnnecessaryParagraph(li);
		
		return li;
	},
	
	/**
	 * Performs outdent for list item
	 *
	 * @return {Element} outdented list item or null if no outdent performed
	 */
	outdentListItem: function(element, treatListAsNormalBlock) {
		var li = this.getParentElementOf(element, ["LI"]);
		var container = li.parentNode;

		if(!li.previousSibling) {
			var performed = this.outdentElement(container);
			if(performed) return performed;
		}

		if(li.parentNode.nodeName == "OL" && li.parentNode.className == "code") return this.outdentElement(li, treatListAsNormalBlock, true);
		
		var parentLi = container.parentNode;
		if(parentLi.nodeName != "LI") return null;
		
		if(treatListAsNormalBlock) {
			while(container.lastChild != li) {
				this.insertNodeAt(container.lastChild, parentLi, "after");
			}
		} else {
			// make next siblings as children
			if(li.nextSibling) {
				var targetContainer =
					li.lastChild && this.tree.isListContainer(li.lastChild) ?
						// if there's existing list container, select it as target container
						li.lastChild :
						// if there's nothing, create new one
						this.insertNodeAt(this.createElement(container.nodeName), li, "end");
				
				this.copyAttributes(container, targetContainer);
				
				var sibling;
				while(sibling = li.nextSibling) {
					targetContainer.appendChild(sibling);
				}
			}
		}
		
		// move current LI into parent LI's next sibling
		li = this.insertNodeAt(li, parentLi, "after");
		
		// remove empty container
		if(container.childNodes.length == 0) this.deleteNode(container);
		
		if(li.firstChild && this.tree.isListContainer(li.firstChild)) {
			this.insertNodeAt(this.makePlaceHolder(), li, "start");
		}
		
		this.wrapAllInlineOrTextNodesAs("P", li);
		this.unwrapUnnecessaryParagraph(parentLi);
		
		return li;
	},
	
	/**
	 * Performs justification
	 *
	 * @param {Element} block target element
	 * @param {String} dir one of "LEFT", "CENTER", "RIGHT", "BOTH"
	 */
	justifyBlock: function(block, dir) {
		// if block is only child, select its parent as mover
		while(block.parentNode != this.getRoot() && !block.previousSibling && !block.nextSibling && !this.tree.isListContainer(block.parentNode)) {
			block = block.parentNode;
		}
		
		var styleValue = dir.toLowerCase() == "both" ? "justify" : dir;
		if(styleValue == "left") {
			block.style.textAlign = "";
			if(block.style.cssText == "") block.removeAttribute("style");
		} else {
			block.style.textAlign = styleValue;
		}
		return block;
	},
	
	justifyBlocks: function(blocks, dir) {
		blocks.each(function(block) {
			this.justifyBlock(block, dir);
		}.bind(this));
		
		return blocks;
	},
	
	/**
     * Turn given element into list. If the element is a list already, it will be reversed into normal element.
	 *
	 * @param {Element} element target element
	 * @param {String} type one of "UL", "OL"
	 * @returns {Element} affected element
	 */
	applyList: function(element, type) {
		type = type.toUpperCase();
		var containerTag = type == "UL" ? "UL" : "OL";
		
		if(element.nodeName == "LI" || (element.parentNode.nodeName == "LI" && !element.previousSibling)) {
			var element = this.getParentElementOf(element, ["LI"]);
			var container = element.parentNode;
			if(container.nodeName == containerTag) {
				return this.extractOutElementFromParent(element);
			} else {
				return this.changeListTypeTo(element, type);
			}
		} else {
			return this.turnElementIntoListItem(element, type);
		}
	},
	
	applyLists: function(from, to, type) {
		type = type.toUpperCase();
		var containerTag = type == "UL" ? "UL" : "OL";
		var blocks = this.getBlockElementsBetween(from, to);
		
		// LIs or Non-containing blocks
		var whole = blocks.findAll(function(e) {
			return e.nodeName == "LI" || !this.tree.isBlockContainer(e);
		}.bind(this));
		
		// LIs
		var listItems = whole.findAll(function(e) {return e.nodeName == "LI"}.bind(this));
		
		// Non-containing blocks which is not a descendant of any LIs selected above(listItems).
		var normalBlocks = whole.findAll(function(e) {
			return e.nodeName != "LI" &&
				!(e.parentNode.nodeName == "LI" && !e.previousSibling && !e.nextSibling) &&
				!this.tree.isDescendantOf(listItems, e)
		}.bind(this));
		
		var diffListItems = listItems.findAll(function(e) {
			return e.parentNode.nodeName != containerTag;
		}.bind(this));
		
		// Conditions needed to determine mode
		var hasNormalBlocks = normalBlocks.length > 0;
		var hasDifferentListStyle = diffListItems.length > 0;
		
		var blockToHandle = null;
		
		if(hasNormalBlocks) {
			blockToHandle = normalBlocks;
		} else if(hasDifferentListStyle) {
			blockToHandle = diffListItems;
		} else {
			blockToHandle = listItems;
		}
		
		// perform operation
		for(var i = 0; i < blockToHandle.length; i++) {
			var block = blockToHandle[i];
			
			// preserve original index to restore selection
			var originalIndex = blocks.indexOf(block);
			blocks[originalIndex] = this.applyList(block, type);
		}
		
		return blocks;
	},

	/**
	 * Insert place-holder for given empty element. Empty element does not displayed and causes many editing problems.
	 *
	 * @param {Element} element empty element
	 */
	correctEmptyElement: function(element) {throw "Not implemented"},

	/**
	 * Corrects current block-only-container to do not take any non-block element or node.
	 */
	correctParagraph: function() {throw "Not implemented"},
	
	/**
	 * Makes place-holder for empty element.
	 *
	 * @returns {Node} Platform specific place holder
	 */
	makePlaceHolder: function() {throw "Not implemented"},
	
	/**
	 * Makes empty paragraph which contains only one place-holder
	 */
	makeEmptyParagraph: function() {throw "Not implemented"},

	/**
	 * Applies background color to selected area
	 *
	 * @param {Object} color valid CSS color value
	 */
	applyBackgroundColor: function(color) {throw "Not implemented";},

	/**
	 * Applies foreground color to selected area
	 *
	 * @param {Object} color valid CSS color value
	 */
	applyForegroundColor: function(color) {
		this.execCommand("forecolor", color);
	},
	
	execCommand: function(commandId, param) {throw "Not implemented";},
	
	applyRemoveFormat: function() {throw "Not implemented";},
	applyEmphasis: function() {throw "Not implemented";},
	applyStrongEmphasis: function() {throw "Not implemented";},
	applyStrike: function() {throw "Not implemented";},
	applyUnderline: function() {throw "Not implemented";},
	applySuperscription: function() {
		this.execCommand("superscript");
	},
	applySubscription: function() {
		this.execCommand("subscript");
	},
	applyQuote: function() {
		alert("TODO");
		return;
	},
	indentBlock: function(element, treatListAsNormalBlock) {
		return (!element.previousSibling && element.parentNode.nodeName == "LI") ?
			this.indentListItem(element, treatListAsNormalBlock) :
			this.indentElement(element);
	},
	outdentBlock: function(element, treatListAsNormalBlock) {
		while(true) {
			if(!element.previousSibling && element.parentNode.nodeName == "LI") {
				element = this.outdentListItem(element, treatListAsNormalBlock);
				return element;
			} else {
				var performed = this.outdentElement(element);
				if(performed) return performed;
				
				// first-child can outdent container
				if(!element.previousSibling) {
					element = element.parentNode;
				} else {
					break;
				}
			}
		}
		
		return null;
	},
	wrapBlock: function(tag, start, end) {
		if(!this.tree._blockTags.include(tag)) throw "Unsuppored block container: [" + tag + "]";
		if(!start) start = this.getCurrentBlockElement();
		if(!end) end = start;
		
		// Check if the selection captures valid fragement
		var validFragment = false;
		
		if(start == end) {
			// are they same block?
			validFragment = true;
		} else if(start.parentNode == end.parentNode && !start.previousSibling && !end.nextSibling) {
			// are they covering whole parent?
			validFragment = true;
			start = end = start.parentNode;
		} else {
			// are they siblings of non-LI blocks?
			validFragment =
				(start.parentNode == end.parentNode) &&
				(start.nodeName != "LI");
		}
		
		if(!validFragment) return null;
		
		var wrapper = this.createElement(tag);
		
		if(start == end) {
			// They are same.
			if(this.tree.isBlockContainer(start) && !this.tree.isListContainer(start)) {
				// It's a block container. Wrap its contents.
				if(this.tree.isBlockOnlyContainer(wrapper)) {
					this.correctEmptyElement(start);
					this.wrapAllInlineOrTextNodesAs("P", start, true);
				}
				this.moveChildNodes(start, wrapper);
				start.appendChild(wrapper);
			} else {
				// It's not a block container. Wrap itself.
				wrapper = this.insertNodeAt(wrapper, start, "after");
				wrapper.appendChild(start);
			}
			
			this.correctEmptyElement(wrapper);
		} else {
			// They are siblings. Wrap'em all.
			wrapper = this.insertNodeAt(wrapper, start, "before");
			var node = start;
			
			while(node != end) {
				next = node.nextSibling;
				wrapper.appendChild(node);
				node = next;
			}
			wrapper.appendChild(node);
		}
		
		return wrapper;
	},


	
	/////////////////////////////////////////////
	// Focus/Caret/Selection
	
	/**
	 * Gives focus to root element's window
	 */
	focus: function() {throw "Not implemented";},

	/**
	 * Returns selection object
	 */
	sel: function() {throw "Not implemented";},
	
	/**
	 * Returns range object
	 */
	rng: function() {throw "Not implemented";},
	
	/**
	 * Returns true if DOM has selection
	 */
	hasSelection: function() {throw "Not implemented";},

	/**
	 * Returns true if root element's window has selection
	 */
	hasFocus: function() {
		var cur = this.getCurrentElement();
		return (cur && cur.ownerDocument == this.getDoc());
	},
	
	/**
	 * Adjust scrollbar to make the element visible in current viewport.
	 *
	 * @param {Element} element Target element
	 * @param {boolean} toTop Align element to top of the viewport
	 * @param {boolean} moveCaret Move caret to the element
	 */
	scrollIntoView: function(element, toTop, moveCaret) {
		element.scrollIntoView(toTop);
		if(moveCaret) this.placeCaretAtStartOf(element);
	},
	
	/**
	 * Select all document
	 */
	selectAll: function() {
		return this.execCommand('selectall');
	},
	
	/**
	 * Select specified element.
	 *
	 * @param {Element} element element to select
	 * @param {boolean} entireElement true to select entire element, false to select inner content of element 
	 */
	selectElement: function(node, entireElement) {throw "Not implemented"},
	
	/**
	 * Select all elements between two blocks(inclusive).
	 *
	 * @param {Element} start start of selection
	 * @param {Element} end end of selection
	 */
	selectBlocksBetween: function(start, end) {throw "Not implemented"},
	
	/**
	 * Delete selected area
	 */
	deleteSelection: function() {throw "Not implemented"},
	
	/**
	 * Collapses current selection.
	 *
	 * @param {boolean} toStart true to move caret to start of selected area.
	 */
	collapseSelection: function(toStart) {throw "Not implemented"},
	
	/**
	 * Returns selected area as HTML string
	 */
	getSelectionAsHtml: function() {throw "Not implemented"},
	
	/**
	 * Returns selected area as text string
	 */
	getSelectionAsText: function() {throw "Not implemented"},
	
	/**
	 * Places caret at start of the element
	 *
	 * @param {Element} element Target element
	 */
	placeCaretAtStartOf: function(element) {throw "Not implemented"},
	
	/**
	 * Checks if the node is empty-text-node or not
	 */
	isEmptyTextNode: function(node) {
		return node.nodeType == 3 && node.nodeValue.length == 0;
	},
	
	/**
	 * Checks if the caret is place in empty block element
	 */
	isCaretAtEmptyBlock: function() {
		return this.isEmptyBlock(this.getCurrentBlockElement());
	},
	
	/**
	 * Checks if the caret is place at start of the block
	 */
	isCaretAtBlockStart: function() {throw "Not implemented"},

	/**
	 * Checks if the caret is place at end of the block
	 */
	isCaretAtBlockEnd: function() {throw "Not implemented"},
	
	/**
	 * Saves current selection info
	 *
	 * @returns {Object} Bookmark for selection
	 */
	saveSelection: function() {throw "Not implemented"},
	
	/**
	 * Restores current selection info
	 *
	 * @param {Object} bookmark Bookmark
	 */
	restoreSelection: function(bookmark) {throw "Not implemented"},
	
	/**
	 * Create marker
	 */
	createMarker: function() {
		var marker = this.createElement("SPAN");
		marker.id = "xquared_marker_" + (this._lastMarkerId++);
		marker.className = "xquared_marker";
		return marker;
	},

	/**
	 * Create and insert marker into current caret position.
	 * Marker is an inline element which has no child nodes. It can be used with many purposes.
	 * For example, You can push marker to mark current caret position.
	 *
	 * @returns {Element} marker
	 */
	pushMarker: function() {
		var marker = this.createMarker();
		return this.insertNode(marker);
	},
	
	/**
	 * Removes last marker
	 *
	 * @params {boolean} moveCaret move caret into marker before delete.
	 */
	popMarker: function(moveCaret) {
		var id = "xquared_marker_" + (--this._lastMarkerId);
		var marker = this.$(id);
		if(moveCaret) {
			this.selectElement(marker, true);
			this.collapseSelection(false);
		}
		
		this.deleteNode(marker);
	},
	
	
	
	/////////////////////////////////////////////
	// Query methods
	
	/**
	 * Returns outer HTML of given element
	 */
	getOuterHTML: function(element) {throw "Not implemented"},
	
	/**
	 * Returns inner text of given element
	 * 
	 * @param {Element} element Target element
	 * @returns {String} Text string
	 */
	getInnerText: function(element) {
		return element.innerHTML.stripTags();
	},

	/**
	 * Checks if given node is place holder or not.
	 * 
	 * @param {Node} node DOM node
	 */
	isPlaceHolder: function(node) {throw "Not implemented"},
	
	/**
	 * Checks if given block is the first LI whose next sibling is a nested list.
	 *
	 * @param {Element} block Target block
	 */
	isFirstLiWithNestedList: function(block) {
		return !block.previousSibling &&
			block.parentNode.nodeName == "LI" &&
			this.tree.isListContainer(block.nextSibling);
	},
	
	/**
	 * Search all headings of given element
	 *
	 * @param {Element} element Container element
	 * @returns {Array} Array of headings. It returns empty array if there's no headings.
	 */
	searchHeadings: function(element, found) {
		if(!element) element = this.getRoot();
		if(!found) found = [];

		var regexp = /^h[1-6]/ig;

		if (!element.childNodes) return [];
		$A(element.childNodes).each(function(child) {
			var isContainer = child && this.tree._blockContainerTags.include(child.nodeName);
			var isHeading = child && child.nodeName.match(regexp);

			if (isContainer) {
				this.searchHeadings(child, found);
			} else if (isHeading) {
				found.push(child);
			}
		}.bind(this));

		return found;
	},
	
	/**
	 * Find elements by CSS selector.
	 *
	 * WARNING: Use this method carefully since prototype.js doesn't work well with designMode DOM.
	 */
	findBySelector: function(selector) {
		return Element.getElementsBySelector(this.root, selector);
	},
	
	/**
	 * Find elements by attribute.
	 * 
	 * This method will be deprecated when findBySelector get stabilized.
	 */
	findByAttribute: function(name, value) {
		var nodes = [];
		this._findByAttribute(nodes, this.root, name, value);
		return nodes;
	},
	
	/** @private */
	_findByAttribute: function(nodes, element, name, value) {
		if(element.getAttribute(name) == value) nodes.push(element);
		if(!element.hasChildNodes()) return;
		
		var children = element.childNodes;
		for(var i = 0; i < children.length; i++) {
			if(children[i].nodeType == 1) this._findByAttribute(nodes, children[i], name, value);
		}
	},
	
	/**
	 * Checks if the element has one or more important attributes: id, class, style
	 *
	 * @param {Element} element Target element
	 */
	hasImportantAttributes: function(element) {throw "Not implemented"},
	
	/**
	 * Checks if the element is empty or not. Place-holder is not counted as a child.
	 *
	 * @param {Element} element Target element
	 */
	isEmptyBlock: function(element) {throw "Not implemented"},
	
	/**
	 * Returns element that contains caret.
	 */
	getCurrentElement: function() {throw "Not implemented"},
	
	/**
	 * Returns block element that contains caret.
	 */
	getCurrentBlockElement: function() {
		var block = this.getParentBlockElementOf(this.getCurrentElement());
		return (block.nodeName == "BODY") ? block.firstChild : block;
	},
	
	/**
	 * Returns parent block element of parameter.
	 * If the parameter itself is a block, it will be returned.
	 *
	 * @param {Element} element Target element
	 *
	 * @returns {Element} Element or null
	 */
	getParentBlockElementOf: function(element) {
		while(element) {
			if(this.tree._blockTags.include(element.nodeName)) return element;
			element = element.parentNode;
		}
		return null;
	},
	
	/**
	 * Returns parent element of parameter which has one of given tag name.
	 * If the parameter itself has the same tag name, it will be returned.
	 *
	 * @param {Element} element Target element
	 * @param {Array} tagNames Array of string which contains tag names
	 *
	 * @returns {Element} Element or null
	 */
	getParentElementOf: function(element, tagNames) {
		while(element) {
			if(tagNames.include(element.nodeName)) return element;
			element = element.parentNode;
		}
		return null;
	},
	
	/**
	 * Collects all block elements between two elements
	 *
	 * @param {Element} from Start element(inclusive)
	 * @param {Element} to End element(inclusive)
	 */
	getBlockElementsBetween: function(from, to) {
		return this.tree.collectNodesBetween(from, to, function(node) {
			return node.nodeType == 1 && this.tree.isBlock(node);
		}.bind(this));
	},
	
	/**
	 * Returns block element that contains selection start.
	 *
	 * This method will return exactly same result with getCurrentBlockElement method
	 * when there's no selection.
	 */
	getBlockElementAtSelectionStart: function() {throw "Not implemented"},
	
	/**
	 * Returns block element that contains selection end.
	 *
	 * This method will return exactly same result with getCurrentBlockElement method
	 * when there's no selection.
	 */
	getBlockElementAtSelectionEnd: function() {throw "Not implemented"},
	
	/**
	 * Returns blocks at each edge of selection(start and end).
	 *
	 * TODO: implement ignoreEmptyEdges for FF
	 *
	 * @param {boolean} naturalOrder Mak the start element always comes before the end element
	 * @param {boolean} ignoreEmptyEdges Prevent some browser(Gecko) from selecting one more block than expected
	 */
	getBlockElementsAtSelectionEdge: function(naturalOrder, ignoreEmptyEdges) {throw "Not implemented"},
	
	/**
	 * Returns array of selected block elements
	 */
	getSelectedBlockElements: function() {
		var selectionEdges = this.getBlockElementsAtSelectionEdge(true, true);
		var start = selectionEdges[0];
		var end = selectionEdges[1];
		
		return this.tree.collectNodesBetween(start, end, function(node) {
			return node.nodeType == 1 && this.tree.isBlock(node);
		}.bind(this));
	},
	
	/**
	 * Get element by ID
	 *
	 * @param {String} id Element's ID
	 * @returns {Element} element or null
	 */
	getElementById: function(id) {return this.doc.getElementById(id)},
	
	/**
	 * Shortcut for #getElementById
	 */
	$: function(id) {return this.getElementById(id)},
	
	/**
	  * Returns first "valid" child of given element. It ignores empty textnodes.
	  *
	  * @param {Element} element Target element
	  * @returns {Node} first child node or null
	  */
	getFirstChildOf: function(element) {
		if(!element) return null;
		
		var nodes = $A(element.childNodes);
		for(var i = 0; i < nodes.length; i++) {
			if(!this.isEmptyTextNode(nodes[i])) return nodes[i];
		}
		return null;
	},
	
	/**
	  * Returns last "valid" child of given element. It ignores empty textnodes and place-holders.
	  *
	  * @param {Element} element Target element
	  * @returns {Node} last child node or null
	  */
	getLastChildOf: function(element) {throw "Not implemented"},

	/** @private */
	_getCssValue: function(str, defaultUnit) {
		if(!str || str.length == 0) return {value:0, unit:defaultUnit};
		
		var tokens = str.match(/(\d+)(.*)/);
		return {
			value:parseInt(tokens[1]),
			unit:tokens[2] || defaultUnit
		};
	}
};

/**
 * Creates and returns instance of browser specific implementation.
 */
xq.RichDom.createInstance = function() {
	if(xq.Browser.isTrident) {
		return new xq.RichDomTrident();
	} else if(xq.Browser.isWebkit) {
		return new xq.RichDomWebkit();
	} else {
		return new xq.RichDomGecko();
	}
}
/**
 * RichDom for W3C Standard Engine
 */
xq.RichDomW3 = Class.create();
xq.RichDomW3.prototype = {
	insertNode: function(node) {
		var rng = this.rng();
		rng.insertNode(node);
		rng.selectNode(node);
		rng.collapse(false);
		return node;
	},

	removeTrailingWhitespace: function(block) {
		// TODO: do nothing
	},

	getOuterHTML: function(element) {
		var div = element.ownerDocument.createElement("div");
		div.appendChild(element.cloneNode(true));
		return div.innerHTML;
	},
	
	correctEmptyElement: function(element) {
		if(!element || element.nodeType != 1 || this.tree.isAtomic(element)) return;
		
		if(element.firstChild)
			this.correctEmptyElement(element.firstChild);
		else
			element.appendChild(this.makePlaceHolder());
	},

	correctParagraph: function() {
		if(this.hasSelection()) return;
		
		var block = this.getCurrentElement();
		
		if(this.tree.isBlockOnlyContainer(block)) {
			this.execCommand("InsertParagraph")
		} else if(this.tree.hasMixedContents(block)) {
			this.wrapAllInlineOrTextNodesAs("P", block, true);
		}
	},

	applyBackgroundColor: function(color) {
		this.execCommand("styleWithCSS", "true");
		this.execCommand("hilitecolor", color);
		this.execCommand("styleWithCSS", "false");
		
		// 0. Save current selection
		var bookmark = this.saveSelection();
		
		// 1. Get selected blocks
		var blocks = this.getSelectedBlockElements();
		if(blocks.length == 0) return;
		
		// 2. Apply background-color to all adjust inline elements
		// 3. Remove background-color from blocks
		for(var i = 0; i < blocks.length; i++) {
			if((i == 0 || i == blocks.length-1) && !blocks[i].style.backgroundColor) continue;
			
			var spans = this.wrapAllInlineOrTextNodesAs("SPAN", blocks[i], true);
			for(var j = 0; j < spans.length; j++) {
				spans[j].style.backgroundColor = color;
			}
			blocks[i].style.backgroundColor = "";
		}
		
		// 4. Restore selection
		this.restoreSelection(bookmark);
	},
	
	
	
	
	//////
	// Commands
	execCommand: function(commandId, param) {
		return this.doc.execCommand(commandId, false, param || null);
	},
	
	saveSelection: function() {
		var rng = this.rng();
		return [rng.startContainer, rng.startOffset, rng.endContainer, rng.endOffset];
	},
	
	restoreSelection: function(bookmark) {
		var rng = this.rng();
		rng.setStart(bookmark[0], bookmark[1]);
		rng.setEnd(bookmark[2], bookmark[3]);
	},
	
	applyRemoveFormat: function() {
		this.execCommand("RemoveFormat");
		this.execCommand("Unlink");
	},
	applyEmphasis: function() {
		// Generate <i> tag. It will be replaced with <emphasis> tag during cleanup phase.
		this.execCommand("styleWithCSS", "false");
		this.execCommand("italic");
	},
	applyStrongEmphasis: function() {
		// Generate <b> tag. It will be replaced with <strong> tag during cleanup phase.
		this.execCommand("styleWithCSS", "false");
		this.execCommand("bold");
	},
	applyStrike: function() {
		// Generate <strike> tag. It will be replaced with <style class="strike"> tag during cleanup phase.
		this.execCommand("styleWithCSS", "false");
		this.execCommand("strikethrough");
	},
	applyUnderline: function() {
		// Generate <u> tag. It will be replaced with <em class="underline"> tag during cleanup phase.
		this.execCommand("styleWithCSS", "false");
		this.execCommand("underline");
	},
	execHeading: function(level) {
		this.execCommand("Heading", "H" + level);
	},



	//////
	// Focus/Caret/Selection
	
	focus: function() {
		setTimeout(this._focus.bind(this), 0);
	},
	
	/** @private */
	_focus: function() {
		this.win.focus();
		if(!this.hasSelection() && this.getCurrentElement().nodeName == "HTML") {
			this.selectElement(this.doc.body.firstChild);
			this.collapseSelection(true);
		}
	},

	sel: function() {
		return this.win.getSelection();
	},
	
	rng: function() {
		var sel = this.sel();
		return (sel == null || sel.rangeCount == 0) ? null : sel.getRangeAt(0);
	},

	hasSelection: function() {
		var sel = this.sel();
		return sel && !sel.isCollapsed;
	},
	
	deleteSelection: function() {
		this.rng().deleteContents();
		this.sel().collapseToStart();
	},
	
	selectElement: function(element, entireElement) {throw "Not implemented yet"},

	selectBlocksBetween: function(start, end) {
		// required to avoid FF selection bug.
		this.doc.execCommand("SelectAll", false, null);
		
		var rng = this.rng();
		rng.setStart(start.firstChild, 0);
		rng.setEnd(end, end.childNodes.length);
	},

	collapseSelection: function(toStart) {
		this.rng().collapse(toStart);
	},
	
	placeCaretAtStartOf: function(element) {
		while(this.tree.isBlock(element.firstChild)) {
			element = element.firstChild;
		}
		this.selectElement(element, false);
		this.collapseSelection(true);
	},
	
	getSelectionAsHtml: function() {
		var container = document.createElement("div");
		container.appendChild(this.rng().cloneContents());
		return container.innerHTML;
	},
	
	getSelectionAsText: function() {
		return this.rng().toString()
	},
	
	hasImportantAttributes: function(element) {
		return !!(element.id || element.className || element.style.cssText);
	},
	
	isEmptyBlock: function(element) {
		if(!element.hasChildNodes()) return true;
		var children = element.childNodes;
		for(var i = 0; i < children.length; i++) {
			if(!this._isPlaceHolder(children[i]) && !this.isEmptyTextNode(children[i])) return false;
		}
		return true;
	},
	
	getLastChildOf: function(element) {
		if(!element || !element.hasChildNodes()) return null;
		
		var nodes = $A(element.childNodes).reverse();
		
		for(var i = 0; i < nodes.length; i++) {
			if(!this._isPlaceHolder(nodes[i]) && !this.isEmptyTextNode(nodes[i])) return nodes[i];
		}
		return null;
	},
	
	getCurrentElement: function() {
		var rng = this.rng();
		if(!rng) return null;
		
		var container = rng.startContainer;
		return container.nodeType == 3 ? container.parentNode : container;
	},

	getBlockElementsAtSelectionEdge: function(naturalOrder, ignoreEmptyEdges) {
		var start = this.getBlockElementAtSelectionStart();
		var end = this.getBlockElementAtSelectionEnd();
		
		var reversed = false;
		
		if(naturalOrder && start != end && this.tree.checkTargetBackward(start, end)) {
			var temp = start;
			start = end;
			end = temp;
			
			reversed = true;
		}
		
		if(ignoreEmptyEdges && start != end) {
			// TODO - Firefox sometimes selects one more block.
/*
			
			var sel = this.sel();
			if(reversed) {
				if(sel.focusNode.nodeType == 1) start = start.nextSibling;
				if(sel.anchorNode.nodeType == 3 && sel.focusOffset == 0) end = end.previousSibling;
			} else {
				if(sel.anchorNode.nodeType == 1) start = start.nextSibling;
				if(sel.focusNode.nodeType == 3 && sel.focusOffset == 0) end = end.previousSibling;
			}
*/
		}
		
		return [start, end];
	},
	
	getBlockElementAtSelectionStart: function() {
		var block = this.getParentBlockElementOf(this.sel().anchorNode);
		
		// find bottom-most first block child
		while(this.tree.isBlockContainer(block) && block.firstChild && this.tree.isBlock(block.firstChild)) {
			block = block.firstChild;
		}
		
		return block;
	},
	
	getBlockElementAtSelectionEnd: function() {
		var block = this.getParentBlockElementOf(this.sel().focusNode);
		
		// find bottom-most last block child
		while(this.tree.isBlockContainer(block) && block.lastChild && this.tree.isBlock(block.lastChild)) {
			block = block.lastChild;
		}
		
		return block;
	},

	isCaretAtBlockStart: function() {
		if(this.isCaretAtEmptyBlock()) return true;
		if(this.hasSelection()) return false;
		var rng = this.rng();
		var node = this.getCurrentBlockElement();
		var isTrue = false;
		
		if(node == rng.startContainer) {
			var marker = this.pushMarker();
			while (node = this.getFirstChildOf(node)) {
				if (node == marker) {
					isTrue = true;
					break;
				}
			}
			this.popMarker();
		} else {
			while (node = node.firstChild) {
				if (node == rng.startContainer && rng.startOffset == 0) {
					isTrue = true;
					break;
				}
			}
		}
		
		return isTrue;
	},
	
	isCaretAtBlockEnd: function() {
		if(this.isCaretAtEmptyBlock()) return true;
		if(this.hasSelection()) return false;
		
		var rng = this.rng();
		var node = this.getCurrentBlockElement();
		var isTrue = false;
		
		if(node == rng.startContainer) {
			var marker = this.pushMarker();
			while (node = this.getLastChildOf(node)) {
				if ((node == marker) || (this.isPlaceHolder(node) && node.previousSibling == marker)) {
					isTrue = true;
					break;
				}
			}
			this.popMarker();
		} else {
			while (node = this.getLastChildOf(node)) {
				if (node == rng.endContainer && rng.endContainer.nodeType == 1) {
					isTrue = true;
					break;
				} else if (node == rng.endContainer && rng.endOffset == node.nodeValue.length) {
					isTrue = true;
					break;
				}
			}
		}
		
		return isTrue;
	},
	
	_isPlaceHolder: function(node) {
		return node.nodeType == 1 && node.nodeName == "BR" && node.getAttribute("type") == "_moz";
	}	
}
xq.RichDomW3.prototype = Object.extend(new xq.RichDom(), xq.RichDomW3.prototype);
/**
 * RichDom for Gecko
 */
xq.RichDomGecko = Class.create();
xq.RichDomGecko.prototype = {
	makePlaceHolder: function() {
		var holder = this.createElement("BR");
		holder.setAttribute("type", "_moz");
		holder.setAttribute("_moz_dirty", "");
		return holder;
	},
	
	makeEmptyParagraph: function() {
		return this.createElementFromHtml('<p><br type="_moz" _moz_dirty /></p>');
	},
	
	isPlaceHolder: function(node) {
		return node.nodeName == "BR" && node.getAttribute("type") == "_moz";
	},

	selectElement: function(element, entireElement) {
		if(!element) throw "[element] is null";
		if(element.nodeType != 1) throw "[element] is not an element";

		// required to avoid FF selection bug.
		try {
			this.doc.execCommand("SelectAll", false, null);
		} catch(ignored) {}
		
		if(entireElement) {
			this.rng().selectNode(element);
		} else {
			this.rng().selectNodeContents(element);
		}
	}
}
xq.RichDomGecko.prototype = Object.extend(new xq.RichDomW3(), xq.RichDomGecko.prototype);
/**
 * RichDom for Webkit
 */
xq.RichDomWebkit = Class.create();
xq.RichDomWebkit.prototype = {
	makePlaceHolder: function() {
		var holder = this.createElement("BR");
		holder.className = "webkit-block-placeholder";
		return holder;
	},
	
	isPlaceHolder: function(node) {
		return node.nodeName == "BR" && node.className == "webkit-block-placeholder";
	},

	selectElement: function(element, entireElement) {
		if(!element) throw "[element] is null";
		if(element.nodeType != 1) throw "[element] is not an element";
		
		if(entireElement) {
			this.rng().selectNode(element);
		} else {
			this.rng().selectNodeContents(element);
		}
	}
}
xq.RichDomWebkit.prototype = Object.extend(new xq.RichDomW3(), xq.RichDomWebkit.prototype);


/**
 * RichDom for Internet Explorer 6 and 7
 */
xq.RichDomTrident = Class.create();
xq.RichDomTrident.prototype = {
	makePlaceHolder: function() {
		return this.createTextNode(" ");
	},
	
	makeEmptyParagraph: function() {
		return this.createElementFromHtml("<p>&nbsp;</p>");
	},

	isPlaceHolder: function(node) {
		return false;
	},

	getOuterHTML: function(element) {
		return element.outerHTML;
	},
	
	insertNode: function(node) {
		if(this.hasSelection()) this.collapseSelection(true);
		
		this.rng().pasteHTML('<span id="xquared_temp"></span>');
		var marker = this.$('xquared_temp');
		if(node.id == 'xquared_temp') return marker;
		
		marker.replaceNode(node);
		return node;
	},
	
	removeTrailingWhitespace: function(block) {
		if(!block) return;
		
		// TODO: reimplement to handle atomic tags and so on. (use DomTree)
		
		if(this.isEmptyBlock(block)) return;
		
		var text = block.innerText;
		var lastCharCode = text.charCodeAt(text.length - 1);
		if(text.length <= 1 || ![32,160].include(lastCharCode)) return;
		
		var node = block;
		
		while(node && node.nodeType != 3) node = node.lastChild;
		
		if(!node) return;
		
		if(node.nodeValue.length == 1) {
			this.deleteNode(node);
		} else {
			node.nodeValue = node.nodeValue.substring(0, node.nodeValue.length - 1);
		}
	},
	
	correctEmptyElement: function(element) {
		if(!element || element.nodeType != 1 || this.tree.isAtomic(element)) return;
		
		if(element.firstChild) {
			this.correctEmptyElement(element.firstChild);
		} else {
			element.innerHTML = "&nbsp;";
		}
	},

	copyAttributes: function(from, to, copyId) {
		to.mergeAttributes(from, !copyId);
	},

	correctParagraph: function() {
		if(!this.hasFocus()) return;
		if(this.hasSelection()) return;
		var block = this.getCurrentBlockElement();
		
		if(block.nodeType == 3) block = block.parentNode;
		
		if(this.tree.hasMixedContents(block)) {
			var marker = this.pushMarker();
			this.wrapAllInlineOrTextNodesAs("P", block, true);
			this.popMarker(true);
		} else if((this.tree.isTextOrInlineNode(block.previousSibling) || this.tree.isTextOrInlineNode(block.nextSibling)) && this.tree.hasMixedContents(block.parentNode)) {
			// IE?�서??Block�?Inline/Text�??�접??경우 getCurrentElement ?�이 ?�작?�한??
			// ?�라???�재 Block 주�?까�? ?�번???�아주어???�다.
			this.wrapAllInlineOrTextNodesAs("P", block.parentNode, true);
		}
	},

	applyBackgroundColor: function(color) {
		this.execCommand("BackColor", color);
	},
	
	
	
	//////
	// Commands
	execCommand: function(commandId, param) {
		return this.doc.execCommand(commandId, false, param);
	},
	
	applyEmphasis: function() {
		// Generate <i> tag. It will be replaced with <emphasis> tag during cleanup phase.
		this.execCommand("Italic");
	},
	applyStrongEmphasis: function() {
		// Generate <b> tag. It will be replaced with <strong> tag during cleanup phase.
		this.execCommand("Bold");
	},
	applyStrike: function() {
		// Generate <strike> tag. It will be replaced with <style class="strike"> tag during cleanup phase.
		this.execCommand("strikethrough");
	},
	applyUnderline: function() {
		// Generate <u> tag. It will be replaced with <em class="underline"> tag during cleanup phase.
		this.execCommand("underline");
	},
	applyRemoveFormat: function() {
		this.execCommand("RemoveFormat");
		this.execCommand("Unlink");
	},
	execHeading: function(level) {
		this.execCommand("FormatBlock", "<H" + level + ">");
	},



	//////
	// Focus/Caret/Selection
	
	focus: function() {
		this.win.focus();
	},

	sel: function() {
		return this.doc.selection;
	},
	
	rng: function() {
		try {
			var sel = this.sel();
			return (sel == null) ? null : sel.createRange();
		} catch(ignored) {
			// IE often fails
			return null;
		}
	},
	
	hasSelection: function() {
		var selectionType = this.sel().type.toLowerCase();
		if("none" == selectionType) return false;
		if("text" == selectionType && this.getSelectionAsHtml().length == 0) return false;
		return true;
	},
	deleteSelection: function() {
		if(this.getSelectionAsText() != "") this.sel().clear();
	},
	
	placeCaretAtStartOf: function(element) {
		// If there's no empty span, caret sometimes moves into a previous node.
		var ph = this.createElement("SPAN");
		this.insertNodeAt(ph, element, "start");
		this.selectElement(ph);
		this.collapseSelection(false);
		this.deleteNode(ph);
	},
	
	selectElement: function(element, entireElement) {
		if(!element) throw "[element] is null";
		if(element.nodeType != 1) throw "[element] is not an element";
		
		var rng = this.rng();
		rng.moveToElementText(element);
		rng.select();
	},

	selectBlocksBetween: function(start, end) {
		var rng = this.rng();
		var rngTemp = this.rng();

		rngTemp.moveToElementText(start);
		rng.setEndPoint("StartToStart", rngTemp);
		
		rngTemp.moveToElementText(end);
		rng.setEndPoint("EndToEnd", rngTemp);
		
		rng.select();
	},
	
	collapseSelection: function(toStart) {
		var rng = this.rng();
		rng.collapse(toStart);
		rng.select();
	},
	
	getSelectionAsHtml: function() {
		var rng = this.rng()
		return rng && rng.htmlText ? rng.htmlText : ""
	},
	
	getSelectionAsText: function() {
		var rng = this.rng();
		return rng && rng.text ? rng.text : "";
	},
	
	hasImportantAttributes: function(element) {
		return !!(element.id || element.className || element.style.cssText);
	},

	isEmptyBlock: function(element) {
		if(!element.hasChildNodes()) return true;
		if(element.nodeType == 3 && !element.nodeValue) return true;
		if(["&nbsp;", " ", ""].include(element.innerHTML)) return true;
		
		return false;
	},
	
	getLastChildOf: function(element) {
		if(!element || !element.hasChildNodes()) return null;
		
		var nodes = $A(element.childNodes).reverse();
		
		for(var i = 0; i < nodes.length; i++) {
			if(nodes[i].nodeType != 3 || nodes[i].nodeValue.length != 0) return nodes[i];
		}
		
		return null;
	},
	
	getCurrentElement: function() {
		if(this.sel().type.toLowerCase() == "control") return this.rng().item(0);
		return this.rng().parentElement();
	},
	
	getBlockElementAtSelectionStart: function() {
		var rng = this.rng();
		var dup = rng.duplicate();
		dup.collapse(true);
		
		var result = this.getParentBlockElementOf(dup.parentElement());
		if(result.nodeName == "BODY") result = result.firstChild;
		
		return result;
	},
	
	getBlockElementAtSelectionEnd: function() {
		var rng = this.rng();
		var dup = rng.duplicate();
		dup.collapse(false);
		
		var result = this.getParentBlockElementOf(dup.parentElement());
		if(result.nodeName == "BODY") result = result.lastChild;

		return result;
	},
	
	getBlockElementsAtSelectionEdge: function(naturalOrder, ignoreEmptyEdges) {
		return [
			this.getBlockElementAtSelectionStart(),
			this.getBlockElementAtSelectionEnd()
		];
	},
	
	isCaretAtBlockStart: function() {
		if(this.isCaretAtEmptyBlock()) return true;
		if(this.hasSelection()) return false;
		
		var node = this.getCurrentBlockElement();
		var marker = this.pushMarker();
		
		var isTrue = false;
		while (node = this.getFirstChildOf(node)) {
			if (node == marker) {
				isTrue = true;
				break;
			}
		}
		
		this.popMarker();
		
		return isTrue;
	},
	isCaretAtBlockEnd: function() {
		if(this.isCaretAtEmptyBlock()) return true;
		if(this.hasSelection()) return false;
		
		var node = this.getCurrentBlockElement();
		var marker = this.pushMarker();
		var isTrue = false;
		while (node = this.getLastChildOf(node)) {
			if (node == marker) {
				isTrue = true;
				break;
			} else if(
				node.nodeType == 3 &&
				node.previousSibling == marker &&
				(node.nodeValue == " " || (node.nodeValue && node.nodeValue.charCodeAt(0) == 160)))
			{
				isTrue = true;
				break;
			}
		}
		
		this.popMarker();
		
		return isTrue;
	},
	saveSelection: function() {
		return this.rng();
	},
	restoreSelection: function(bookmark) {
		bookmark.select();
	}
}
xq.RichDomTrident.prototype = Object.extend(new xq.RichDom(), xq.RichDomTrident.prototype);
xq.RichTable = Class.create();
xq.RichTable.prototype = {
	initialize: function(rdom, table) {
		this.rdom = rdom;
		this.table = table;
	},
	insertRowBelow: function(row) {
		
	},
	getPreviousCellOf: function(cell) {
		if(cell.previousSibling) return cell.previousSibling;
		var adjRow = this.getPreviousRowOf(cell.parentNode);
		if(adjRow) return adjRow.lastChild;
		return null;
	},
	getNextCellOf: function(cell) {
		if(cell.nextSibling) return cell.nextSibling;
		var adjRow = this.getNextRowOf(cell.parentNode);
		if(adjRow) return adjRow.firstChild;
		return null;
	},
	getPreviousRowOf: function(row) {
		if(row.previousSibling) return row.previousSibling;
		var rowContainer = row.parentNode;
		if(rowContainer.previousSibling && rowContainer.previousSibling.lastChild) return rowContainer.previousSibling.lastChild;
		return null;
	},
	getNextRowOf: function(row) {
		if(row.nextSibling) return row.nextSibling;
		var rowContainer = row.parentNode;
		if(rowContainer.nextSibling && rowContainer.nextSibling.firstChild) return rowContainer.nextSibling.firstChild;
		return null;
	},
	getAboveCellOf: function(cell) {
		var row = this.getPreviousRowOf(cell.parentNode);
		if(!row) return null;
		
		var x = this.getXIndexOf(cell);
		return row.cells[x];
	},
	getBelowCellOf: function(cell) {
		var row = this.getNextRowOf(cell.parentNode);
		if(!row) return null;
		
		var x = this.getXIndexOf(cell);
		return row.cells[x];
	},
	getXIndexOf: function(cell) {
		var row = cell.parentNode;
		for(var i = 0; i < row.cells.length; i++) {
			if(row.cells[i] == cell) return i;
		}
		
		return -1;
	},
	getYIndexOf: function(cell) {
		var y = -1;
		
		// find y
		var group = row.parentNode;
		for(var i = 0; i <group.rows.length; i++) {
			if(group.rows[i] == row) {
				y = i;
				break;
			}
		}
		if(this.hasHeadingAtTop() && group.nodeName == "TBODY") y = y + 1;
		
		return y;
	},
	/**
	 * TODO: Not used. Delete or not?
	 */
	getLocationOf: function(cell) {
		var x = this.getXIndexOf(cell);
		var y = this.getYIndexOf(cell);
		return {x:x, y:y};
	},
	getCellAt: function(col, row) {
		return this.getRowAt(row).cells[col];
	},
	getRowAt: function(index) {
		if(this.hasHeadingAtTop()) {
			return index == 0 ? this.table.tHead.rows[0] : this.table.tBodies[0].rows[index - 1];
		} else {
			return this.table.tBodies[0].rows[index];
		}
	},
	getDom: function() {
		return this.table;
	},
	hasHeadingAtTop: function() {
		return !!(this.table.tHead && this.table.tHead.rows[0]);
	},
	hasHeadingAtLeft: function() {
		return this.table.tBodies[0].rows[0].cells[0].nodeName == "TH";
	},
	correctEmptyCells: function() {
		var cells = $A(this.table.getElementsByTagName("TH"));
		cells.push($A(this.table.getElementsByTagName("TD")));
		cells = cells.flatten();
		
		for(var i = 0; i < cells.length; i++) {
			if(this.rdom.isEmptyBlock(cells[i])) this.rdom.correctEmptyElement(cells[i])
		}
	}
}
xq.RichTable.create = function(rdom, cols, rows, headerPositions) {
	if(["t", "tl", "lt"].include(headerPositions)) var headingAtTop = true
	if(["l", "tl", "lt"].include(headerPositions)) var headingAtLeft = true

	var sb = []
	sb.push('<table class="datatable">')
	
	// thead
	if(headingAtTop) {
		sb.push('<thead><tr>')
		for(var i = 0; i < cols; i++) sb.push('<th></th>')
		sb.push('</tr></thead>')
		rows -= 1
	}
		
	// tbody
	sb.push('<tbody>')
	for(var i = 0; i < rows; i++) {
		sb.push('<tr>')
		
		for(var j = 0; j < cols; j++) {
			if(headingAtLeft && j == 0) {
				sb.push('<th></th>')
			} else {
				sb.push('<td></td>')
			}
		}
		
		sb.push('</tr>')
	}
	sb.push('</tbody>')
	
	sb.push('</table>')
	
	// create DOM element
	var container = rdom.createElement("div");
	container.innerHTML = sb.join("");
	
	// correct empty cells and return
	var rtable = new xq.RichTable(rdom, container.firstChild);
	rtable.correctEmptyCells();
	return rtable;
}
/**
 * Validates and invalidates designmode contents
 */
xq.Validator = Class.create();
xq.Validator.prototype = {
	initialize: function() {
		this.allowedTags = 'a abbr acronym address blockquote br caption cite code dd dfn div dl dt em h1 h2 h3 h4 h5 h6 hr img kbd li ol p pre q samp span sup sub strong table thead tbody td th tr ul var '
		this.allowedAttrs = 'href src width height alt cite datetime title class style id '
	},
	
	/**
	 * Perform validation on given element
	 *
	 * @param {Element} element Target element. It is not affected by validation.
	 * @param {boolean} fullValidation Perform full validation. If you just want to use the result to assign innerHTML, set it false
	 *
	 * @returns {String} Validated HTML string
	 */
	validate: function(element, fullValidation) {throw "Not implemented"},
	
	/**
	 * Perform invalidation on given element to make the designmode works well.
	 *
	 * @param {Element} element Target element. It is not affected by validation.
	 * @returns {String} Invalidated HTML string
	 */
	invalidate: function(element) {throw "Not implemented"},
	
	validateStrike: function(content) {
		content = content.replace(/<strike(>|\s+[^>]*>)/ig, "<span class=\"strike\"$1");
		content = content.replace(/<\/strike>/ig, "</span>");
		return content;
	},
	
	validateUnderline: function(content) {
		content = content.replace(/<u(>|\s+[^>]*>)/ig, "<em class=\"underline\"$1");
		content = content.replace(/<\/u>/ig, "</em>");
		return content;
	},
	
	replaceTag: function(content, from, to) {
		return content.replace(new RegExp("(</?)" + from + "(>|\\s+[^>]*>)", "ig"), "$1" + to + "$2");
	},
	
	validateSelfClosingTags: function(content) {
		return content.replace(/<(br|hr|img)([^>]*?)>/img, function(str, tag, attrs) {
			return "<" + tag + attrs + " />"
		});
	},
	
	removeComments: function(content) {
		return content.replace(/<!--.*?-->/img, '');
	},
	
	// TODO: very slow
	applyWhitelist: function(content) {
		var allowedTags = this.allowedTags;
		var allowedAttrs = this.allowedAttrs;
		
		return content.replace(new RegExp("(</?)([^>]+?)(>|\\s+([^>]*?)(\\s?/?)>)", "g"), function(str, head, tag, tail, attrs, selfClosing) {
			if(allowedTags.indexOf(tag) == -1) return '';
			
			if(attrs) {
				var sb = [];
				var m = attrs.match(/([^=]+)="[^"]*?"/g);
				for(var i = 0; i < m.length; i++) {
					m[i] = m[i].strip();
					var name = m[i].split('=')[0];
					if(allowedAttrs.indexOf(name) != -1) sb.push(m[i]);
				}
				attrs = sb.join(' ');
				if(attrs != '') attrs = ' ' + attrs;
				return head + tag + attrs + selfClosing + '>';
			} else {
				return str;
			}
		});
	}
};

/**
 * Creates and returns instance of browser specific implementation.
 */
xq.Validator.createInstance = function() {
	if(xq.Browser.isTrident) {
		return new xq.ValidatorTrident();
	} else if(xq.Browser.isWebkit) {
		return new xq.ValidatorWebkit();
	} else {
		return new xq.ValidatorGecko();
	}
}
/**
 * Validator for W3C Standard Engine
 */
xq.ValidatorW3 = Class.create();
xq.ValidatorW3.prototype = {
	validate: function(element, fullValidation) {
		this.validateFontColor(element);

		var content = element.innerHTML;
		
		content = this.replaceTag(content, "b", "strong");
		content = this.replaceTag(content, "i", "em");
		
		content = this.validateStrike(content);
		content = this.validateUnderline(content);
		
		if(fullValidation) content = this.performFullValidation(content);
		
		return content;
	},
	invalidate: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);
		
		this.invalidateFontColor(element);
		
		// <span class="strike"> -> <strike>
		var strikes = rdom.findByAttribute("class", "strike");
		for(var i = 0; i < strikes.length; i++) {
			if("SPAN" == strikes[i].nodeName) rdom.replaceTag("strike", strikes[i]).removeAttribute("class");
		}
		
		// <em|i class="underline"> -> <u>
		var underlines = rdom.findByAttribute("class", "underline");
		for(var i = 0; i < underlines.length; i++) {
			if(["EM", "I"].include(underlines[i].nodeName)) rdom.replaceTag("u", underlines[i]).removeAttribute("class");
		}
		
		var content = rdom.getRoot().innerHTML;
		
		content = this.replaceTag(content, "strong", "b");
		content = this.replaceTag(content, "em", "i");
		content = this.removeComments(content);
		
		return content;
	},
	
	performFullValidation: function(content) {
		content = this.validateSelfClosingTags(content);
		content = this.applyWhitelist(content);
		return content;
	},
	
	validateFontColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);

		var fonts = element.getElementsByTagName('FONT');
		for(var i = 0; i < fonts.length; i++) {
			var font = fonts[i];
			var color = font.getAttribute('color');
			
			if(color) {
				var span = rdom.replaceTag("span", font);
				span.removeAttribute('color');
				span.style.color = color;
			}
		}
	},
	
	invalidateFontColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);

		var spans = element.getElementsByTagName('SPAN');
		for(var i = 0; i < spans.length; i++) {
			var span = spans[i];
			var color = span.style.color;
			
			if(color) {
				var font = rdom.replaceTag("font", span);
				font.style.color = "";
				font.setAttribute('color', color);
			}
		}
	}
}
xq.ValidatorW3.prototype = Object.extend(new xq.Validator(), xq.ValidatorW3.prototype);
/**
 * Validator for Gecko Engine
 */
xq.ValidatorGecko = Class.create();
xq.ValidatorGecko.prototype = {
}
xq.ValidatorGecko.prototype = Object.extend(new xq.ValidatorW3(), xq.ValidatorGecko.prototype);
/**
 * Validator for Webkit
 */
xq.ValidatorWebkit = Class.create();
xq.ValidatorWebkit.prototype = {
}
xq.ValidatorWebkit.prototype = Object.extend(new xq.ValidatorW3(), xq.ValidatorWebkit.prototype);
/**
 * Validator for Internet Explorer 6 and 7
 */
xq.ValidatorTrident = Class.create();
xq.ValidatorTrident.prototype = {
	validate: function(element, fullValidation) {
		this.validateFontColor(element);
		this.validateBackgroundColor(element);

		var content = element.innerHTML;
		
		content = this.validateStrike(content);
		content = this.validateUnderline(content);
		
		if(fullValidation) content = this.performFullValidation(content);
		
		return content;
	},
	
	invalidate: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);
		
		this.invalidateFontColor(element);
		this.invalidateBackgroundColor(element);
		
		// <span class="strike"> -> <strike>
		var strikes = rdom.findByAttribute("className", "strike");
		for(var i = 0; i < strikes.length; i++) {
			if("SPAN" == strikes[i].nodeName) rdom.replaceTag("strike", strikes[i]).removeAttribute("className");
		}
		
		// <em|i class="underline"> -> <u>
		var underlines = rdom.findByAttribute("className", "underline");
		for(var i = 0; i < underlines.length; i++) {
			if(["EM", "I"].include(underlines[i].nodeName)) rdom.replaceTag("u", underlines[i]).removeAttribute("className");
		}

		var content = rdom.getRoot().innerHTML;

		content = this.removeComments(content);
		
		return content;
	},
	
	performFullValidation: function(content) {
		content = this.lowerTagNames(content);
		content = this.validateSelfClosingTags(content);
		content = this.applyWhitelist(content);
		return content;
	},
	
	validateFontColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);
		
		var fonts = element.getElementsByTagName('FONT');
		for(var i = 0; i < fonts.length; i++) {
			var font = fonts[i];
			var color = font.getAttribute('color');
			
			if(color) {
				var span = rdom.replaceTag("span", font);
				span.removeAttribute('color');
				span.style.color = color;
			}
		}
	},

	invalidateFontColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);

		var spans = element.getElementsByTagName('SPAN');
		for(var i = 0; i < spans.length; i++) {
			var span = spans[i];
			var color = span.style.color;
			
			if(color) {
				var font = rdom.replaceTag("font", span);
				font.style.color = "";
				font.setAttribute('color', color);
			}
		}
	},

	validateBackgroundColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);

		var fonts = element.getElementsByTagName('FONT');
		for(var i = 0; i < fonts.length; i++) {
			if(fonts[i].style.color || fonts[i].style.backgroundColor) rdom.replaceTag("span", fonts[i]);
		}
	},

	invalidateBackgroundColor: function(element) {
		var rdom = xq.RichDom.createInstance();
		rdom.setRoot(element);

		var spans = element.getElementsByTagName('SPAN');
		for(var i = 0; i < spans.length; i++) {
			if(spans[i].style.color || spans[i].style.backgroundColor) rdom.replaceTag("font", spans[i]);
		}
	},
	
	lowerTagNames: function(content) {
		// Uniformize quotation, turn tag names and attribute names into lower case
		content = content.replace(/<(\/?)(\w+)([^>]*?)>/img, function(str, closingMark, tagName, attrs) {
			return "<" + closingMark + tagName.toLowerCase() + this.correctHtmlAttrQuotation(attrs) + ">";
		}.bind(this));
		
		return content;
	},
	
	correctHtmlAttrQuotation: function(html) {
		html = html.replace(/(\w+)="([^"]+)"/mg,function (str, name, value) {return name.toLowerCase() + '=' + '"' + value + '"'});
		html = html.replace(/(\w+)=([^ "]+)/mg,function (str, name, value) {return name.toLowerCase() + '=' + '"' + value + '"'});
		return html;
	}
}
xq.ValidatorTrident.prototype = Object.extend(new xq.Validator(), xq.ValidatorTrident.prototype);
/**
 * @fileOverview xq.EditHistory manages editing history and performs UNDO/REDO.
 */
xq.EditHistory = Class.create();
xq.EditHistory.prototype = {
	/**
	 * Initializer
	 *
     * @constructor
	 * @param {xq.RichDom} rdom RichDom instance
	 * @param {Number} [max] maximum UNDO buffer size(default value is 100).
	 */
	initialize: function(rdom, max) {
		if (!rdom) throw "IllegalArgumentException";

		this.disabled = false;
		this.max = max || 100;
		this.rdom = rdom;
		this.root = rdom.getRoot();
		this.clear();
		
		this.lastModified = Date.get();
	},
	getLastModifiedDate: function() {
		return this.lastModified;
	},
	isUndoable: function() {
		return this.queue.length > 0 && this.index > 0;
	},
	isRedoable: function() {
		return this.queue.length > 0 && this.index < this.queue.length - 1;
	},
	disable: function() {
		this.disabled = true;
	},
	enable: function() {
		this.disabled = false;
	},
	undo: function() {
		this.pushContent();
		
		if (this.isUndoable()) {
			this.index--;
			this.popContent();
			return true;
		} else {
			return false;
		}
	},
	redo: function() {
		if (this.isRedoable()) {
			this.index++;
			this.popContent();
			return true;
		} else {
			return false;
		}
	},
	onCommand: function() {
		this.lastModified = Date.get();
		if(this.disabled) return false;

		return this.pushContent();
	},
	onEvent: function(event) {
		this.lastModified = Date.get();
		if(this.disabled) return false;

		// ignore normal keys
		if('keydown' == event.type && !(event.ctrlKey || event.metaKey)) return false;
		if(['keydown', 'keyup', 'keypress'].include(event.type) && !event.ctrlKey && !event.altKey && !event.metaKey && ![33,34,35,36,37,38,39,40].include(event.keyCode)) return false;
		if(['keydown', 'keyup', 'keypress'].include(event.type) && (event.ctrlKey || event.metaKey) && [89,90].include(event.keyCode)) return false;
		
		// ignore ctrl/shift/alt/meta keys
		if([16,17,18,224].include(event.keyCode)) return false;
		
		return this.pushContent();
	},
	popContent: function() {
		this.lastModified = Date.get();
		if (this.queue[this.index].caret > 0) {
			var html=this.queue[this.index].html.substring(0, this.queue[this.index].caret) + '<span id="caret_marker_00700"></span>' + this.queue[this.index].html.substring(this.queue[this.index].caret);
			this.root.innerHTML = html;
		} else {
			this.root.innerHTML = this.queue[this.index].html;
		}
		this.restoreCaret();
	},
	pushContent: function(ignoreCaret) {
		if(xq.Browser.isTrident && !ignoreCaret && !this.rdom.hasFocus()) return false;
		var html = this.root.innerHTML;
		
		if(html == (this.queue[this.index] ? this.queue[this.index].html : null)) return false;
		
		var caret = ignoreCaret ? -1 : this.saveCaret();
		
		if(this.queue.length >= this.max) {
			this.queue.shift();
		} else {
			this.index++;
		}
		
		this.queue.splice(this.index, this.queue.length - this.index, {html:html, caret:caret});
		return true;
	},
	clear: function() {
		this.index = -1;
		this.queue = [];
		this.pushContent(true);
	},
	saveCaret: function() {
		if(this.rdom.hasSelection()) return null;
		
		var bookmark = this.rdom.saveSelection();
		
		var marker = this.rdom.pushMarker();
		var str = xq.Browser.isTrident ? '<SPAN class='+marker.className : '<span class="'+marker.className+'"';
		var caret = this.rdom.getRoot().innerHTML.indexOf(str);
		this.rdom.popMarker();
		
		this.rdom.restoreSelection(bookmark);
		
		return caret;
	},
	restoreCaret: function() {
		var marker = this.rdom.$('caret_marker_00700');
		
		if(marker) {
			this.rdom.selectElement(marker, true);
			this.rdom.collapseSelection(false);
			this.rdom.deleteNode(marker);
		} else {
			var node = this.rdom.tree.findForward(this.rdom.getRoot(), function(node) {
				return this.isBlock(node) && !this.hasBlocks(node);
			}.bind(this.rdom.tree));
			this.rdom.selectElement(node, false);
			this.rdom.collapseSelection(false);
			
		}
	}
}
xq.Macro = Class.create();
xq.Macro.create = function(className, win) {
	var MacroClass = eval(className);
	var macro = new MacroClass(win);
	return macro;
}
xq.Macro.load = function(container) {
	throw "TODO";
}
xq.Macro.prototype = {
	initialize: function(win) {
		this.rdom = xq.RichDom.createInstance();
		this.rdom.setWin(win);
		this.rdom.setRoot(win.document.body);
		
		this.element = null;
		this.canvas = null;
		this.iframe = null;
		this.name = null;
	},
	
	getName: function() {throw "Not implemented"},
	
	insertElement: function() {
		this.element = this.rdom.createElement("DIV");
		this.element.className = "xqMacro " + this.getName();
		this.rdom.insertNode(this.element);
		
		if(xq.Browser.isTrident) this.element.contentEditable = false;
	},
	
	execute: function() {
		// create canvas
		this.canvas = this.rdom.createElement("DIV");
		this.canvas.className = "xqMacroCanvas";
		
		// create iframe
		this.iframe = this.rdom.createElement("IFRAME");
		this.canvas.appendChild(this.iframe);
		
		// append
		this.element.appendChild(this.canvas);
	}
}

xq.Macro.HelloWorld = Class.create();
Object.extend(xq.Macro.HelloWorld.prototype, xq.Macro.prototype);
Object.extend(xq.Macro.HelloWorld.prototype, {
	getName: function() {return "HelloWorld"},
	run: function() {
		this.getBody().innerHTML = 'Hello World, ' + new Date();
	}
});


/*
xq.Macro = Class.create();

xq.Macro.prototype = {
	name: '',
	
	property: {},
	element: null,
	iframe: null,
	staticContents: null,
	doc: null,
	
	editor: null,
	
	initialize: function() {},
	
	init: function(element, properties) {
		this.property = properties;
		
		this.element = element;
		this.element.className = 'xqMacro ' + this.getName();
		this.doc = this.element.ownerDocument;
		
		if (xq.Browser.isTrident) this.element.contentEditable = false;
	},
	
	setEditor: function(editor) {
		this.editor = editor;
	},
	
	getElement: function() {
		return this.element;
	},
	
	putProperty: function() {
		var propertyContainer = this.doc.createElement('DL');
		propertyContainer.style.display = 'none';
		this.element.appendChild(propertyContainer);
		propertyContainer.className = 'xqMacroProperty';
		
		this._putProperty(propertyContainer, this.property);
	},
	
	_putProperty: function(container, property) {
		var dt, dd;
		for (var key in property) {
			dt = this.doc.createElement('DT');
			dt.innerHTML = key;
			container.appendChild(dt);
			
			dd = this.doc.createElement('DD');
			container.appendChild(dd);
			this._putPropertyData(dd, property[key]);
		}
	},
	
	_putPropertyList: function(container, property) {
		var dd;
		for (var i=0; i < property.length; i++) {
			dd = this.doc.createElement('LI');
			container.appendChild(dd);
			
			this._putPropertyData(dd, property[i]);
		}
	},
	
	_putPropertyData: function(dd, property) {
		if (property.__proto__ == Array.prototype || property.__proto__ == Object.prototype) {
			var sub;
			if (property.__proto__ == Array.prototype) {
				sub=this.doc.createElement('OL');
				this._putPropertyList(sub, property);
			}else{
				sub=this.doc.createElement('DL');
				this._putProperty(sub, property);
			}
			dd.appendChild(sub);
		}else
			dd.innerHTML = property.toString();
	},

	execute: function() {
		this.element.innerHTML='';
		
		try{
			this.putProperty();
		}catch(e) {
			throw 'Exception';
		}

		if (!xq.Browser.isTrident) {
			this.iframe = this.doc.createElement('IFRAME');
			this.element.appendChild(this.iframe);

			var doc = this.getDoc();
			doc.open();
			doc.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">');
			doc.write('<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko">');
			doc.write('<head>');
			doc.write('<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />');
			doc.write('</head>');
			doc.write('<body><p></p></body>');
			doc.write('</html>');
			doc.close();
		}

		this.staticContents = this.doc.createElement('DIV');
		this.staticContents.className = 'xqMacroStatic';
		this.element.appendChild(this.staticContents);

		this.run();
		
		this.generateOutput();
	},
	
	generateOutput: function() {
		if (xq.Browser.isTrident) return;
		this.staticContents.innerHTML = this.getBody().innerHTML;
		this.staticContents.style.display='none';

		var links = this.staticContents.getElementsByTagName('A');
		for (var i=0; i < links.length; i++) {
			if (links[i].target && links[i].target == '_parent')
				links[i].target = '';
		} 
	},
	
	getName: function() {
		return this.name;
	},
	
	getDoc: function() {
		if (!xq.Browser.isTrident)
			return this.iframe.contentWindow.document;
		else
			return this.doc;
	},
	getBody: function() {
		if (!xq.Browser.isTrident)
			return this.getDoc().body;
		else
			return this.staticContents;
	}
};

xq.Macro.load = function(container) {
	var macroClass = eval(container.className.replace(/\s?xqMacro\s?/, '').strip());
	var propertiesContainer = xq.Macro.findPropertiesContainer(container);
	var properties = xq.Macro.fromDL2JSON(propertiesContainer);
	var instance = new macroClass();
	instance.init(container, properties);
	return instance;
};

xq.Macro.create = function(className, properties, doc) {
	var macroClass = eval(className);
	var container = doc.createElement('DIV');
	var instance = new macroClass();
	instance.init(properties, json);
	return instance;
};

xq.Macro.findPropertiesContainer = function(container) {
	var dl = element.getElementsByTagName('DL');
	for (var i = 0; i < dl.length; i++) {
		if (dl[i].className.match(/xqMacroProperty/)) return dl[i];
	}
	return null;
};

xq.Macro.fromDL2JSON = function(container) {
	var ret;
	if (container.nodeName == 'DL')
		ret = {};
	else if (container.nodeName == 'OL')
		ret = [];
	else
		return null;

	for (var i=0; i < container.childNodes.length; i++) {
		if (container.nodeName == 'OL') {
			if (container.childNodes[i].firstChild && ['OL', 'DL'].include(container.childNodes[i].firstChild.tagName))
				ret.push(xq.Macro.fromDL2JSON(container.childNodes[i].firstChild));
			else
				ret.push(container.childNodes[i].innerHTML);
		} else {
			if (container.childNodes[i+1].firstChild && ['OL', 'DL'].include(container.childNodes[i+1].firstChild.tagName))
				ret[container.childNodes[i].innerHTML]=xq.Macro.fromDL2JSON(container.childNodes[i+1].firstChild);
			else
				ret[container.childNodes[i].innerHTML]=container.childNodes[i+1].innerHTML;
			i++;
		}
	}
	return ret;
};

xq.Macro.random = Class.create();
xq.Macro.random.prototype = {
	name: 'random',
	
	run: function() {
		this.getBody().innerHTML = Math.random();
	}
};
xq.Macro.random.prototype = Object.extend(new xq.Macro(), xq.Macro.random.prototype);
*/
